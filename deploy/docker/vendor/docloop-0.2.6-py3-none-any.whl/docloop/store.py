from __future__ import annotations

import contextlib
import fcntl
import os
import re
import subprocess
import tempfile
from pathlib import Path

from .document import Document, canonical, digest
from .formats import decode, encode


class Conflict(RuntimeError):
    """The document changed since this operation began."""


class SaveFailure(RuntimeError):
    """A safe save outcome; the chained cause is for private diagnosis only."""

    code = "save_failed"
    message = "Document storage did not complete; review the current state before continuing."

    def __init__(
        self,
        *,
        phase,
        installed=None,
        durability="unknown",
        history="unknown",
        history_durability="unknown",
        attempted_revision=None,
        current_revision=None,
    ):
        super().__init__(self.message)
        self.phase = phase
        self.installed = installed
        self.durability = durability
        self.history = history
        self.history_durability = history_durability
        self.attempted_revision = attempted_revision
        self.current_revision = current_revision
        self.retry_action = False

    @property
    def revision(self):
        return self.current_revision

    def as_dict(self):
        return {
            "code": self.code,
            "message": self.message,
            "phase": self.phase,
            "installed": self.installed,
            "durability": self.durability,
            "history": self.history,
            "history_durability": self.history_durability,
            "attempted_revision": self.attempted_revision,
            "current_revision": self.current_revision,
            "revision": self.revision,
            "retry_action": False,
        }


class HistoryFailure(SaveFailure):
    code = "history_failed"
    message = "Notebook history is unavailable; the current document may still be readable."

    def __init__(self, *, history="unavailable", **kwargs):
        super().__init__(history=history, **kwargs)


class Store:
    def __init__(self, path: Path | str):
        self.path = Path(path).resolve()
        if self.path.suffix not in {".org", ".ipynb"}:
            raise ValueError("Document must be .org or .ipynb")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.history_dir = self.path.parent / ("." + self.path.name + ".history")
        self.history_dir.mkdir(mode=0o700, exist_ok=True)
        with self.lock():
            if not any(
                (self.history_dir / name).exists() for name in ("HEAD", "objects", "config", "refs")
            ):
                try:
                    self.git("init", "--quiet")
                    self.git("config", "user.name", "Docloop")
                    self.git("config", "user.email", "docloop@localhost")
                except (OSError, subprocess.SubprocessError) as error:
                    raise HistoryFailure(phase="history_init") from error

    def git(self, *args: str, input: bytes | None = None, index: Path | None = None) -> str:
        env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
        if index is not None:
            env["GIT_INDEX_FILE"] = str(index)
        result = subprocess.run(
            [
                "git",
                "--git-dir",
                str(self.history_dir),
                "--work-tree",
                str(self.path.parent),
                "-c",
                "core.fsync=all",
                "-c",
                "core.fsyncMethod=fsync",
                *args,
            ],
            cwd=self.path.parent,
            check=True,
            capture_output=True,
            input=input,
            env=env,
        )
        return result.stdout.decode("utf-8")

    @contextlib.contextmanager
    def lock(self):
        with (self.history_dir / "docloop.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock, fcntl.LOCK_UN)

    def _bytes(self):
        try:
            return self.path.read_bytes()
        except FileNotFoundError:
            return b""

    @staticmethod
    def _revision(raw):
        return digest(raw.decode("utf-8"))

    def _observed_revision(self):
        try:
            return self._revision(self._bytes())
        except (OSError, UnicodeError):
            return None

    def read(self) -> tuple[Document, str]:
        raw = self._bytes()
        if not raw and not self.path.exists():
            return Document(), digest("")
        text = raw.decode("utf-8")
        return decode(text, self.path.suffix), digest(text)

    def _head(self):
        # An absent symbolic branch is unborn; other Git failures are unavailable.
        try:
            ref = self.git("symbolic-ref", "-q", "HEAD").strip()
        except subprocess.CalledProcessError as error:
            if error.returncode != 1:
                raise
        else:
            try:
                self.git("show-ref", "--verify", "--quiet", ref)
            except subprocess.CalledProcessError as error:
                if error.returncode == 1:
                    return None
                raise
        return self.git("rev-parse", "--verify", "HEAD^{commit}").strip()

    def _head_identity(self):
        raw = (self.history_dir / "HEAD").read_bytes()
        try:
            ref = self.git("symbolic-ref", "-q", "HEAD").strip()
        except subprocess.CalledProcessError as error:
            if error.returncode != 1:
                raise
            ref = None
        if (self.history_dir / "HEAD").read_bytes() != raw:
            raise Conflict("Notebook branch changed during history recording")
        return raw, ref

    def _assert_head_identity(self, identity):
        if self._head_identity() != identity:
            raise Conflict("Notebook branch changed during history recording")

    def _publish(self, commit, head, identity):
        self._assert_head_identity(identity)
        ref = identity[1]
        if ref is not None:
            # Pin the original branch even if another process switches HEAD mid-call.
            self.git("update-ref", ref, commit, head or "0" * len(commit))
        else:
            # Detached HEAD needs the Git lockfile protocol to reject symbolic switches.
            lock = self.history_dir / "HEAD.lock"
            fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            owned = os.fstat(fd)
            try:
                with os.fdopen(fd, "wb") as stream:
                    self._assert_head_identity(identity)
                    if self._head() != head:
                        raise Conflict("Notebook history changed before publication")
                    stream.write((commit + "\n").encode())
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(lock, self.history_dir / "HEAD")
            finally:
                try:
                    current = lock.lstat()
                except FileNotFoundError:
                    pass
                else:
                    if (current.st_dev, current.st_ino) == (owned.st_dev, owned.st_ino):
                        lock.unlink()
        self._assert_head_identity((commit.encode() + b"\n", None) if ref is None else identity)

    def _recorded(self, head, raw):
        if head is None:
            return not self.path.exists()
        return self.git("show", f"{head}:{self.path.name}").encode("utf-8") == raw

    def _assert_current(self, raw):
        if self._bytes() != raw:
            raise Conflict("External edit detected; reload before continuing")

    @staticmethod
    def _sync(path):
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

    def _sync_document(self, state, prefix=""):
        state["phase"] = prefix + "file_sync"
        self._sync(self.path)
        state["phase"] = prefix + "directory_sync"
        self._sync(self.path.parent)
        state["durability"] = "confirmed"

    def _sync_history(self, head):
        # Git fsyncs newly written objects/refs. Also sync existing objects on recovery.
        tree = self.git("rev-parse", f"{head}^{{tree}}").strip()
        blob = self.git("rev-parse", f"{head}:{self.path.name}").strip()
        for ident in (head, tree, blob):
            path = self.history_dir / "objects" / ident[:2] / ident[2:]
            if path.exists():
                self._sync(path)
                self._sync(path.parent)
            else:
                for pack in (self.history_dir / "objects" / "pack").glob("*"):
                    if pack.is_file():
                        self._sync(pack)
                self._sync(self.history_dir / "objects" / "pack")
        self._sync(self.history_dir / "objects")
        self._sync(self.history_dir / "HEAD")
        try:
            ref = self.git("symbolic-ref", "-q", "HEAD").strip()
        except subprocess.CalledProcessError as error:
            if error.returncode != 1:
                raise
        else:
            path = self.history_dir / ref
            if path.exists():
                self._sync(path)
                parent = path.parent
                while parent != self.history_dir:
                    self._sync(parent)
                    parent = parent.parent
            elif (self.history_dir / "packed-refs").exists():
                self._sync(self.history_dir / "packed-refs")
        self._sync(self.history_dir)
        self._sync(self.path.parent)

    def _record(self, raw, message, state, *, force=False, prefix="", expected_head=None):
        state["phase"] = prefix + "history_read"
        identity = self._head_identity()
        head = self._head()
        self._assert_head_identity(identity)
        if expected_head is not None and (identity, head) != expected_head:
            raise Conflict("Notebook history changed before snapshot recording")
        recorded = self._recorded(head, raw)
        self._assert_current(raw)
        if not recorded or force:
            state["history"] = "pending"
            state["history_durability"] = "unknown"
            state["phase"] = prefix + "history_blob"
            blob = self.git("hash-object", "-w", "--stdin", input=raw).strip()
            with tempfile.TemporaryDirectory(prefix="snapshot-", dir=self.history_dir) as tmp:
                index = Path(tmp) / "index"
                state["phase"] = prefix + "history_index"
                self.git("read-tree", head if head else "--empty", index=index)
                self.git(
                    "update-index",
                    "--add",
                    "--cacheinfo",
                    "100644",
                    blob,
                    self.path.name,
                    index=index,
                )
                state["phase"] = prefix + "history_tree"
                tree = self.git("write-tree", index=index).strip()
                state["phase"] = prefix + "history_commit"
                parents = ("-p", head) if head else ()
                commit = self.git(
                    "-c", "commit.gpgsign=false", "commit-tree", tree, *parents, "-m", message
                ).strip()
            # Never commit --path: it rereads a potentially newer external worktree file.
            self._assert_current(raw)
            state["phase"] = prefix + "history_ref"
            self._publish(commit, head, identity)
            head = commit
            if identity[1] is None:
                identity = (commit.encode() + b"\n", None)
        if head is not None:
            state["phase"] = prefix + "history_sync"
            self._sync_history(head)
            state["history_durability"] = "confirmed"
            self._assert_head_identity(identity)
            if self._head() != head or not self._recorded(head, raw):
                raise Conflict("Notebook history changed during recording")
        self._assert_current(raw)
        state["history"] = "recorded"
        if head is not None:
            # Keep checkout compatibility; unrelated staged entries are left alone.
            state["phase"] = prefix + "history_worktree_index"
            blob = self.git("rev-parse", f"{head}:{self.path.name}").strip()
            self.git("update-index", "--add", "--cacheinfo", "100644", blob, self.path.name)
            self._assert_head_identity(identity)
            self._assert_current(raw)
        return identity, head

    def save(self, doc: Document, expected: str, message: str) -> str:
        state = dict(phase="encode", installed=False, durability="unchanged", history="unknown")
        attempted = None
        try:
            text = encode(doc, self.path.suffix, stabilize=True)
            raw = text.encode("utf-8")
            attempted = digest(text)
            with self.lock():
                state["phase"] = "read"
                current = self._bytes()
                if self._revision(current) != expected:
                    raise Conflict("Document changed; reload before applying this edit")
                # Discover interrupted saves after restart, without a writable error marker.
                state["phase"] = "preserve_history_read"
                identity = self._head_identity()
                expected_head = (identity, self._head())
                self._assert_head_identity(identity)
                if self.path.exists():
                    recorded = self._recorded(expected_head[1], current)
                    state["history"] = "recorded" if recorded else "pending"
                    self._sync_document(state, "preserve_")
                    if recorded:
                        # A previous interrupted sync can leave a visible but unsynced HEAD.
                        state["phase"] = "preserve_history_sync"
                        self._sync_history(expected_head[1])
                        self._assert_head_identity(expected_head[0])
                        if self._head() != expected_head[1]:
                            raise Conflict("Notebook history changed before preservation")
                        self._assert_current(current)
                    else:
                        expected_head = self._record(
                            current,
                            "Recover unrecorded notebook",
                            state,
                            prefix="preserve_",
                            expected_head=expected_head,
                        )
                state.update(
                    phase="temporary_write",
                    durability="unchanged",
                    history="unknown",
                    history_durability="unknown",
                )
                fd, temporary = tempfile.mkstemp(prefix=".docloop-", dir=self.path.parent)
                try:
                    with os.fdopen(fd, "wb") as stream:
                        stream.write(raw)
                        stream.flush()
                        state["phase"] = "file_sync"
                        os.fsync(stream.fileno())
                    self._assert_current(current)
                    self._assert_head_identity(expected_head[0])
                    if self._head() != expected_head[1]:
                        raise Conflict("Notebook history changed before document replacement")
                    state.update(phase="replace", installed=None, durability="unknown")
                    os.replace(temporary, self.path)
                    state.update(installed=True, durability="unknown", history="pending")
                    state["phase"] = "directory_sync"
                    self._sync(self.path.parent)
                    state["durability"] = "confirmed"
                finally:
                    if os.path.exists(temporary):
                        os.unlink(temporary)
                self._record(raw, message, state, force=True, expected_head=expected_head)
            return attempted
        except Conflict as error:
            if not state["installed"]:
                raise
            raise SaveFailure(
                **state, attempted_revision=attempted, current_revision=self._observed_revision()
            ) from error
        except (OSError, subprocess.SubprocessError, UnicodeError) as error:
            raise SaveFailure(
                **state, attempted_revision=attempted, current_revision=self._observed_revision()
            ) from error

    def recover_history(self, expected_revision: str) -> str:
        state = dict(
            phase="recovery_read", installed=False, durability="unknown", history="pending"
        )
        try:
            with self.lock():
                raw = self._bytes()
                if self._revision(raw) != expected_revision:
                    raise Conflict("Document changed; reload before recovering history")
                if self.path.exists():
                    self._sync_document(state, "recovery_")
                self._record(raw, "Recover unrecorded notebook", state)
                return expected_revision
        except Conflict:
            raise
        except (OSError, subprocess.SubprocessError, UnicodeError) as error:
            raise HistoryFailure(
                **state,
                attempted_revision=expected_revision,
                current_revision=self._observed_revision(),
            ) from error

    def history_status(self):
        try:
            raw = self._bytes()
            head = self._head()
            recorded = self._recorded(head, raw)
            self._assert_current(raw)
            return {
                "status": "unborn"
                if head is None and recorded
                else "recorded"
                if recorded
                else "pending",
                "revision": self._revision(raw),
                "commit": head,
                "unborn": head is None,
                "history_durability": "unknown",
            }
        except (OSError, subprocess.SubprocessError, UnicodeError, Conflict) as error:
            raise HistoryFailure(
                phase="history_read", current_revision=self._observed_revision()
            ) from error

    def history(self) -> list[dict]:
        try:
            head = self._head()
            if head is None:
                return []
            rows = self.git("log", "--format=%H%x09%aI%x09%s", head, "--", self.path.name)
            return [
                dict(zip(("commit", "date", "message"), row.split("\t", 2)))
                for row in rows.splitlines()
            ]
        except (OSError, subprocess.SubprocessError, UnicodeError) as error:
            raise HistoryFailure(
                phase="history_read", current_revision=self._observed_revision()
            ) from error

    def conversation_history(self):
        """Retained message revisions from this native store's selected Git ancestry."""
        from .history_ui import retained_history

        return retained_history(self)

    def version(self, commit: str) -> str:
        if not re.fullmatch(r"[a-f0-9]{40,64}", commit):
            raise ValueError("Version must be a full Git commit ID")
        try:
            return self.git("show", f"{commit}:{self.path.name}")
        except (OSError, subprocess.SubprocessError, UnicodeError) as error:
            raise HistoryFailure(
                phase="history_version", current_revision=self._observed_revision()
            ) from error

    def restore(self, commit: str, expected: str) -> str:
        return self.save(
            decode(self.version(commit), self.path.suffix), expected, f"Restore {commit}"
        )

    def diff(self, older: str, newer: str) -> str:
        import difflib

        def semantic(commit):
            doc = decode(self.version(commit), self.path.suffix)
            lines = ["document=" + canonical({"metadata": doc.metadata, "extra": doc.extra}) + "\n"]
            for node in doc.nodes:
                lines.append(f"[{node.id}] " + canonical(node.value()) + "\n")
            return lines

        return "".join(difflib.unified_diff(semantic(older), semantic(newer), older, newer))
