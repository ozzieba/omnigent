from __future__ import annotations

import argparse
import copy
import json
import os
import secrets
import shlex
import sys
from pathlib import Path

from .document import Node, canonical, digest, pretty, pretty_text
from .store import SaveFailure, Store


def runtime(store, args, *, mcp_dispatch=None, model=None):
    from .engine import Engine
    from .environments import environment_from_descriptor
    from .execution import Executor
    from .model_routes import ModelCatalog
    from .provider import ChatProvider

    provider_environ = dict(os.environ)
    from .team import Team

    def environment(current):
        doc, _ = current.read()
        try:
            descriptor = json.loads(doc.get("docloop-environment").source)
        except ValueError:
            descriptor = {}
        if current.path != store.path:
            try:
                inherited = json.loads(store.read()[0].get("docloop-environment").source)
                descriptor = {
                    **inherited,
                    "workspace": descriptor.get("workspace", current.path.parent),
                }
            except ValueError:
                pass
        workspace = args.workspace if current.path == store.path else None
        workspace = workspace or descriptor.get("workspace") or current.path.parent
        kind = args.environment or descriptor.get("kind", "local")
        if kind == "oci":
            descriptor = {**descriptor, "kind": kind, "workspace": workspace}
            if args.image:
                descriptor["image"] = args.image
            if args.runtime:
                descriptor["runtime"] = args.runtime
            return environment_from_descriptor(descriptor)
        return environment_from_descriptor({"kind": "local", "workspace": workspace})

    def executor(current, selected_model=None):
        if provider_environ.get("DOCLOOP_PYTHON_STATE") == "1":
            from .python_objects import enable

            enable(current)
        if mcp_dispatch is not None and hasattr(mcp_dispatch, "materialize"):
            mcp_dispatch.materialize(current)
        env = environment(current)
        doc, revision = current.read()
        descriptor = canonical(env.descriptor())
        try:
            old = doc.get("docloop-environment")
            if old.source != descriptor:
                doc.update(old.id, source=descriptor)
                current.save(doc, revision, "Configure execution environment")
        except ValueError:
            doc.insert(Node("docloop-environment", "raw", descriptor, language="json"))
            current.save(doc, revision, "Configure execution environment")
        team = Team(
            current,
            runner=lambda child, cancel: child_run(child, cancel, selected_model),
            workspace=env.workspace,
            model=selected_model,
        )
        config = json.loads(Path(args.mcp_config).read_text()) if args.mcp_config else {}
        return Executor(
            current,
            timeout=args.timeout,
            environment=env,
            team=team,
            mcp_config=config,
            mcp_dispatch=mcp_dispatch,
        )

    def child_run(child, cancel, selected_model=None):
        if catalog is not None:
            # Resume uses the child's durable binding, not a later parent choice.
            saved_model = child.read()[0].metadata.get("docloop_child_model")
            if not isinstance(saved_model, str) or not saved_model:
                raise ValueError(
                    "Child model binding is missing; explicitly restore its original model"
                )
            selected_model = catalog.resolve(saved_model)
        child_executor = executor(child, selected_model)
        try:
            return Engine(
                child,
                ChatProvider.from_env(
                    agent_id="docloop-" + digest(str(child.path))[:24],
                    model=selected_model,
                    environ=provider_environ,
                ),
                child_executor,
                budget_bytes=args.budget_bytes,
            ).run(max_steps=args.steps, cancel_event=cancel)
        finally:
            child_executor.team.close()
            child_executor.close()

    execute = executor(store, model)

    def factory(_cancel=None, *, model=None):
        selected = (
            catalog.resolve(default_model if model is None else model)
            if catalog is not None
            else model
        )
        selected_executor = executor(store, selected)
        selected_executor.native_jupyter = execute.native_jupyter
        return Engine(
            store,
            ChatProvider.from_env(
                agent_id="docloop-" + digest(str(store.path))[:24],
                model=selected,
                environ=provider_environ,
            ),
            selected_executor,
            budget_bytes=args.budget_bytes,
        )

    # Construction validates configuration without making a provider request.
    # Editing/evaluation remain available when inference is absent or incomplete.
    try:
        catalog = ModelCatalog(provider_environ) if provider_environ.get("DOCLOOP_MODEL") else None
        default_model = catalog.resolve(model) if catalog is not None else model
        ChatProvider.from_env(
            agent_id="docloop-" + digest(str(store.path))[:24],
            model=default_model,
            environ=provider_environ,
        )
    except (ValueError, OSError):
        return execute, None
    if catalog is not None:
        for choice in catalog.models:
            try:
                ChatProvider.from_env(model=choice, environ=provider_environ)
            except (ValueError, OSError):
                return execute, None
    execute.team.model = default_model
    factory.model_catalog = catalog
    factory.default_model = default_model
    return execute, factory


def show(store):
    doc, revision = store.read()
    print(f"{store.path} · {revision[:12]}")
    for node in doc.nodes:
        source = (
            pretty_text(node.source) if node.language in {"json", "mcp", "team"} else node.source
        )
        print(f"\n[{node.id}] {node.kind} ({node.language})\n{source}")
        for output in node.outputs:
            text = output.get("text")
            print(pretty_text(text) if isinstance(text, str) else pretty(output))


def wait_operation(app):
    """Wait without blocking cancellation; the worker owns execution cleanup."""
    try:
        while app.worker and app.worker.is_alive():
            app.worker.join(0.1)
    except KeyboardInterrupt:
        app.mutate({"action": "stop"})
        print("Cancellation requested; waiting for execution receipts.", file=sys.stderr)
        while app.worker and app.worker.is_alive():
            app.worker.join(0.1)
    if app.error:
        print(f"Error: {app.error}", file=sys.stderr)
    if app.result is not None:
        print(pretty(app.result))


def repl(store, execute, factory):
    from .web import Application

    def terminal_factory(_event=None, *, model=None):
        return factory() if model is None else factory(model=model)

    terminal_factory.model_catalog = getattr(factory, "model_catalog", None)
    terminal_factory.default_model = getattr(factory, "default_model", None)
    app = Application(store, terminal_factory if factory is not None else None, execute)
    print(
        "Docloop terminal. Text instructs the agent. /note adds Markdown. /help lists commands. Ctrl-D exits."
    )
    try:
        while True:
            try:
                line = input("doc> ")
            except (EOFError, KeyboardInterrupt):
                print()
                return
            try:
                if not line.strip():
                    continue
                if not line.startswith("/"):
                    app.instruct({"source": line})
                    wait_operation(app)
                    continue
                command, *parts = shlex.split(line)
                if command in {"/quit", "/exit"}:
                    return
                if command == "/help":
                    print(
                        "Text instructs/runs. /note 'text' /show /run [steps] /eval ID /edit ID 'source' /code language 'source' /delete ID /history /verify-history /restore COMMIT /quit"
                    )
                elif command == "/show":
                    show(store)
                elif command in {"/run", "/eval"}:
                    data = {"action": command[1:], "revision": store.read()[1]}
                    if command == "/run":
                        data["steps"] = int(parts[0]) if parts else 10
                    else:
                        data["address"] = parts[0]
                    app.mutate(data)
                    wait_operation(app)
                    if command == "/eval":
                        show(store)
                elif command == "/history":
                    print(json.dumps(store.history(), indent=2))
                elif command == "/verify-history":
                    revision = store.recover_history(store.read()[1])
                    print(pretty({"status": "Version history verified", "revision": revision}))
                elif command == "/restore":
                    store.restore(parts[0], store.read()[1])
                elif command in {"/edit", "/delete", "/code", "/note"}:
                    doc, rev = store.read()
                    if command == "/edit":
                        doc.update(parts[0], source=parts[1])
                    elif command == "/delete":
                        doc.delete(parts[0])
                    elif command == "/note":
                        doc.insert(
                            Node("note_" + secrets.token_hex(6), "markdown", " ".join(parts))
                        )
                    else:
                        doc.insert(
                            Node(
                                "code_" + secrets.token_hex(6), "code", parts[1], language=parts[0]
                            )
                        )
                    store.save(doc, rev, "Terminal " + command)
                else:
                    print("Unknown command; use /help")
            except KeyboardInterrupt:
                app.mutate({"action": "stop"})
                print("Cancellation requested")
            except SaveFailure as exc:
                print(pretty(exc.as_dict()), file=sys.stderr)
            except Exception as exc:
                print(f"Error: {exc}", file=sys.stderr)
    finally:
        active = app.close()["active"]
        if active:
            print(
                "Shutdown still has active execution; inspect receipts: " + ", ".join(active),
                file=sys.stderr,
            )


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Document-primary coding harness (private/internal)"
    )
    parser.add_argument("--workspace")
    parser.add_argument("--environment", choices=["local", "oci"])
    parser.add_argument("--image")
    parser.add_argument("--runtime", choices=["podman", "docker"])
    parser.add_argument(
        "--mcp-config", help="JSON mapping of MCP server names to connection configuration"
    )
    parser.add_argument("--timeout", type=float, default=60)
    parser.add_argument("--budget-bytes", type=int, default=24000)
    parser.add_argument("--steps", type=int, default=20)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in (
        "init",
        "show",
        "run",
        "instruct",
        "eval",
        "add",
        "edit",
        "delete",
        "history",
        "verify-history",
        "version",
        "diff",
        "restore",
        "convert",
        "serve",
        "terminal",
        "checkpoint",
        "checkpoints",
        "state-diff",
        "restore-state",
    ):
        p = sub.add_parser(name)
        p.add_argument("document", type=Path)
        if name in {"eval", "edit", "delete"}:
            p.add_argument("address")
        if name == "verify-history":
            p.add_argument(
                "--revision", help="Expected document revision; defaults to the current revision"
            )
        if name in {"init", "add", "edit", "instruct"}:
            p.add_argument(
                "--source",
                default="" if name == "init" else None,
                help="Text; omitted add/edit/instruct reads stdin",
            )
        if name == "add":
            p.add_argument(
                "--kind", default="markdown", choices=["markdown", "code", "section", "item", "raw"]
            )
            p.add_argument("--language", default="python")
            p.add_argument("--id")
            p.add_argument("--after")
        if name in {"version", "restore", "restore-state"}:
            p.add_argument("commit")
        if name in {"diff", "state-diff"}:
            p.add_argument("older")
            p.add_argument("newer")
        if name == "checkpoint":
            p.add_argument("--message", default="Checkpoint notebook and workspace")
        if name == "restore-state":
            p.add_argument("destination", type=Path)
        if name == "convert":
            p.add_argument("output", type=Path)
        if name == "serve":
            p.add_argument(
                "--tailscale-login", help="Exact login injected by a managed Tailscale HTTP proxy"
            )
            p.add_argument(
                "--trusted-proxy-cidrs",
                help="Explicit comma-separated TCP peer CIDRs for that proxy",
            )
            p.add_argument(
                "--access-token-file",
                help="Secret file for private deployment login (or DOCLOOP_ACCESS_TOKEN_FILE)",
            )
            p.add_argument("--host", default="127.0.0.1")
            p.add_argument("--port", type=int, default=8765)
            p.add_argument(
                "--allowed-host",
                action="append",
                default=[],
                help="Internal proxy Host header, including port when present",
            )
    args = parser.parse_args(argv)
    execute = None
    app = None
    try:
        store = Store(args.document)
        command = args.command
        if command == "show":
            show(store)
        elif command in {"init", "add", "edit", "delete"}:
            doc, revision = store.read()
            if command == "init" and store.path.exists():
                raise ValueError("Document already exists")
            source = getattr(args, "source", "")
            if source is None:
                source = sys.stdin.read()
            if command == "edit":
                doc.update(args.address, source=source)
            elif command == "delete":
                doc.delete(args.address)
            elif command == "init":
                doc.insert(Node("task", "markdown", source or "Describe the task here."))
            else:
                node = Node(
                    args.id or "n_" + secrets.token_hex(6),
                    args.kind,
                    source,
                    language=args.language,
                )
                doc.insert(node, args.after)
                print(node.id)
            store.save(doc, revision, "CLI " + command)
        elif command == "history":
            print(json.dumps(store.history(), indent=2))
        elif command == "verify-history":
            revision = store.recover_history(args.revision or store.read()[1])
            print(pretty({"status": "Version history verified", "revision": revision}))
        elif command == "version":
            print(store.version(args.commit))
        elif command == "diff":
            print(store.diff(args.older, args.newer))
        elif command == "restore":
            store.restore(args.commit, store.read()[1])
        elif command in {"checkpoint", "checkpoints", "state-diff", "restore-state"}:
            from .checkpoints import Checkpoints

            checkpoints = Checkpoints(store, workspace=args.workspace)
            if command == "checkpoint":
                print(checkpoints.create(store.read()[1], args.message))
            elif command == "checkpoints":
                print(json.dumps(checkpoints.history(), indent=2))
            elif command == "state-diff":
                print(checkpoints.diff(args.older, args.newer))
            else:
                print(checkpoints.restore(args.commit, args.destination).path)
        elif command == "convert":
            target = Store(args.output)
            if target.path.exists():
                raise ValueError("Conversion destination already exists")
            target.save(store.read()[0], target.read()[1], "Convert from " + str(store.path))
        else:
            execute, factory = runtime(store, args)
            if command in {"run", "instruct"}:
                from .web import Application

                app = Application(store, factory, execute, budget_bytes=args.budget_bytes)
                if command == "instruct":
                    app.instruct(
                        {
                            "source": args.source if args.source is not None else sys.stdin.read(),
                            "steps": args.steps,
                        }
                    )
                else:
                    app.mutate({"action": "run", "revision": store.read()[1], "steps": args.steps})
                wait_operation(app)
                if app.error:
                    return 1
            elif command == "eval":
                execute(args.address, store.read()[1])
            elif command == "terminal":
                repl(store, execute, factory)
            else:
                from .web import Application, make_server

                def fork_runtime(current):
                    fork_args = copy.copy(args)
                    fork_args.workspace = None
                    fork_args.environment = fork_args.image = fork_args.runtime = None
                    return runtime(current, fork_args)

                app = Application(
                    store,
                    factory,
                    execute,
                    budget_bytes=args.budget_bytes,
                    access_token_file=args.access_token_file,
                    runtime_factory=fork_runtime,
                    tailscale_login=args.tailscale_login,
                    trusted_proxy_cidrs=args.trusted_proxy_cidrs,
                )
                server = make_server(app, args.host, args.port, args.allowed_host)
                print(f"Docloop internal UI: http://{args.host}:{server.server_port}", flush=True)
                try:
                    server.serve_forever()
                finally:
                    app.close()
                    server.server_close()
        return 0
    except KeyboardInterrupt:
        return 130
    except SaveFailure as exc:
        print(pretty(exc.as_dict()), file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"docloop: {exc}", file=sys.stderr)
        return 1
    finally:
        if app is not None:
            active = app.close()["active"]
            if active:
                print(
                    "Shutdown still has active execution; inspect receipts: " + ", ".join(active),
                    file=sys.stderr,
                )
        if app is None and execute is not None:
            if getattr(execute, "team", None) is not None:
                execute.team.close()
            execute.close()


if __name__ == "__main__":
    raise SystemExit(main())
