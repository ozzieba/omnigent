"""Native HTTP application with a read-only view of retained conversation history."""

from __future__ import annotations

import ipaddress
import json
import os
import secrets
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from .document import Node
from .formats import decode
from .storage_response import history_state, storage_error
from .store import Conflict, HistoryFailure, SaveFailure, Store


def tailscale_configuration(login=None, cidrs=None):
    """Opt-in trust of an explicitly constrained managed HTTP proxy."""
    if not login and not cidrs:
        return None, ()
    if not login or not cidrs:
        raise ValueError(
            "DOCLOOP_TAILSCALE_LOGIN and DOCLOOP_TRUSTED_PROXY_CIDRS are both required"
        )
    if len(login) > 320 or any(c.isspace() or c == "," for c in login):
        raise ValueError("DOCLOOP_TAILSCALE_LOGIN must be one exact login without whitespace")
    networks = []
    for value in cidrs.split(","):
        value = value.strip()
        if "/" not in value:
            raise ValueError("Trusted proxies require explicit CIDRs")
        network = ipaddress.ip_network(value, strict=True)
        if network.prefixlen == 0:
            raise ValueError("Trusted proxy CIDRs must not include all addresses")
        networks.append(network)
    return login, tuple(networks)


class Application:
    def __init__(
        self,
        store: Store,
        engine_factory=None,
        executor=None,
        budget_bytes=24000,
        access_token_file=None,
        runtime_factory=None,
        tailscale_login=None,
        trusted_proxy_cidrs=None,
    ):
        self.store = store
        self.engine_factory = engine_factory
        self.selected_model = getattr(engine_factory, "default_model", None)
        self.active_model = None
        self.executor = executor
        self.runtime_factory = runtime_factory
        self._executors = [executor] if executor is not None else []
        self._closed = False
        from .native import NativeJupyter

        self.native = NativeJupyter(self)
        if executor is not None:
            executor.native_jupyter = self.native
        self.budget_bytes = budget_bytes
        self.token = secrets.token_urlsafe(32)
        self.tailscale_login, self.trusted_proxy_networks = tailscale_configuration(
            tailscale_login
            if tailscale_login is not None
            else os.environ.get("DOCLOOP_TAILSCALE_LOGIN"),
            trusted_proxy_cidrs
            if trusted_proxy_cidrs is not None
            else os.environ.get("DOCLOOP_TRUSTED_PROXY_CIDRS"),
        )
        access_token_file = access_token_file or os.environ.get("DOCLOOP_ACCESS_TOKEN_FILE")
        if self.tailscale_login and access_token_file:
            raise ValueError("Choose Tailscale identity or access-token authentication, not both")
        self.access_token = (
            Path(access_token_file).read_text().strip() if access_token_file else None
        )
        if self.access_token is not None and len(self.access_token) < 32:
            raise ValueError("Access token file must contain a secret of at least 32 characters")
        self.sessions = {}
        self.cancel = threading.Event()
        self.worker = None
        self._worker_retired = True
        self.error = None
        self.result = None
        self.status = "ready"
        self.lock = threading.RLock()
        self.storage_fault = None

    def state(self):
        from .context import project

        doc, revision = self.store.read()
        projection = project(doc, budget_bytes=self.budget_bytes)
        return {
            "native_jupyter": self.native.descriptor(),
            "history_status": history_state(self.store),
            "path": str(self.store.path),
            "revision": revision,
            "nodes": [n.value() for n in doc.nodes],
            "metadata": doc.metadata,
            "cache_candidates": projection.unchanged_prefix_nodes,
            "context_epochs": os.environ.get("DOCLOOP_CONTEXT_EPOCHS", "0") == "1",
            "running": bool(self.worker and self.worker.is_alive() and not self._worker_retired),
            "error": self.error,
            "result": self.result,
            "status": self.status,
            "authentication": self.access_token is not None,
            "provider_available": self.engine_factory is not None,
            "models": list(
                getattr(getattr(self.engine_factory, "model_catalog", None), "models", ())
            ),
            "default_model": getattr(self.engine_factory, "default_model", None),
            "model": self.selected_model,
            "active_model": self.active_model,
            "pending_instructions": [n.id for n in self._instructions(doc)],
        }

    def conversation(self, *, selection="next", before=None, limit=50):
        from .context_bridge import ContextBridge, Limits
        from .engine import EPOCH_PROTOCOL
        from .python_harness import PROTOCOL as PYTHON_PROTOCOL
        from .python_objects import enabled

        with self.lock:
            return ContextBridge(self.store, Limits(budget_bytes=self.budget_bytes)).conversation(
                PYTHON_PROTOCOL if enabled(self.store.read()[0]) else EPOCH_PROTOCOL,
                selection=selection,
                before=before,
                limit=limit,
                enabled=os.environ.get("DOCLOOP_CONTEXT_EPOCHS", "0") == "1",
                model=self.selected_model,
            )

    def _resolve_model(self, model=None):
        catalog = getattr(self.engine_factory, "model_catalog", None)
        selected = self.selected_model if model is None else model
        if catalog is None:
            if selected is not None:
                raise ValueError("Model selection is unavailable for this provider")
            return None
        return catalog.resolve(selected)

    def _run_engine(self, steps, model):
        # The provider and child runner are constructed with an explicit immutable ID.
        with self.lock:
            if self._closed:
                raise ValueError("Application is shutting down")
            self.active_model = model
            engine = (
                self.engine_factory(self.cancel, model=model)
                if model is not None
                else self.engine_factory(self.cancel)
            )
            evaluator = getattr(engine, "evaluator", None)
            if evaluator is not None and not any(evaluator is e for e in self._executors):
                self._executors.append(evaluator)
        result = engine.run(max_steps=steps, cancel_event=self.cancel)
        if isinstance(result, dict) and model is not None:
            result = {**result, "model": model}
        return result

    def select_model(self, model):
        with self.lock:
            if self._closed:
                raise ValueError("Application is shutting down")
            selected = self._resolve_model(model)
            if self.worker and self.worker.is_alive() and not self._worker_retired:
                raise Conflict("Stop the active run before changing models")
            self.selected_model = selected
            return self.state()

    def _storage_failed(self, failure):
        # Keep this outside the document: recording a failed save must not write again.
        with self.lock:
            self.storage_fault = {
                **(self.result or {}),
                **storage_error(failure),
                "retry_action": False,
            }
            self.result = self.storage_fault
            self.error = self.result["error"]
            self.status = "error"
            self.cancel.set()

    def _check_history(self):
        if self.storage_fault:
            raise Conflict("Verify version history before starting another operation")
        status = self.store.history_status()
        if status["status"] == "pending":
            raise HistoryFailure(
                phase="history_read", history="pending", current_revision=status["revision"]
            )

    def start(self, operation):
        with self.lock:
            if self._closed:
                raise ValueError("Application is shutting down")
            if self.worker and self.worker.is_alive() and not self._worker_retired:
                raise Conflict("A run or evaluation is already active")
            try:
                self._check_history()
            except SaveFailure as exc:
                self._storage_failed(exc)
                raise
            self.cancel.clear()
            self.error = None
            self.result = None
            self.status = "running"
            self._worker_retired = False

            def work():
                current_operation = operation
                while True:
                    try:
                        result = current_operation()
                        self.result = result if isinstance(result, dict) else None
                        if isinstance(result, dict) and result.get("retryable"):
                            self.status = "paused"
                        elif isinstance(result, dict) and result.get("error"):
                            self.error = (
                                storage_error(result["storage_failure"])["error"]
                                if result.get("storage_failure")
                                else str(result["error"])
                            )
                            self.status = "error"
                        elif (
                            self.cancel.is_set()
                            or isinstance(result, dict)
                            and result.get("cancelled")
                        ):
                            self.status = "stopped"
                        elif isinstance(result, dict) and (
                            result.get("paused") or result.get("done") is False
                        ):
                            self.status = "paused"
                        elif isinstance(result, dict) and result.get("done"):
                            self.status = "completed"
                        else:
                            self.status = "ready"
                    except SaveFailure as exc:
                        self._storage_failed(exc)
                    except Exception as exc:
                        self.error = str(exc)
                        self.status = "error"
                    # Submission and worker exit share this lock: an instruction
                    # cannot land between the pending check and worker retirement.
                    with self.lock:
                        if isinstance(self.result, dict) and self.result.get("storage_failure"):
                            self._storage_failed(self.result["storage_failure"])
                        if not self.storage_fault:
                            try:
                                self._check_history()
                            except SaveFailure as exc:
                                self._storage_failed(exc)
                        if self.storage_fault:
                            self.result = self.storage_fault
                            self.error = self.result["error"]
                            self.status = "error"
                        doc, _ = self.store.read()
                        pending = self._instructions(doc, {"pending"})
                        if (
                            not self._closed
                            and not self.storage_fault
                            and pending
                            and self.engine_factory is not None
                            and (self.result or {}).get("retry_action") is not False
                        ):
                            self.cancel.clear()
                            self.status, self.error = "running", None
                            current_operation = self._run_instructions
                            continue
                        self.active_model = None
                        self._worker_retired = True
                        return

            self.worker = threading.Thread(target=work, daemon=True)
            self.worker.start()

    @staticmethod
    def _instructions(doc, statuses=None):
        statuses = statuses or {"pending", "active", "paused"}
        return [
            n
            for n in doc.nodes
            if n.metadata.get("docloop_role") == "user_instruction"
            and n.metadata.get("instruction_status") in statuses
        ]

    def _instruction_edit(self, edit, message):
        for _ in range(20):
            doc, revision = self.store.read()
            result = edit(doc)
            try:
                self.store.save(doc, revision, message)
                return result
            except Conflict:
                continue
        raise Conflict("Document kept changing; instruction update could not be saved")

    def _run_instructions(self, requested_model=None):
        with self.lock:
            if self.cancel.is_set():
                return {"done": True, "cancelled": True}

            current, _ = self.store.read()
            waiting = self._instructions(current)
            pending = [n for n in waiting if n.metadata.get("instruction_status") == "pending"]
            first = (pending or waiting)[0] if waiting else None
            raw_model = (
                requested_model
                if requested_model is not None
                else (first.metadata.get("instruction_model") or self.selected_model)
                if first
                else self.selected_model
            )
            try:
                model = self._resolve_model(raw_model)
            except ValueError:

                def pause_invalid(doc):
                    for node in self._instructions(doc):
                        if (
                            node.metadata.get("instruction_model") or self.selected_model
                        ) == raw_model:
                            node.metadata["instruction_status"] = "paused"

                self._instruction_edit(pause_invalid, "Pause unavailable model instructions")
                raise
            self.active_model = model

            def claim(doc):
                nodes = [
                    n
                    for n in self._instructions(doc)
                    if (n.metadata.get("instruction_model") or self.selected_model) == model
                ]
                for node in nodes:
                    node.metadata["instruction_status"] = "active"
                return {n.id: n.source for n in nodes}, max(
                    (n.metadata.get("instruction_steps", 10) for n in nodes), default=10
                )

            addresses, steps = self._instruction_edit(claim, "Begin document instructions")
        try:
            result = self._run_engine(steps, model)
        except SaveFailure:
            raise
        except Exception as exc:
            result = {"done": True, "error": str(exc)}
        with self.lock:
            if (
                not self.cancel.is_set()
                and not self.storage_fault
                and not result.get("cancelled")
                and result.get("retry_action") is not False
            ):
                status = "completed" if result.get("done") and not result.get("error") else "paused"

                def finish(doc):
                    for node in self._instructions(doc):
                        if node.id in addresses:
                            node.metadata["instruction_status"] = (
                                status if node.source == addresses[node.id] else "pending"
                            )

                self._instruction_edit(finish, "Record instruction run outcome")
        return result

    def instruct(self, data):
        with self.lock:
            try:
                self._check_history()
                return self._instruct(data)
            except SaveFailure as exc:
                self._storage_failed(exc)
                raise

    def _instruct(self, data):
        source = data.get("source")
        if not isinstance(source, str) or not source.strip():
            raise ValueError("An instruction is required")
        steps = int(data.get("steps", 10))
        if not 1 <= steps <= 1000:
            raise ValueError("Steps must be between 1 and 1000")
        address = data.get("id") or "instruction_" + secrets.token_hex(12)
        with self.lock:
            if self._closed:
                raise ValueError("Application is shutting down")
            if self.engine_factory is None:
                raise ValueError("Configure a provider before sending instructions")
            selected = self._resolve_model(data.get("model"))
            if (
                self.worker
                and self.worker.is_alive()
                and not self._worker_retired
                and self.active_model is not None
                and self.active_model != selected
            ):
                raise Conflict("Stop the active run before changing models")

            def append(doc):
                existing = next((n for n in doc.nodes if n.id == address), None)
                if existing:
                    if (
                        existing.source != source
                        or existing.metadata.get("instruction_model") != selected
                        or existing.metadata.get("instruction_steps", 10) != steps
                        or existing.metadata.get("docloop_role") != "user_instruction"
                    ):
                        raise Conflict("Instruction ID already has different content")
                    return False
                doc.insert(
                    Node(
                        address,
                        "markdown",
                        source,
                        metadata={
                            "docloop_role": "user_instruction",
                            "instruction_status": "pending",
                            "instruction_steps": steps,
                            "instruction_model": selected,
                        },
                    )
                )
                return True

            added = self._instruction_edit(append, "Human instruction")
            if added:
                self.selected_model = selected
                if self.worker and self.worker.is_alive() and not self._worker_retired:
                    self.cancel.set()
                    self.status = "steering"
                else:
                    self.active_model = selected
                    self.start(self._run_instructions)
        return self.state()

    def close(self, timeout=10):
        with self.lock:
            self._closed = True
            self.cancel.set()
            executors = list(self._executors)
        deadline = time.monotonic() + max(0, timeout)
        active = []
        for executor in executors:
            team = getattr(executor, "team", None)
            if team is not None:
                active.extend(team.close(max(0, deadline - time.monotonic()))["active"])
        if self.worker and self.worker is not threading.current_thread():
            self.worker.join(max(0, deadline - time.monotonic()))
            if self.worker.is_alive():
                active.append(str(self.store.path))
        self.native.close()
        for executor in executors:
            if callable(getattr(executor, "close", None)):
                executor.close()
        return {"active": active}

    def mutate(self, data):
        with self.lock:
            try:
                return self._mutate(data)
            except SaveFailure as exc:
                self._storage_failed(exc)
                raise

    def _mutate(self, data):
        if self._closed:
            raise ValueError("Application is shutting down")
        action = data["action"]
        if action == "model":
            return self.select_model(data.get("model"))
        if action == "context":
            if os.environ.get("DOCLOOP_CONTEXT_EPOCHS", "0") != "1":
                raise ValueError("Context epochs is not enabled for this service")
            from .context_bridge import ContextBridge, Limits
            from .engine import EPOCH_PROTOCOL

            return ContextBridge(self.store, Limits(budget_bytes=self.budget_bytes)).call(
                data["request"], EPOCH_PROTOCOL
            )
        if action == "instruct":
            return self.instruct(data)
        if action == "stop":
            with self.lock:
                self.cancel.set()

                def pause(doc):
                    for node in self._instructions(doc):
                        node.metadata["instruction_status"] = "paused"

                self._instruction_edit(pause, "Pause document instructions")
                self.status = (
                    "stopping"
                    if self.worker and self.worker.is_alive() and not self._worker_retired
                    else "stopped"
                )
            return self.state()
        doc, revision = self.store.read()
        if data.get("revision") != revision:
            raise Conflict("Document changed; reload before applying this action")
        if action == "recover-history":
            with self.lock:
                if self.worker and self.worker.is_alive() and not self._worker_retired:
                    raise Conflict("Stop the active operation before repairing history")
                self.store.recover_history(revision)
                self.storage_fault = None
                self.error = None
                self.status = "ready"
                if self.result:
                    self.result["storage_recovered"] = True
            return self.state()
        if action in {"checkpoint", "restore-state"}:
            from .checkpoints import Checkpoints

            with self.lock:
                if self.worker and self.worker.is_alive() and not self._worker_retired:
                    raise Conflict(
                        "Stop the active run or evaluation before checkpointing or forking"
                    )
                checkpoints = Checkpoints(self.store)
                if action == "checkpoint":
                    checkpoints.create(revision, data.get("message", "Human workspace checkpoint"))
                else:
                    if self.runtime_factory is None:
                        raise ValueError("Forking requires a configured runtime factory")
                    destination = (
                        self.store.path.parent
                        / ("." + self.store.path.name + ".forks")
                        / secrets.token_hex(12)
                    )
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    fork = checkpoints.restore(data["commit"], destination)
                    executor, engine_factory = self.runtime_factory(fork)
                    self._executors.append(executor)
                    old_team = getattr(self.executor, "team", None)
                    if old_team is not None:
                        old_team.close()
                    self.native.close()
                    self.store, self.executor, self.engine_factory = fork, executor, engine_factory
                    self.selected_model = getattr(engine_factory, "default_model", None)
                    self.active_model = None
                    self.status, self.error, self.result = "ready", None, None
            return self.state()
        if action == "run":
            if self.engine_factory is None:
                raise ValueError("Configure a provider before running the agent")
            steps = int(data.get("steps", 10))
            if not 1 <= steps <= 1000:
                raise ValueError("Steps must be between 1 and 1000")
            with self.lock:
                selected = self._resolve_model(data.get("model"))
                waiting = self._instructions(doc)
                if waiting and not any(
                    (n.metadata.get("instruction_model") or self.selected_model) == selected
                    for n in waiting
                ):
                    raise Conflict(
                        "Pending instructions are bound to another model; select it to resume"
                    )
                if self.worker and self.worker.is_alive() and not self._worker_retired:
                    raise Conflict("A run or evaluation is already active")
                self.selected_model = selected
                self.active_model = selected
                self.start(
                    (lambda: self._run_instructions(selected))
                    if waiting
                    else lambda: self._run_engine(steps, selected)
                )
        elif action == "eval":
            if self.executor is None:
                raise ValueError("Evaluation is unavailable")
            address = data["address"]
            self.start(lambda: self.executor(address, revision, cancel_event=self.cancel))
        elif action == "restore":
            self.store.restore(data["commit"], revision)
        else:
            if action == "insert":
                doc.insert(
                    Node(
                        id=data.get("id") or "n_" + secrets.token_hex(6),
                        kind=data.get("kind", "markdown"),
                        source=data["source"],
                        language=data.get("language", "python"),
                    ),
                    data.get("after"),
                )
            elif action == "update":
                doc.update(data["address"], **data["changes"])
            elif action == "delete":
                doc.delete(data["address"])
            elif action == "move":
                doc.move(data["address"], data["after"])
            else:
                raise ValueError("Unknown action")
            self.store.save(doc, revision, "Human " + action)
        return self.state()


def make_server(app: Application, host="127.0.0.1", port=8765, allowed_hosts=()):
    static = Path(__file__).with_name("static")

    class BrowserServer(ThreadingHTTPServer):
        # JupyterLab fetches many independent bundles on an initial page load.
        # Set before HTTPServer binds/activates its listening socket.
        request_queue_size = 128

    server = BrowserServer((host, port), BaseHTTPRequestHandler)
    permitted = {f"{host}:{server.server_port}", f"localhost:{server.server_port}", *allowed_hosts}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def respond(self, status, payload, content_type="application/json", headers=()):
            body = json.dumps(payload).encode() if content_type == "application/json" else payload
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            # Native password-form POSTs need Origin; no-referrer makes Chromium
            # send a null Origin on that navigation. Never send cross-origin refs.
            self.send_header("Referrer-Policy", "same-origin")
            for key, value in headers:
                self.send_header(key, value)
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
            )
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def session(self):
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get("Cookie", ""))
                value = cookie.get("docloop_session")
                return value.value if value else ""
            except Exception:
                return ""

        def logged_in(self):
            if app.tailscale_login is not None:
                identities = self.headers.get_all("Tailscale-User-Login", [])
                try:
                    peer = ipaddress.ip_address(self.client_address[0])
                except ValueError:
                    return False
                return (
                    len(identities) == 1
                    and identities[0] == app.tailscale_login
                    and any(peer in network for network in app.trusted_proxy_networks)
                )
            return app.access_token is None or app.sessions.get(self.session(), 0) > time.time()

        def matching_origin(self):
            return self.headers.get("Host") in permitted and self.headers.get("Origin") in {
                "http://" + self.headers["Host"],
                "https://" + self.headers["Host"],
            }

        def authorized(self, write=False):
            if self.headers.get("Host") not in permitted:
                self.respond(403, {"error": "Host is not allowed"})
                return False
            if not self.logged_in():
                self.respond(401, {"error": "Sign in required"})
                return False
            if not secrets.compare_digest(self.headers.get("X-Docloop-Token", ""), app.token):
                self.respond(403, {"error": "Session token required"})
                return False
            if write and not self.matching_origin():
                self.respond(403, {"error": "Matching Origin required"})
                return False
            return True

        def native_request(self):
            if self.headers.get("Host") not in permitted:
                self.respond(403, {"error": "Host is not allowed"})
                return
            if not self.logged_in():
                self.respond(401, {"error": "Sign in required"})
                return
            if (
                self.command not in {"GET", "HEAD"}
                or self.headers.get("Upgrade", "").lower() == "websocket"
            ) and not self.matching_origin():
                self.respond(403, {"error": "Matching Origin required"})
                return
            try:
                app.native.proxy(self)
            except (BrokenPipeError, ConnectionResetError):
                self.close_connection = True
            except (OSError, ValueError) as exc:
                if getattr(self, "native_response_started", False):
                    self.close_connection = True
                else:
                    self.respond(502, {"error": str(exc)})

        def do_HEAD(self):
            if urlsplit(self.path).path.startswith("/jupyter/"):
                self.native_request()
            else:
                self.respond(404, {"error": "Not found"})

        def do_PUT(self):
            if urlsplit(self.path).path.startswith("/jupyter/"):
                self.native_request()
            else:
                self.respond(404, {"error": "Not found"})

        do_PATCH = do_PUT
        do_DELETE = do_PUT

        def do_GET(self):
            target = urlsplit(self.path)
            if target.path.startswith("/jupyter/"):
                self.native_request()
                return
            if target.path.startswith("/api/"):
                if not self.authorized():
                    return
                try:
                    query = parse_qs(target.query)
                    if target.path == "/api/state":
                        result = app.state()
                    elif target.path == "/api/history":
                        result = app.store.history()
                    elif target.path == "/api/conversation":
                        result = app.conversation(
                            selection=query.get("selection", ["next"])[0],
                            before=query.get("before", [None])[0],
                            limit=int(query.get("limit", [50])[0]),
                        )
                    elif target.path in {"/api/checkpoints", "/api/checkpoint", "/api/state-diff"}:
                        from .checkpoints import Checkpoints

                        checkpoints = Checkpoints(app.store)
                        if target.path == "/api/checkpoints":
                            result = checkpoints.history()
                        elif target.path == "/api/checkpoint":
                            result = checkpoints.inspect(query["commit"][0])
                        else:
                            result = {
                                "diff": checkpoints.diff(query["older"][0], query["newer"][0])
                            }
                    elif target.path == "/api/version":
                        doc = decode(app.store.version(query["commit"][0]), app.store.path.suffix)
                        result = {"nodes": [n.value() for n in doc.nodes], "metadata": doc.metadata}
                    elif target.path == "/api/diff":
                        result = {"diff": app.store.diff(query["older"][0], query["newer"][0])}
                    else:
                        self.respond(404, {"error": "Not found"})
                        return
                    self.respond(200, result)
                except SaveFailure as exc:
                    self.respond(503, storage_error(exc))
                except (ValueError, KeyError) as exc:
                    self.respond(400, {"error": str(exc)})
                return
            if self.headers.get("Host") not in permitted:
                self.respond(403, {"error": "Host is not allowed"})
                return
            if not self.logged_in():
                if target.path == "/" and app.tailscale_login is None:
                    self.respond(
                        200, (static / "login.html").read_bytes(), "text/html; charset=utf-8"
                    )
                else:
                    self.respond(401, {"error": "Sign in required"})
                return
            assets = {
                "/": ("index.html", "text/html; charset=utf-8"),
                "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                "/native.js": ("native.js", "text/javascript; charset=utf-8"),
                "/style.css": ("style.css", "text/css; charset=utf-8"),
            }
            if target.path not in assets:
                self.respond(404, {"error": "Not found"})
                return
            name, mime = assets[target.path]
            body = (
                (static / name).read_bytes().replace(b"DOCLOOP_SESSION_TOKEN", app.token.encode())
            )
            self.respond(200, body, mime)

        def do_POST(self):
            if urlsplit(self.path).path.startswith("/jupyter/"):
                self.native_request()
                return
            if self.path == "/login":
                if app.tailscale_login is not None:
                    self.respond(401, {"error": "Managed Tailscale proxy identity required"})
                    return
                if not self.matching_origin():
                    self.respond(403, {"error": "Matching Origin required"})
                    return
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                    if not 0 < size <= 4096:
                        raise ValueError("Invalid login request")
                    supplied = parse_qs(self.rfile.read(size).decode()).get("access_token", [""])[0]
                except (ValueError, UnicodeError):
                    self.respond(400, {"error": "Invalid login request"})
                    return
                if app.access_token is None or not secrets.compare_digest(
                    supplied.encode(), app.access_token.encode()
                ):
                    self.respond(401, {"error": "Invalid access token"})
                    return
                now = time.time()
                with app.lock:
                    app.sessions = {k: v for k, v in app.sessions.items() if v > now}
                    session = secrets.token_urlsafe(32)
                    app.sessions[session] = now + 28800
                secure = "; Secure" if self.headers.get("Origin", "").startswith("https://") else ""
                self.respond(
                    303,
                    b"",
                    "text/plain",
                    [
                        ("Location", "/"),
                        (
                            "Set-Cookie",
                            f"docloop_session={session}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800{secure}",
                        ),
                    ],
                )
                return
            if not self.authorized(write=True):
                return
            if self.path == "/api/logout":
                with app.lock:
                    app.sessions.pop(self.session(), None)
                self.respond(
                    200,
                    {"ok": True},
                    headers=[
                        (
                            "Set-Cookie",
                            "docloop_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0",
                        )
                    ],
                )
                return
            if self.path != "/api/action":
                self.respond(404, {"error": "Not found"})
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 4_000_000:
                    raise ValueError("Request must be between 1 byte and 4 MB")
                data = json.loads(self.rfile.read(size))
                self.respond(200, app.mutate(data))
            except SaveFailure as exc:
                self.respond(503, storage_error(exc))
            except Conflict as exc:
                self.respond(409, {"error": str(exc)})
            except (ValueError, KeyError, TypeError) as exc:
                self.respond(400, {"error": str(exc)})

    server.RequestHandlerClass = Handler
    return server
