"""Fresh Chat Completions requests, including LLMQ's metered text envelope."""

from __future__ import annotations

import http.client
import json
import os
import socket
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

PYTHON_TEXT_PROTOCOL = """Transport contract for this text-only provider endpoint:
Return a JSON object with exactly calls, note, and done. calls is either [] or one
object {"op":"run_python","code":"Python source"}. note is a string; done is a boolean.
When finished, return {"calls":[],"note":"Your answer","done":true}.
Return code as data for the caller to evaluate; this provider has no execution tools.
Do not use markdown fences or call any other operation.
"""


@dataclass
class Reply:
    calls: list[dict]
    note: str = ""
    done: bool = False
    usage: dict | None = None


def parse_reply(response: dict, *, python_tool=False, text_tools=False) -> Reply:
    message = response["choices"][0]["message"]
    if message.get("tool_calls"):
        calls = []
        for call in message["tool_calls"]:
            function = call["function"]
            arguments = json.loads(function["arguments"])
            if python_tool and (
                function["name"] != "run_python"
                or not isinstance(arguments, dict)
                or set(arguments) != {"code"}
                or not isinstance(arguments["code"], str)
            ):
                raise ValueError("Provider must call only run_python(code)")
            calls.append({**arguments, "op": function["name"]})
        return Reply(calls, message.get("content") or "", False, response.get("usage"))
    content = (message.get("content") or "").strip()
    if python_tool and not text_tools:
        return Reply([], content, True, response.get("usage"))
    if content.startswith("```") and content.endswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    value = json.loads(content)
    if not isinstance(value, dict) or set(value) - {"calls", "note", "done"}:
        raise ValueError("Reply must contain only calls, note and done")
    calls, note, done = value.get("calls", []), value.get("note", ""), value.get("done", False)
    if not isinstance(calls, list) or not isinstance(note, str) or type(done) is not bool:
        raise ValueError("Invalid reply envelope")
    if python_tool and (
        len(calls) > 1
        or any(
            not isinstance(call, dict)
            or set(call) != {"op", "code"}
            or call["op"] != "run_python"
            or not isinstance(call["code"], str)
            for call in calls
        )
        or (done and calls)
    ):
        raise ValueError("Provider must call only run_python(code), or finish without calls")
    return Reply(calls, note, done, response.get("usage"))


class ChatProvider:
    def __init__(
        self,
        endpoint: str,
        model: str,
        api_key: str = "",
        *,
        timeout: float = 240,
        headers: dict | None = None,
        max_body_bytes: int = 65536,
        tool_transport: str = "native",
    ):
        if not endpoint.startswith(("http://", "https://")):
            raise ValueError("Explicit HTTP(S) chat completions endpoint required")
        self.endpoint, self.model, self.api_key = endpoint, model, api_key
        self.timeout, self.headers, self.max_body_bytes = timeout, headers or {}, max_body_bytes
        if tool_transport not in {"native", "text"}:
            raise ValueError("Unknown provider tool transport")
        self.tool_transport = tool_transport

    @classmethod
    def from_env(cls, *, agent_id=None, model=None, environ=None):
        from .model_routes import ModelCatalog

        env = ModelCatalog(os.environ if environ is None else environ).environment(model)
        mode = env.get("DOCLOOP_PROVIDER", "llmq")
        model = env.get("DOCLOOP_MODEL", "")
        if not model:
            raise ValueError("Set DOCLOOP_MODEL to an explicitly selected metered model")
        if mode in {"llmq", "llmq-api"}:
            if env.get("OMNIGENT_QUOTA_ROUTE", "personal-llmq") != "personal-llmq":
                raise ValueError("LLMQ is a personal route; configure the explicit work provider")
            base = env.get("DOCLOOP_LLMQ_URL", "").rstrip("/")
            if not base:
                raise ValueError("Set DOCLOOP_LLMQ_URL to the guarded gateway mount; no fallback")
            if mode == "llmq-api":
                route = urlsplit(base)
                if (
                    not route.path.endswith(("/api/openrouter", "/api/vast"))
                    or route.query
                    or route.fragment
                    or route.username is not None
                ):
                    raise ValueError(
                        "llmq-api requires the configured /api/openrouter or /api/vast mount"
                    )
            endpoint = base + "/w/agent-infra/v1/chat/completions"
            key = env.get("DOCLOOP_API_KEY", env.get("LLMQ_API_KEY", ""))
            if not key and env.get("DOCLOOP_API_KEY_FILE"):
                key = Path(env["DOCLOOP_API_KEY_FILE"]).read_text().strip()
            if not key:
                raise ValueError("LLMQ API credential required")
            headers = {
                "X-LLM-Workstream": "agent-infra",
                "X-LLM-Project-ID": "agent-infra",
            }
            if mode == "llmq":
                headers["X-LLM-Agent-ID"] = agent_id or env.get(
                    "DOCLOOP_AGENT_ID", "document-harness"
                )
            # API gateway admission uses the authenticated token actor. A document
            # agent ID is not that actor and would fail its optional assertion.
        elif mode == "chat":
            endpoint = env.get("DOCLOOP_ENDPOINT", "")
            key, headers = env.get("DOCLOOP_API_KEY", ""), {}
        else:
            raise ValueError("DOCLOOP_PROVIDER must be llmq, llmq-api or chat")
        return cls(
            endpoint,
            model,
            key,
            headers=headers,
            tool_transport="text" if mode == "llmq" else "native",
        )

    def complete(self, messages: list[dict], cancel_event=None, *, tools=None) -> Reply:
        # There is deliberately no message history or previous response ID here.
        text_tools = tools is not None and self.tool_transport == "text"
        if text_tools:
            from .python_harness import RUN_PYTHON

            if tools != [RUN_PYTHON]:
                raise ValueError("Text transport supports only run_python")
            messages = [{"role": "system", "content": PYTHON_TEXT_PROTOCOL}, *messages]
        body = json.dumps(
            {
                "model": self.model,
                "messages": messages,
                "stream": False,
                **(
                    {"tools": tools, "parallel_tool_calls": False}
                    if tools is not None and not text_tools
                    else {}
                ),
            },
            ensure_ascii=False,
        ).encode()
        if len(body) > self.max_body_bytes:
            raise ValueError(
                "Serialized request exceeds provider body budget; lower context budget"
            )
        headers = {"Content-Type": "application/json", **self.headers}
        if not any(key.lower() in {"idempotency-key", "x-request-id"} for key in headers):
            headers["Idempotency-Key"] = uuid.uuid4().hex
        if self.api_key:
            headers["Authorization"] = "Bearer " + self.api_key
        url = urlsplit(self.endpoint)
        connection_type = (
            http.client.HTTPSConnection if url.scheme == "https" else http.client.HTTPConnection
        )
        connection = connection_type(url.hostname, url.port, timeout=self.timeout)
        finished = threading.Event()

        def watch_cancel():
            while not finished.wait(0.05):
                if cancel_event is not None and cancel_event.is_set():
                    sock = connection.sock
                    if sock is not None:
                        try:
                            sock.shutdown(socket.SHUT_RDWR)
                        except OSError:
                            pass
                        connection.close()
                        return

        watcher = None
        if cancel_event is not None:
            if cancel_event.is_set():
                raise InterruptedError("Inference cancelled")
            watcher = threading.Thread(target=watch_cancel, daemon=True)
            watcher.start()
        try:
            path = url.path or "/"
            if url.query:
                path += "?" + url.query
            connection.request("POST", path, body=body, headers=headers)
            response = connection.getresponse()
            raw = response.read(2_000_001)
            if response.status >= 400:
                # Do not echo response bodies which may contain credentials or upstream details.
                raise RuntimeError(f"Provider HTTP {response.status} {response.reason}")
        finally:
            finished.set()
            connection.close()
            if watcher is not None:
                watcher.join(timeout=1)
        if len(raw) > 2_000_000:
            raise ValueError("Provider reply too large")
        return parse_reply(json.loads(raw), python_tool=tools is not None, text_tools=text_tools)
