"""Private container service entrypoint; configuration secrets remain mounted files."""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlsplit

from .cli import main as cli_main
from .document import Document, Node
from .store import Store


def personal_mcp_configuration(env):
    """Build a credential-free client config; the helper owns refresh state."""
    explicit = env.get("DOCLOOP_MCP_CONFIG")
    if env.get("DOCLOOP_PERSONAL_MCP_ENABLED", "0") != "1":
        return explicit
    if explicit:
        raise ValueError("Choose DOCLOOP_MCP_CONFIG or DOCLOOP_PERSONAL_MCP_ENABLED, not both")
    for name in (
        "PERSONAL_CLOUD_TOKEN_PATH",
        "PERSONAL_CLOUD_TOKEN_SEED",
        "PERSONAL_CLOUD_ROUTE_KEY_PATH",
        "PERSONAL_CLOUD_TOKEN_ENDPOINT",
        "PERSONAL_CLOUD_RESOURCE",
        "PERSONAL_CLOUD_CLIENT_ID",
    ):
        if not env.get(name):
            raise ValueError(f"Personal MCP requires {name}")
    for name in ("PERSONAL_CLOUD_TOKEN_ENDPOINT", "PERSONAL_CLOUD_RESOURCE"):
        url = urlsplit(env[name])
        if url.scheme != "https" or not url.hostname or url.username or url.password:
            raise ValueError(f"Personal MCP requires an HTTPS URL without userinfo for {name}")
    destination = Path(env["PERSONAL_CLOUD_TOKEN_PATH"]).parent / "servers.json"
    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    config = {
        "personal": {
            "url": env["PERSONAL_CLOUD_RESOURCE"],
            "headers_command": [sys.executable, "-m", "docloop.personal_mcp"],
        }
    }
    # Only paths and transport configuration belong here. Never read the seed,
    # route key or current grant into the notebook or generated client config.
    fd, temporary = tempfile.mkstemp(prefix=".servers-", dir=destination.parent)
    try:
        with os.fdopen(fd, "w") as handle:
            json.dump(config, handle)
            handle.write("\n")
        os.replace(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return str(destination)


def configure(environ=None):
    env = os.environ if environ is None else environ
    host = env.get("DOCLOOP_HOST", "0.0.0.0")
    token_file = env.get("DOCLOOP_ACCESS_TOKEN_FILE")
    from .web import tailscale_configuration

    login, _ = tailscale_configuration(
        env.get("DOCLOOP_TAILSCALE_LOGIN"), env.get("DOCLOOP_TRUSTED_PROXY_CIDRS")
    )
    if login and token_file:
        raise ValueError("Choose Tailscale identity or access-token authentication, not both")
    if host not in {"127.0.0.1", "localhost", "::1"} and not token_file and not login:
        raise ValueError(
            "Access-token or configured Tailscale identity authentication is required for a non-loopback service"
        )
    if token_file and len(Path(token_file).read_text().strip()) < 32:
        raise ValueError("Access token must contain at least 32 characters")
    mcp_config = personal_mcp_configuration(env)
    document = Path(env.get("DOCLOOP_DOCUMENT", "/data/notebook.ipynb")).resolve()
    workspace = Path(env.get("DOCLOOP_WORKSPACE", "/data/workspace")).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    store = Store(document)
    if not document.exists():
        nodes = [
            Node(
                "task",
                "markdown",
                "# Private document workspace\n\nEnter a task below. "
                "Agent context comes from this document; filesystem observations enter through evaluated cells.",
            )
        ]
        if env.get("DOCLOOP_DEMO", "0") == "1":
            nodes.append(
                Node(
                    "demo",
                    "code",
                    "from pathlib import Path\n"
                    "Path('hello.txt').write_text('Hello from the document workspace\\n')\n"
                    "print(Path('hello.txt').read_text())",
                )
            )
        store.save(Document(nodes), store.read()[1], "Initialize private service notebook")
    args = [
        "--workspace",
        str(workspace),
        "--environment",
        "local",
        "--timeout",
        env.get("DOCLOOP_TIMEOUT", "60"),
        "--steps",
        env.get("DOCLOOP_STEPS", "20"),
        "--budget-bytes",
        env.get("DOCLOOP_BUDGET_BYTES", "24000"),
    ]
    if mcp_config:
        args += ["--mcp-config", mcp_config]
    args += ["serve", str(document), "--host", host, "--port", env.get("DOCLOOP_PORT", "8765")]
    if token_file:
        args += ["--access-token-file", token_file]
    if login:
        args += [
            "--tailscale-login",
            login,
            "--trusted-proxy-cidrs",
            env["DOCLOOP_TRUSTED_PROXY_CIDRS"],
        ]
    for allowed_host in env.get("DOCLOOP_ALLOWED_HOSTS", "").split(","):
        if allowed_host.strip():
            args += ["--allowed-host", allowed_host.strip()]
    return args


def main():
    import signal

    def terminate(_signal, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, terminate)
    try:
        args = configure()
        # Chat endpoints as well as LLMQ may consume a mounted key. Never bake it
        # into the image, document, argv or a generated on-disk config.
        if os.environ.get("DOCLOOP_API_KEY_FILE") and not os.environ.get("DOCLOOP_API_KEY"):
            os.environ["DOCLOOP_API_KEY"] = (
                Path(os.environ["DOCLOOP_API_KEY_FILE"]).read_text().strip()
            )
        return cli_main(args)
    except (OSError, ValueError) as exc:
        import sys

        print(f"docloop service: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
