"""Three-way stable-address merge, also usable as a private Git merge driver."""

from __future__ import annotations

import argparse
import copy
import heapq
import os
import stat
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from .document import Document, Node
from .formats import decode, encode

_MISSING = object()


@dataclass(frozen=True)
class MergeConflict:
    address: str
    reason: str


@dataclass
class MergeResult:
    document: Document | None
    conflicts: list[MergeConflict]


def _merge_value(base, ours, theirs, address, conflicts):
    if ours == theirs:
        return copy.deepcopy(ours) if ours is not _MISSING else _MISSING
    if ours == base:
        return copy.deepcopy(theirs) if theirs is not _MISSING else _MISSING
    if theirs == base:
        return copy.deepcopy(ours) if ours is not _MISSING else _MISSING
    if isinstance(ours, dict) and isinstance(theirs, dict) and isinstance(base, dict):
        result = {}
        for key in sorted(base.keys() | ours.keys() | theirs.keys()):
            value = _merge_value(
                base.get(key, _MISSING),
                ours.get(key, _MISSING),
                theirs.get(key, _MISSING),
                f"{address}/{key}",
                conflicts,
            )
            if value is not _MISSING:
                result[key] = value
        return result
    reason = "delete/modify conflict" if ours is _MISSING or theirs is _MISSING else "both changed"
    conflicts.append(MergeConflict(address, reason))
    return _MISSING


def _order(nodes, base, ours, theirs, conflicts):
    """Merge relative ordering; incompatible moves form a cycle, never guessed away."""
    indexes = [
        {node.id: index for index, node in enumerate(doc.nodes)} for doc in (base, ours, theirs)
    ]
    edges = {address: set() for address in nodes}
    indegree = dict.fromkeys(nodes, 0)
    ids = sorted(nodes)
    for index, left in enumerate(ids):
        for right in ids[index + 1 :]:
            relations = [
                mapping[left] < mapping[right] if left in mapping and right in mapping else None
                for mapping in indexes
            ]
            before, first, second = relations
            if first is None:
                chosen = second
            elif second is None or first == second:
                chosen = first
            elif before is None:
                conflicts.append(
                    MergeConflict(f"order/{left}/{right}", "incompatible insertion order")
                )
                continue
            else:
                chosen = second if first == before else first
            if chosen is None:
                # Separate branches inserted at the same boundary. ID sort breaks ties.
                continue
            early, late = (left, right) if chosen else (right, left)
            edges[early].add(late)
            indegree[late] += 1
    ready = [address for address in ids if indegree[address] == 0]
    heapq.heapify(ready)
    ordered = []
    while ready:
        address = heapq.heappop(ready)
        ordered.append(address)
        for successor in sorted(edges[address]):
            indegree[successor] -= 1
            if indegree[successor] == 0:
                heapq.heappush(ready, successor)
    if len(ordered) != len(nodes):
        cycle = ",".join(address for address in ids if indegree[address])
        conflicts.append(MergeConflict("order", "incompatible moves involving " + cycle))
    return ordered


def _parents(doc):
    parents = {}
    stack = []
    for node in doc.nodes:
        if node.kind == "section":
            while stack and stack[-1].level >= node.level:
                stack.pop()
        parents[node.id] = stack[-1].id if stack else None
        if node.kind == "section":
            stack.append(node)
    return parents


def merge_documents(base: Document, ours: Document, theirs: Document) -> MergeResult:
    """Return a merged document or explicit conflicts; inputs are never mutated."""
    for doc in (base, ours, theirs):
        doc.validate()
    conflicts = []
    maps = [{node.id: node for node in doc.nodes} for doc in (base, ours, theirs)]
    base_nodes, our_nodes, their_nodes = maps
    nodes = {}
    for address in sorted(base_nodes.keys() | our_nodes.keys() | their_nodes.keys()):
        versions = [mapping.get(address) for mapping in maps]
        original, first, second = versions
        if original is not None and ((first is None) != (second is None)):
            retained_doc = theirs if first is None else ours
            retained_ids = [node.id for node in retained_doc.nodes if node.id in base_nodes]
            common = set(retained_ids)
            base_ids = [node.id for node in base.nodes if node.id in common]
            # A deletion must not silently win over the other branch's relocation.
            before = {item for item in base_ids[: base_ids.index(address)]}
            after = {item for item in retained_ids[: retained_ids.index(address)]}
            if before != after:
                conflicts.append(MergeConflict(address, "delete/reorder conflict"))
        values = [node.value() if node is not None else _MISSING for node in versions]
        conflicts_before = len(conflicts)
        value = _merge_value(*values, address, conflicts)
        if value is _MISSING or len(conflicts) != conflicts_before:
            continue
        if original and first and second:
            original_program = (original.source, original.language)
            first_program = (first.source, first.language)
            second_program = (second.source, second.language)
            if first_program != second_program and (
                (
                    first_program != original_program
                    and second.outputs != original.outputs
                    and second.outputs
                )
                or (
                    second_program != original_program
                    and first.outputs != original.outputs
                    and first.outputs
                )
            ):
                conflicts.append(
                    MergeConflict(
                        address + "/outputs", "execution results conflict with changed program"
                    )
                )
        node = Node(**value)
        # Keep a native representation only when it describes the complete merged node.
        for candidate in (first, second, original):
            if candidate is not None and candidate.value() == value:
                node.original = candidate.original
                node.original_digest = candidate.original_digest
                break
        nodes[address] = node
    metadata = _merge_value(base.metadata, ours.metadata, theirs.metadata, "metadata", conflicts)
    extra = _merge_value(base.extra, ours.extra, theirs.extra, "extra", conflicts)
    ordered = _order(nodes, base, ours, theirs, conflicts)
    if conflicts:
        return MergeResult(None, conflicts)
    merged = Document([nodes[address] for address in ordered], metadata, extra)
    merged.validate()
    parent_maps = [_parents(doc) for doc in (base, ours, theirs)]
    for address, actual_parent in _parents(merged).items():
        expected_parent = _merge_value(
            *(mapping.get(address, _MISSING) for mapping in parent_maps),
            address + "/parent",
            conflicts,
        )
        if expected_parent is not _MISSING and actual_parent != expected_parent:
            conflicts.append(
                MergeConflict(address + "/parent", "merged order would change section ownership")
            )
    return MergeResult(None, conflicts) if conflicts else MergeResult(merged, [])


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", help="Git %O file")
    parser.add_argument("ours", help="Git %A file; replaced only on success")
    parser.add_argument("theirs", help="Git %B file")
    parser.add_argument("path", nargs="?", help="Git %P original filename (format inference)")
    parser.add_argument("--format", choices=["org", "ipynb"])
    args = parser.parse_args(argv)
    suffix = "." + args.format if args.format else Path(args.path or args.ours).suffix
    temporary = None
    try:
        paths = [Path(path) for path in (args.base, args.ours, args.theirs)]
        contents = [path.read_bytes() for path in paths]
        result = merge_documents(*(decode(content.decode("utf-8"), suffix) for content in contents))
        if result.conflicts:
            for conflict in result.conflicts:
                print(
                    f"docloop merge conflict [{conflict.address}]: {conflict.reason}",
                    file=sys.stderr,
                )
            return 1
        output = encode(result.document, suffix, stabilize=True).encode("utf-8")
        ours = paths[1]
        descriptor, temporary = tempfile.mkstemp(prefix=".docloop-merge-", dir=ours.parent)
        with os.fdopen(descriptor, "wb") as stream:
            os.fchmod(stream.fileno(), stat.S_IMODE(ours.stat().st_mode))
            stream.write(output)
            stream.flush()
            os.fsync(stream.fileno())
        if ours.read_bytes() != contents[1]:
            raise ValueError("ours changed while merging; result not written")
        os.replace(temporary, ours)
        temporary = None
        return 0
    except (ValueError, TypeError, KeyError, OSError) as exc:
        print(f"docloop merge failed: {exc}", file=sys.stderr)
        return 1
    finally:
        if temporary is not None:
            os.unlink(temporary)


if __name__ == "__main__":
    raise SystemExit(main())
