"""Virtual MCP endpoint for the current Omnigent turn's explicit tool inventory."""

from __future__ import annotations

import asyncio
import concurrent.futures
import threading
import time

from .document import Node, canonical, pretty, pretty_text
from .store import Conflict
from .tool_catalog import DISCOVERY_HELP, discover


def inventory(tools):
    result, names = [], set()
    for tool in tools or []:
        if not isinstance(tool, dict) or tool.get("type") != "function":
            continue
        function = tool.get("function", tool)
        if not isinstance(function, dict):
            raise ValueError("Function tool definition must be an object")
        name = function.get("name")
        if not isinstance(name, str) or not name or name in names:
            raise ValueError("Function tool names must be unique nonempty strings")
        description = function.get("description", "")
        parameters = function.get("parameters", {"type": "object", "properties": {}})
        if not isinstance(description, str) or not isinstance(parameters, dict):
            raise ValueError("Function description/schema has an invalid type")
        # Only the advertised function contract crosses into the document.
        # Connection headers, URLs, credentials and executor extensions are excluded.
        value = {"name": name, "description": description, "parameters": parameters}
        result.append(value)
        names.add(name)
    return result


class ToolBridge:
    def __init__(self, ctx, tools, agent, timeout=60):
        self.ctx, self.agent, self.timeout = ctx, agent, timeout
        if not 0 < timeout <= 300:
            raise ValueError("DOCLOOP_OMNIGENT_TOOL_TIMEOUT must be greater than 0 and at most 300")
        self.tools = sorted(inventory(tools), key=lambda tool: tool["name"])
        self.names = {tool["name"] for tool in self.tools}
        self.loop = asyncio.get_running_loop()
        self.closed = threading.Event()
        self.lock = threading.Lock()
        self.pending = {}

    def materialize(self, store):
        from .python_objects import STATE_KEY, enabled

        for _ in range(10):
            doc, revision = store.read()
            if not enabled(doc):
                break
            if doc.metadata[STATE_KEY].get("tools") == self.tools:
                return
            doc.metadata[STATE_KEY]["tools"] = self.tools
            try:
                store.save(doc, revision, "Refresh Python tool objects")
                return
            except Conflict:
                continue
        else:
            raise Conflict("Document busy while refreshing Python tools")
        source = pretty(
            {
                "server": "omnigent",
                **discover(self.tools, {"op": "list"}),
                "usage": DISCOVERY_HELP.replace("SERVER", "omnigent"),
            }
        )
        for _ in range(10):
            doc, revision = store.read()
            try:
                node = doc.get("omnigent-tools")
                if node.source == source:
                    return
                doc.update(node.id, source=source)
            except ValueError:
                doc.insert(
                    Node(
                        "omnigent-tools",
                        "raw",
                        source,
                        language="json",
                        metadata={"docloop_role": "tool_inventory"},
                    )
                )
            try:
                store.save(doc, revision, "Refresh current Omnigent function inventory")
                return
            except Conflict:
                continue
        raise Conflict("Document busy while refreshing tool inventory")

    def __call__(
        self, request, *, call_id, cancel_event=None, timeout=60, max_output=1_000_000, archive=None
    ):
        if archive is not None and max_output < 256:
            raise ValueError("Archived tool results require a payload budget of at least 256 bytes")

        def output_result(output, limit, receipt, status="ok"):
            return self._output(pretty_text(output), limit, receipt, archive=archive, status=status)

        if not isinstance(request, dict):
            raise ValueError("Invalid virtual MCP request fields")
        if request.get("server") != "omnigent":
            raise ValueError("Virtual MCP endpoint is omnigent")
        if self.closed.is_set() or (cancel_event and cancel_event.is_set()):
            return output_result(
                "Cancelled before external dispatch",
                max_output,
                {"dispatched": False},
                status="cancelled",
            )
        operation = request.get("op", "call")
        if operation in {"list", "describe"}:
            return output_result(
                pretty(discover(self.tools, request)), max_output, {"dispatched": False}
            )
        if operation != "call" or set(request) - {"server", "op", "tool", "arguments"}:
            raise ValueError("Virtual Omnigent MCP supports list, describe and call")
        name, arguments = request.get("tool"), request.get("arguments", {})
        if name not in self.names:
            raise ValueError("Tool is absent from the current Omnigent function inventory")
        if not isinstance(arguments, dict) or len(canonical(arguments).encode()) > 65536:
            raise ValueError("Tool arguments must be an object of at most 65536 bytes")
        dispatched, finished = threading.Event(), threading.Event()

        async def dispatch():
            try:
                if (
                    self.closed.is_set()
                    or self.ctx.cancelled.is_set()
                    or (cancel_event and cancel_event.is_set())
                ):
                    raise asyncio.CancelledError
                dispatched.set()
                return await self.ctx.dispatch_tool(call_id, name, canonical(arguments), self.agent)
            finally:
                finished.set()

        future = asyncio.run_coroutine_threadsafe(dispatch(), self.loop)
        with self.lock:
            self.pending[future] = finished
        deadline = time.monotonic() + min(timeout, self.timeout)
        try:
            while True:
                if self.closed.is_set() or (cancel_event and cancel_event.is_set()):
                    reason = "Cancelled"
                    break
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    reason = "Timed out"
                    break
                try:
                    output = future.result(timeout=min(0.05, remaining))
                    return output_result(
                        str(output), max_output, {"dispatched": dispatched.is_set()}
                    )
                except concurrent.futures.TimeoutError:
                    continue
                except concurrent.futures.CancelledError:
                    reason = "Cancelled"
                    break
                except Exception:
                    reason = "Dispatch failed"
                    break
            output = reason + (
                " after external dispatch; outcome unknown. Inspect external state before an explicit retry."
                if dispatched.is_set()
                else " before external dispatch."
            )
            return output_result(
                output,
                max_output,
                {"dispatched": dispatched.is_set()},
                status="unknown" if dispatched.is_set() else "cancelled",
            )
        finally:
            if not future.done():
                future.cancel()
            # Main-loop cancellation runs the SDK's pending-call cleanup. This
            # wait is on an evaluator worker, never on the main async loop.
            finished.wait(1)
            with self.lock:
                self.pending.pop(future, None)

    @staticmethod
    def _output(output, limit, receipt, *, archive=None, status="ok"):
        if archive is not None:
            result = {"status": status, "output": output, "receipt": receipt}
            if len(canonical(result).encode()) <= limit:
                return result
            raw = output.encode()
            receipt = {
                **receipt,
                "output_ref": archive(output),
                "output_truncated": True,
                "output_bytes": len(raw),
            }
            low, high = 0, min(len(raw), limit)

            def envelope(size):
                return {
                    "status": status,
                    "output": raw[:size].decode("utf-8", "ignore"),
                    "receipt": receipt,
                }

            if len(canonical(envelope(0)).encode()) > limit:
                raise ValueError("Tool receipt exceeds result payload budget; observation archived")
            while low < high:
                middle = (low + high + 1) // 2
                if len(canonical(envelope(middle)).encode()) <= limit:
                    low = middle
                else:
                    high = middle - 1
            return envelope(low)
        encoded = output.encode()
        if len(encoded) > limit:
            if archive is not None:
                receipt = {**receipt, "output_ref": archive(output)}
            marker = b"\n[Omnigent tool output truncated]"
            output = (
                encoded[: max(0, limit - len(marker))].decode("utf-8", "ignore")
                + marker[:limit].decode()
            )
            receipt = {**receipt, "output_truncated": True, "output_bytes": len(encoded)}
        return {"status": status, "output": output, "receipt": receipt}

    def cancel(self):
        self.closed.set()
        with self.lock:
            for future in self.pending:
                future.cancel()

    async def close(self):
        self.cancel()
        deadline = time.monotonic() + 1
        while time.monotonic() < deadline:
            with self.lock:
                pending = list(self.pending.values())
            if all(event.is_set() for event in pending):
                break
            await asyncio.sleep(0.01)
