"""Jupyter kernel with one serializable task namespace for browser and agent cells."""

from __future__ import annotations

import ast
import os
from contextlib import contextmanager

from ipykernel.ipkernel import IPythonKernel

from .python_checkpoint import CheckpointStore, RestorePython
from .python_objects import state
from .store import Store


def evaluate(code, namespace, filename="<run_python>"):
    from IPython.display import display

    tree = ast.parse(code, filename=filename)
    last = tree.body.pop() if tree.body and isinstance(tree.body[-1], ast.Expr) else None
    exec(compile(tree, filename, "exec"), namespace, namespace)
    if last is not None:
        value = eval(compile(ast.Expression(last.value), filename, "eval"), namespace, namespace)
        if value is not None:
            display(value)


class Runtime:
    def __init__(self):
        self.checkpoints = CheckpointStore(Store(os.environ["DOCLOOP_NATIVE_DOCUMENT"]))
        self.module = self.checkpoints.load()

    def execute(self, code):
        namespace = self.module.__dict__
        notebook, tools, conversation = state()
        notebook.namespace = namespace
        namespace.update(
            notebook=notebook, tools=tools, conversation=conversation, team=notebook.team
        )
        restored_from = None
        try:
            evaluate(code, namespace)
        except RestorePython as restore:
            replacement = self.checkpoints.load(restore.args[0])
            self.module = replacement
            restored_from = restore.args[0]
            print(
                "Restored Python namespace "
                + restored_from[:12]
                + ". Notebook and filesystem retain their current versions."
            )
        finally:
            self.checkpoints.save(self.module, code=code, restored_from=restored_from)


class PythonKernel(IPythonKernel):
    _docloop_runtime = None

    @property
    def kernel_info(self):
        info = super().kernel_info
        # Debugger source mapping is not implemented for the serializable namespace.
        info["supported_features"] = [
            value for value in info["supported_features"] if value != "debugger"
        ]
        return info

    def _execute(self, code):
        if self._docloop_runtime is None:
            self._docloop_runtime = Runtime()
        return self._docloop_runtime.execute(code)

    @contextmanager
    def _editor_namespace(self):
        # Execution uses a separate module so IPython's transient machinery never
        # becomes checkpoint state. Editor requests must nevertheless see that
        # module, including a replacement selected by namespace restoration.
        if self._docloop_runtime is None:
            self._docloop_runtime = Runtime()
        shell = self.shell
        completer = shell.Completer
        previous = (
            shell.user_ns,
            shell.user_module,
            completer.namespace,
            completer.global_namespace,
        )
        module = self._docloop_runtime.module
        try:
            shell.user_ns = module.__dict__
            shell.user_module = module
            completer.namespace = module.__dict__
            completer.global_namespace = module.__dict__
            yield
        finally:
            (
                shell.user_ns,
                shell.user_module,
                completer.namespace,
                completer.global_namespace,
            ) = previous

    def do_complete(self, code, cursor_pos):
        with self._editor_namespace():
            return super().do_complete(code, cursor_pos)

    def do_inspect(self, code, cursor_pos, detail_level=0, omit_sections=()):
        with self._editor_namespace():
            return super().do_inspect(code, cursor_pos, detail_level, omit_sections)

    async def do_execute(
        self,
        code,
        silent,
        store_history=True,
        user_expressions=None,
        allow_stdin=False,
        *,
        cell_meta=None,
        cell_id=None,
    ):
        self.shell.user_ns["_docloop_execute"] = self._execute
        return await super().do_execute(
            "_docloop_execute(" + repr(code) + ")",
            silent,
            store_history,
            user_expressions,
            allow_stdin,
            cell_meta=cell_meta,
            cell_id=cell_id,
        )


if __name__ == "__main__":
    from ipykernel.kernelapp import IPKernelApp

    IPKernelApp.launch_instance(kernel_class=PythonKernel)
