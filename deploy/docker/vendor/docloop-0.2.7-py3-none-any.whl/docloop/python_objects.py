"""Python objects used inside the session kernel, never provider tool schemas."""

from __future__ import annotations

import json
import os
import socket
import time
import uuid
from collections.abc import Mapping

from .document import Node, canonical, digest
from .document import pretty as pretty
from .store import Conflict, Store
from .tool_catalog import discover

STATE_KEY = "docloop_python_state"
CONVERSATION_ROLES = {"human", "agent", "user_instruction"}


def enabled(doc):
    return doc.metadata.get(STATE_KEY, {}).get("version") == 1


def conversation_from(doc):
    return [
        {
            "id": n.id,
            "role": "assistant" if n.metadata.get("docloop_role") == "agent" else "user",
            "content": n.source,
            "status": (
                "after_execution"
                if n.metadata.get("docloop_response_actions")
                else n.metadata.get("instruction_status")
            ),
            **(
                {"actions": n.metadata["docloop_response_actions"]}
                if n.metadata.get("docloop_response_actions")
                else {}
            ),
        }
        for n in doc.nodes
        if n.metadata.get("docloop_role") in CONVERSATION_ROLES
    ]


def compact_conversation(conversation, recent=4, chars=400):
    # Reserve the first slot for the latest human request, even after many agent
    # notes. It must precede those notes so an output preview cannot hide it again.
    indices = list(reversed(range(len(conversation))))
    latest_user = next((i for i in indices if conversation[i].get("role") == "user"), None)
    if latest_user is not None:
        indices.remove(latest_user)
        indices.insert(0, latest_user)
    return {
        "total": len(conversation),
        "order": "latest-user-then-newest-first",
        "messages": [
            {
                # Keep outcome and action addresses before potentially long prose.
                **{key: value for key, value in message.items() if key != "content"},
                "content": message["content"][:chars],
                "omitted_chars": max(0, len(message["content"]) - chars),
            }
            for message in (conversation[i] for i in indices[: max(0, recent)])
        ],
    }


VIEW_SOURCES = {
    "tools-view": """from docloop.python_objects import state, pretty
notebook, tools, conversation = state()

def view_tools(tools):
    return tools.folders()

print(pretty(view_tools(tools)))""",
    "conversation-view": """from docloop.python_objects import state, pretty, compact_conversation
notebook, tools, conversation = state()

def view_conversation(conversation):
    return compact_conversation(conversation, recent=4, chars=400)

print(pretty(view_conversation(conversation)))""",
}


def enable(store):
    doc, revision = store.read()
    if enabled(doc):
        return revision
    for address in VIEW_SOURCES:
        if any(n.id == address for n in doc.nodes):
            raise ValueError(f"Reserved Python view address already exists: {address}")
    doc.metadata[STATE_KEY] = {"version": 1, "tools": []}
    if store.path.suffix == ".ipynb":
        doc.metadata["kernelspec"] = {
            "name": "docloop-python",
            "display_name": "Docloop Python",
            "language": "python",
        }
    for address, source in VIEW_SOURCES.items():
        doc.insert(Node(address, "code", source, metadata={"docloop_view": address}))
    return store.save(doc, revision, "Enable Python state and editable context views")


class Remote:
    def __init__(self, path):
        self.path = path

    def call(self, method, **arguments):
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
            connection.settimeout(65)
            connection.connect(os.environ.get("DOCLOOP_PYTHON_SOCKET", self.path))
            connection.sendall(
                (canonical({"method": method, "arguments": arguments}) + "\n").encode()
            )
            with connection.makefile("rb") as stream:
                raw = stream.readline(16_000_001)
        if len(raw) > 16_000_000 or not raw.endswith(b"\n"):
            raise ValueError("Python object response exceeds its transport limit")
        result = json.loads(raw)
        if "error" in result:
            raise RuntimeError(result["error"])
        return result["result"]


class Tool:
    def __init__(self, definition, remote):
        self.name = definition["name"]
        self.parameters = definition["parameters"]
        self.__doc__ = definition["description"]
        self._remote = remote

    def __repr__(self):
        return f"<tool {self.name}>"

    def __call__(self, **arguments):
        return self._remote.call("tool", name=self.name, arguments=arguments)


class Connector:
    def __init__(self, name, remote):
        self.name, self._remote = name, remote

    def __repr__(self):
        return (
            f"<MCP connector {self.name}; .find(text), .describe(name), .call(name, **arguments)>"
        )

    def find(self, text="", **options):
        return self._remote.call(
            "mcp", server=self.name, op="list", filter=text, view="names", **options
        )

    def describe(self, name):
        return self._remote.call("mcp", server=self.name, op="describe", tool=name)

    def call(self, name, **arguments):
        return self._remote.call("mcp", server=self.name, op="call", tool=name, arguments=arguments)


class Tools(Mapping):
    def __init__(self, definitions, remote, servers=()):
        self._definitions = {t["name"]: t for t in definitions}
        self._remote = remote
        self.connectors = {name: Connector(name, remote) for name in servers}

    def __len__(self):
        return len(self._definitions)

    def __iter__(self):
        return iter(sorted(self._definitions))

    def __getitem__(self, name):
        return Tool(self._definitions[name], self._remote)

    def __repr__(self):
        return f"<tools: {len(self)} available; use .folders(), .find(text), or ['name']>"

    def folders(self, **options):
        return {
            **discover(list(self._definitions.values()), {"op": "list", **options}),
            "connectors": sorted(self.connectors),
        }

    def find(self, text="", *, folder=None, offset=0, limit=20):
        return discover(
            list(self._definitions.values()),
            {
                "op": "list",
                "view": "names",
                "filter": text,
                "offset": offset,
                "limit": limit,
                **({"folder": folder} if folder is not None else {}),
            },
        )

    def describe(self, name):
        return self._definitions[name]


class Notebook:
    def __init__(self, path, remote):
        self.store = Store(path)
        self._remote = remote
        self._revision = self.store.read()[1]
        self.namespace = None
        self.team = Team(remote)

    def __repr__(self):
        return f"<notebook {self.store.path.name}; .cells(), .read(id), .create(), .update(), .delete(), .move(), .eval()>"

    def cells(self):
        return [
            {"id": n.id, "kind": n.kind, "language": n.language} for n in self.store.read()[0].nodes
        ]

    def read(self, address):
        return self.store.read()[0].get(address).value()

    def read_text(self, address, *, field="source", offset=0, limit=800):
        """Read a bounded UTF-8 slice of a cell field or immutable context reference."""
        from .context_bridge import ContextBridge

        return ContextBridge(self.store).read(address, field, offset, limit)

    def view(self, address, mode="preview"):
        """Select an epoch view; oversized Python full views render as labeled previews.

        Requested policy and complete cell data persist. Use read_text for slices.
        """
        from .context_bridge import ContextBridge

        if os.environ.get("DOCLOOP_CONTEXT_EPOCHS") != "1":
            raise ValueError(
                "Cell views require epoch context; use read_text for bounded inspection"
            )
        result = ContextBridge(self.store).view(self._revision, address, mode)
        self._revision = result["revision"]
        return result

    def _edit(self, edit):
        from .context_bridge import ContextBridge

        result = ContextBridge(self.store).patch(self._revision, [edit])
        self._revision = result["revision"]
        return result

    def create(self, id, source, *, kind="code", language="python", after=None):
        return self._edit(
            {
                "op": "create",
                "node": {"id": id, "kind": kind, "source": source, "language": language},
                **({"after": after} if after else {}),
            }
        )

    def update(self, address, **changes):
        return self._edit({"op": "update", "address": address, "changes": changes})

    def delete(self, address):
        return self._edit({"op": "delete", "address": address})

    def move(self, address, after):
        return self._edit({"op": "move", "address": address, "after": after})

    def refresh(self):
        self._revision = self.store.read()[1]
        return self.cells()

    def python_history(self, limit=50):
        from .python_checkpoint import CheckpointStore

        return CheckpointStore(self.store).history(limit)

    def restore_python(self, checkpoint):
        from .python_checkpoint import RestorePython

        raise RestorePython(checkpoint)

    def eval(self, address):
        doc, revision = self.store.read()
        if revision != self._revision:
            raise Conflict("Notebook changed; refresh and inspect before evaluating")
        node = doc.get(address)
        if node.kind != "code":
            raise ValueError("Only code cells can be evaluated")
        if node.language not in {"python", "python3", "jupyter", "jupyter-python"}:
            result = self._remote.call("eval", address=address, revision=revision)
            self._revision = result["revision"]
            return result
        if self.namespace is None:
            raise RuntimeError("Notebook must be bound to its Python namespace")
        attempt = uuid.uuid4().hex
        source_hash = digest(node.language + "\n" + node.source)
        started = time.time()
        from .execution import _process_identity

        node.metadata["docloop_execution"] = {
            "attempt_id": attempt,
            "status": "running",
            "source_hash": source_hash,
            "owner_pid": os.getpid(),
            "owner_identity": _process_identity(os.getpid()),
            "started_at": started,
            "fresh_process": False,
            "environment": {
                "kind": "local",
                "workspace": os.environ.get("DOCLOOP_NATIVE_WORKSPACE", os.getcwd()),
            },
        }
        node.outputs = []
        self._revision = self.store.save(doc, revision, f"Begin Python cell {address}")
        from IPython.utils.capture import capture_output

        from .python_kernel import evaluate

        output = None
        error = None
        try:
            with capture_output() as output:
                evaluate(node.source, self.namespace, f"<{address}>")
        except Exception as exc:
            error = {
                "output_type": "error",
                "ename": type(exc).__name__,
                "evalue": str(exc),
                "traceback": [],
            }
        current, revision = self.store.read()
        target = current.get(address)
        if (
            digest(target.language + "\n" + target.source) != source_hash
            or target.metadata.get("docloop_execution", {}).get("attempt_id") != attempt
        ):
            raise Conflict("Evaluated cell changed; results were not attached")
        target.outputs = []
        if output is not None:
            for name in ("stdout", "stderr"):
                if text := getattr(output, name):
                    target.outputs.append({"output_type": "stream", "name": name, "text": text})
            target.outputs.extend(
                {"output_type": "display_data", "data": item.data, "metadata": item.metadata}
                for item in output.outputs
            )
        if error:
            target.outputs.append(error)
        target.metadata["docloop_execution"].update(
            status="error" if error else "ok",
            exit_code=1 if error else 0,
            duration=time.time() - started,
        )
        self._revision = self.store.save(current, revision, f"Finish Python cell {address}")
        return target.outputs


class Team:
    def __init__(self, remote):
        self._remote = remote

    def __repr__(self):
        return "<team: .spawn(), .send(), .receive(), .ack(), .status(), .collect()>"

    def spawn(self, task, **options):
        """Start a child; return {id, path, status} without waiting for completion.

        Options: id="tester", shared=["requirements"], workspace_mode="copy".
        Shared cells are explicit snapshots. A copied workspace remains separate.
        """
        return self._remote.call("team", op="spawn", task=task, **options)

    def send(self, to, body, **options):
        """Deliver durable mail to a child ID, 'parent', 'self', or a sibling ID.

        Use id="stable-message-id" for idempotent delivery of the same body.
        Returns the message dict, including id/from/to/body/acked/created_at.
        """
        return self._remote.call("team", op="send", to=to, body=body, **options)

    def receive(self):
        """Return {'messages': [unacknowledged message dicts]}; never consume mail.

        Iterate team.receive()['messages'], then team.ack(message['id']).
        """
        return self._remote.call("team", op="receive")

    def ack(self, id):
        """Acknowledge a received message ID and return its retained message dict."""
        return self._remote.call("team", op="ack", id=id)

    def status(self, *, full=False):
        """Return {'children': {child_id: compact_lifecycle}} and refresh stale owners.

        Compact records include status/path/error and a small run_result. Use
        full=True to inspect the full task, usage, final message and collected nodes.
        This can update the notebook revision; inspect then notebook.refresh().
        """
        if type(full) is not bool:
            raise ValueError("full must be a boolean")
        result = self._remote.call("team", op="status")
        if full:
            return result
        children = {}
        for ident, entry in result["children"].items():
            record = {k: entry[k] for k in ("status", "path") if k in entry}
            if entry.get("error"):
                record["error"] = str(entry["error"])[:400]
            if isinstance(entry.get("run_result"), dict):
                record["run_result"] = {
                    k: (str(v)[:400] if k == "error" else v)
                    for k, v in entry["run_result"].items()
                    if k in {"done", "cancelled", "error", "steps", "revision"}
                }
            children[ident] = record
        return {"children": children}

    def collect(self, id):
        """Save and return {child, revision, nodes}, a snapshot of a child's notebook.

        Wait for completion to collect a final snapshot. Files are not merged:
        inspect nodes and explicitly integrate selected artifacts in your workspace.
        """
        return self._remote.call("team", op="collect", id=id)

    def cancel(self, id):
        """Request cancellation of this child; use status() to observe completion."""
        return self._remote.call("team", op="cancel", id=id)

    def resume(self, id):
        """Resume an inactive, unfinished child from its saved notebook and model."""
        return self._remote.call("team", op="resume", id=id)


def state():
    """Return exactly (notebook, tools, conversation); team is notebook.team.

    Cell execution already binds these objects and team in the persistent namespace.
    Calling state() explicitly refreshes their document-backed values.
    """
    remote = Remote(os.environ["DOCLOOP_PYTHON_SOCKET"])
    snapshot = remote.call("state")
    notebook = Notebook(snapshot["document"], remote)
    import inspect

    notebook.namespace = inspect.currentframe().f_back.f_globals
    return (
        notebook,
        Tools(snapshot["tools"], remote, snapshot.get("connectors", [])),
        snapshot["conversation"],
    )
