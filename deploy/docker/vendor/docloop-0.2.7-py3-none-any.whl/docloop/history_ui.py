"""UI-only history/projection accounting. Nothing here is inserted into model text."""

from __future__ import annotations

import json
import math
import os
import subprocess

from .document import Node, canonical, digest
from .formats import decode

CHAT_ROLES = {"human", "agent", "read", "error", "user_instruction", "instructions"}


def message_value(node):
    role = node.metadata.get("docloop_role")
    if role in CHAT_ROLES or role == "context_tool":
        return {"role": role, "source": node.source, "outputs": node.outputs}
    if node.kind == "code" and (node.outputs or node.metadata.get("docloop_execution")):
        return {
            "role": "tool",
            "source": node.source,
            "outputs": node.outputs,
            "execution": node.metadata.get("docloop_execution"),
        }
    return None


def retained_history(store):
    """Read the selected native Git ancestry; message revisions are immutable events.

    Caller holds the native lock when correlating this view with live input. This
    is a projection of existing Git objects, not another document or transcript store.
    """
    versions = list(reversed(store.history()))
    head = versions[-1]["commit"] if versions else None
    try:
        branch = store.git("symbolic-ref", "--quiet", "HEAD").strip()
    except subprocess.CalledProcessError:
        branch = "detached:" + (head or "empty")
    cached = getattr(store, "_conversation_history_cache", None)
    if cached and cached["head"] == head:
        return {**json.loads(canonical(cached)), "branch": branch}
    events, latest, previous = [], {}, {}
    if cached and cached["head"] in [v["commit"] for v in versions]:
        restored = json.loads(canonical(cached))
        events, latest, previous = (
            restored["events"],
            restored["latest"],
            restored["tip_fingerprints"],
        )
        versions = versions[[v["commit"] for v in versions].index(cached["head"]) + 1 :]
    for version in versions:
        raw = store.version(version["commit"])
        doc = decode(raw, store.path.suffix)
        current = {}
        for node in doc.nodes:
            value = message_value(node)
            if value is None:
                continue
            fingerprint = digest(canonical(value))
            current[node.id] = fingerprint
            if previous.get(node.id) != fingerprint:
                event = {
                    "id": version["commit"] + ":" + node.id,
                    "node_id": node.id,
                    "commit": version["commit"],
                    "revision": digest(raw),
                    "date": version["date"],
                    "change": "revision" if node.id in latest else "message",
                    "fingerprint": fingerprint,
                    **value,
                }
                events.append(event)
                latest[node.id] = event
        previous = current
    result = {
        "head": head,
        "branch": branch,
        "events": events,
        "latest": latest,
        "tip_fingerprints": previous,
    }
    store._conversation_history_cache = json.loads(canonical(result))
    return result


def model_configuration(model=None):
    def number(name):
        value = os.environ.get(name)
        if value is None or value == "":
            return None
        if not value.isdecimal() or int(value) > 100_000_000:
            raise ValueError(name + " must be an explicit nonnegative token count")
        return int(value)

    configured_model = os.environ.get("DOCLOOP_MODEL") or None
    selected_model = model or configured_model
    # The configured window belongs to the configured model, not every picker choice.
    window = number("DOCLOOP_CONTEXT_WINDOW_TOKENS") if selected_model == configured_model else None
    return {
        "model": selected_model,
        "window_tokens": window,
        "output_reserve_tokens": number("DOCLOOP_OUTPUT_RESERVE_TOKENS"),
    }


def account(messages, config):
    """A labeled byte/4 estimate over ALL known input, including JSON framing.

    No tokenizer/model request, metadata insertion, cache subtraction, or guessed
    model-window lookup. Provider serialization/tokenization remains unobservable.
    """
    raw = canonical(messages).encode()
    components = {
        "system_and_tools": 0,
        "document_and_edits": 0,
        "included_chat": 0,
        "known_framing": 0,
    }
    for message in messages:
        size = len(message["content"].encode())
        key = (
            "system_and_tools"
            if message["role"] == "system"
            else "included_chat"
            if message["content"].startswith("RECENT PROSE\n")
            else "document_and_edits"
        )
        components[key] += size
    components["known_framing"] = len(raw) - sum(components.values())
    window, reserve = config["window_tokens"], config["output_reserve_tokens"]
    budget = max(0, window - reserve) if window is not None and reserve is not None else None
    estimate = math.ceil(len(raw) / 4)
    return {
        **config,
        "input_budget_tokens": budget,
        "estimated_input_tokens": estimate,
        "serialized_bytes": len(raw),
        "component_bytes": components,
        "method": "estimate: UTF-8 bytes / 4, rounded up; not a model tokenizer",
        "unknown_overhead": "Provider/native tokenizer, hidden tools and message framing are unknown.",
        "reserve_enforced": False,
        "over_budget_estimate": budget is not None and estimate > budget,
    }


def projection_metadata(store, doc, revision, serialized, blocks, config, db):
    """Correlate stable history IDs with exactly the already-assembled projection."""
    from .context_bridge import materialize

    history = retained_history(store)
    messages = json.loads(serialized)
    tail = messages[-1]["content"]
    python_views = tail.startswith("CURRENT PYTHON VIEWS\n")
    prefix = "CURRENT PYTHON VIEWS\n" if python_views else "RECENT PROSE\n"
    prose = json.loads(tail.removeprefix(prefix).rsplit("\nRevision: ", 1)[0])
    if python_views:
        prose = prose["cells"]
    projected = {n["id"]: ("document", n) for n in materialize(blocks)["nodes"]}
    projected.update({n["id"]: ("document" if python_views else "chat", n) for n in prose})
    inclusion, chat_ids = {}, []
    # Old document versions are still literal input in snapshot/edit messages.
    # Materialized current state alone would incorrectly label those as excluded.
    versions = {}
    for raw in blocks:
        block = json.loads(raw)
        for selected in (
            block["document"]["nodes"] if block["type"] == "snapshot" else block["upsert"]
        ):
            native = db.execute(
                "SELECT text FROM blobs WHERE ref=?", (selected["native_ref"],)
            ).fetchone()
            value = message_value(Node(**json.loads(native[0])))
            if value is not None:
                versions[(selected["id"], digest(canonical(value)))] = selected
    for event in history["events"]:
        selected = versions.get((event["node_id"], event["fingerprint"]))
        if selected:
            inclusion[event["id"]] = {
                "status": "document",
                "location": "document_history",
                "omitted_bytes": sum(
                    selected[field]["omitted_bytes"]
                    for field in ("source", "outputs", "metadata", "extra")
                ),
                "content_ref": selected["native_ref"],
            }
    for node in doc.nodes:
        value = message_value(node)
        event = history["latest"].get(node.id)
        if value is None or event is None or event["fingerprint"] != digest(canonical(value)):
            continue
        location, selected = projected.get(node.id, (None, None))
        if selected is None:
            continue
        # source/outputs are what the conversation renders; metadata previews can
        # independently truncate, so explicitly count all omitted fields as well.
        omitted = sum(
            selected[field]["omitted_bytes"] for field in ("source", "outputs", "metadata", "extra")
        )
        status = "document" if location == "document" else "truncated" if omitted else "included"
        inclusion[event["id"]] = {
            "status": status,
            "omitted_bytes": omitted,
            "location": location,
            "content_ref": selected["native_ref"],
        }
        if location == "chat":
            chat_ids.append(event["id"])
    # The divider uses chronological history order, never a guessed last-N index.
    included = set(chat_ids)
    first = next((e["id"] for e in history["events"] if e["id"] in included), None)
    return {
        "revision": revision,
        "input_hash": digest(serialized),
        "history_head": history["head"],
        "branch": history["branch"],
        "known_history_ids": [e["id"] for e in history["events"]],
        "included_message_ids": chat_ids,
        "divider_id": first,
        "inclusion": inclusion,
        "accounting": account(messages, config),
    }


def provider_measurement(usage):
    if not isinstance(usage, dict):
        return None

    def count(value):
        return value if type(value) is int and value >= 0 else None

    if count(usage.get("prompt_tokens")) is not None:
        details = usage.get("prompt_tokens_details") or {}
        return {
            "input_tokens": usage["prompt_tokens"],
            "cached_input_tokens": count(details.get("cached_tokens"))
            if isinstance(details, dict)
            else None,
            "output_tokens": count(usage.get("completion_tokens")),
            "source": "provider prompt_tokens (includes cache)",
        }
    if count(usage.get("input_tokens")) is not None:
        cached, created = (
            count(usage.get("cache_read_input_tokens")),
            count(usage.get("cache_creation_input_tokens")),
        )
        return {
            "input_tokens": usage["input_tokens"] + (cached or 0) + (created or 0),
            "cached_input_tokens": cached,
            "output_tokens": count(usage.get("output_tokens")),
            "source": "provider input + cache read + cache creation",
        }
    return {"input_tokens": None, "source": "Unrecognized provider usage; raw receipt retained"}
