"use strict";
const $ = id => document.getElementById(id);
const token = document.querySelector('meta[name="docloop-token"]').content;
let state, historical = false, editing = false, activeEditor;
let modelChangePending = false, storageFailure = null;
let historyVerified = null, historyProbe = null, historyLastChecked = 0, historyEpoch = 0;
const HISTORY_CHECK_INTERVAL = 30000;
const editorDrafts = new Map();
let stateGeneration = 0, pendingRefresh = null, activeMutations = 0;
async function api(path, data, signal) {
  const response = await fetch('/api/' + path, {method:data ? 'POST':'GET', headers:{'X-Docloop-Token':token,'Content-Type':'application/json'},body:data ? JSON.stringify(data):undefined,signal});
  const result = await response.json(); if (!response.ok) { const error=Error(result.error);error.status=response.status;error.outcome=result;throw error; } return result;
}
function element(tag, text, cls) { const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e; }
function button(text, action) { const b=element('button',text);b.type='button';b.onclick=()=>guard(action);return b; }
async function guard(action){try{$('error').textContent='';await action();}catch(e){$('error').textContent=e.message;}}
// Deliberately small Markdown renderer: every source fragment becomes a text node.
function markdown(source){const out=element('div');let fence=false,lines=[];for(const line of source.split('\n')){if(line.startsWith('```')){if(fence){out.append(element('pre',lines.join('\n')));lines=[];}fence=!fence;continue;}if(fence){lines.push(line);continue;}const heading=line.match(/^(#{1,6}) (.*)$/);out.append(element(heading?'h'+heading[1].length:'p',heading?heading[2]:line));}if(lines.length)out.append(element('pre',lines.join('\n')));return out;}
function installState(fresh){
  if(state&&fresh.path!==state.path){$('conversation-selection').replaceChildren(new Option('Next request preview','next'));conversationData=null;conversationRows=[];conversationBefore=null;}
  if(fresh.history_status?.status==='checking'&&historyVerified?.revision===fresh.revision&&Date.now()-historyLastChecked<HISTORY_CHECK_INTERVAL)fresh.history_status=historyVerified.status;
  else if(fresh.history_status?.status!=='checking'){
    historyVerified={revision:fresh.revision,status:fresh.history_status};historyLastChecked=Date.now();historyEpoch++;
  }
  stateGeneration++;state=fresh;refreshConversation();
}
function updateHistoryUI(){
  const history=state.history_status;
  $('storage-status').textContent=history?.status==='checking'?'Checking version history…':history&&history.status!=='recorded'?'Version history: '+history.status+'. Repair records the current saved document only; it does not run code or resend instructions.':'';
  $('recover-history').hidden=!storageFailure&&(!history||history.status==='recorded'||history.status==='checking');
  $('recover-history').disabled=state.running;
}
async function checkHistoryStatus(){
  if(historyProbe||!state||Date.now()-historyLastChecked<HISTORY_CHECK_INTERVAL)return;
  const revision=state.revision;
  const epoch=historyEpoch;
  historyProbe=(async()=>{
    try{
      const status=await api('history-status');
      if(state?.revision!==revision||historyEpoch!==epoch||(status.revision&&status.revision!==revision)||(status.current_revision&&status.current_revision!==revision))return;
      historyVerified={revision,status};historyLastChecked=Date.now();
      state.history_status=status;
      updateHistoryUI();
    }catch(error){
      historyLastChecked=Date.now();
      historyVerified=null;
      if(state?.revision===revision){state.history_status={status:'unavailable',revision};updateHistoryUI();}
    }finally{historyProbe=null;}
  })();
  return historyProbe;
}
async function mutate(data){
  const revision=state.revision;
  stateGeneration++;activeMutations++;
  try {
    const fresh=await api('action',{revision,...data});
    installState(fresh);historical=false;render(state);
  } catch(error) {
    if(error.outcome?.retry_action===false)storageFailure=error.outcome;
    if(error.status===409||error.outcome?.retry_action===false){
      try {
        await refresh(true);
        error.message+=' Latest state loaded for review; the action was not retried. Your unsent draft is unchanged.';
      } catch(refreshError){error.message+=' Could not refresh current state: '+refreshError.message;}
    }
    throw error;
  } finally {activeMutations--;stateGeneration++;}
}
function prettyJSON(text) {
  try { const value=JSON.parse(text); if(value===null||typeof value!=='object') return text; }
  catch { return text; }
  // Keep number literals and duplicate keys intact while adding whitespace.
  const tokens=text.match(/"(?:\\.|[^"\\])*"|[^\s{}\[\],:]+|[{}\[\],:]/g)||[];
  let result='',depth=0;const empty=[];
  for(let i=0;i<tokens.length;i++) {
    const token=tokens[i];
    if(token==='{'||token==='[') {
      const isEmpty=tokens[i+1]===(token==='{'?'}':']');empty.push(isEmpty);result+=token;
      if(!isEmpty)result+='\n'+'  '.repeat(++depth);
    } else if(token==='}'||token===']') {
      if(!empty.pop())result+='\n'+'  '.repeat(--depth);result+=token;
    } else if(token===',')result+=',\n'+'  '.repeat(depth);
    else if(token===':')result+=': ';
    else result+=token;
  }
  return result;
}
function displaySource(node){return ['json','mcp','team'].includes(node.language)?prettyJSON(node.source):node.source;}
function outputs(node, container){for(const output of node.outputs||[]){let text=output.text||output.traceback?.join('\n')||output.data?.['text/plain'];if(Array.isArray(text))text=text.join('');if(text)container.append(element('pre',prettyJSON(text),'output'));const png=output.data?.['image/png'];if(png){const img=element('img');img.alt='Cell output';img.src='data:image/png;base64,'+(Array.isArray(png)?png.join(''):png);container.append(img);}if(!text&&!png)container.append(element('pre',JSON.stringify(output,null,2),'output'));}}
function executionStatus(node, container){
  if(node.kind!=='code')return;
  const receipt=node.metadata?.docloop_execution;
  const status=receipt?.status||'not evaluated';
  const row=element('div',undefined,'execution-status');
  row.dataset.status=status;
  row.append(element('span','Execution: '+status,'execution-badge'));
  if(status==='unknown')row.append(element('span','Inspect workspace before re-evaluation.','execution-guidance'));
  if(receipt){const details=element('details');details.append(element('summary','Execution details'),element('pre',JSON.stringify(receipt,null,2)));row.append(details);}
  container.append(row);
}
function openEditor(node) {
  if (!editorDrafts.has(node.id)) {
    editorDrafts.set(node.id, {source:node.source, revision:state.revision, node});
  }
  activeEditor=node.id;editing=true;
  render(state);
  $(node.id).querySelector('textarea').focus();
}
function renderEditor(node, body, actions, exists) {
  const draft=editorDrafts.get(node.id);
  const area=element('textarea');
  area.dataset.editorAddress=node.id;
  area.value=draft.source;
  area.rows=Math.min(25,Math.max(4,draft.source.split('\n').length+1));
  area.oninput=()=>{draft.source=area.value;};
  const save=button('Save',async()=>{
    await mutate({action:'update',revision:draft.revision,address:node.id,changes:{source:draft.source}});
    editorDrafts.delete(node.id);activeEditor=undefined;editing=false;render(state);
  });
  save.disabled=!exists||draft.revision!==state.revision;
  actions.replaceChildren(save,button('Cancel',()=>{
    editorDrafts.delete(node.id);activeEditor=undefined;editing=false;render(state);
  }));
  body.replaceChildren(area);
  if(!exists||draft.revision!==state.revision){
    const current=element('details');current.dataset.conflictCurrent='';current.open=true;
    current.append(element('summary','Current saved block — review before editing again'));
    if(exists){
      const reviewedRevision=state.revision;
      current.append(element('p','Compare the saved source below with your draft, then choose Use current revision. Saving remains a separate action.'));
      current.append(button('Use current revision',()=>{
        draft.revision=reviewedRevision;
        render(state);
      }));
    }
    current.append(element('pre',exists?node.source:'This block was deleted. Your draft is retained here; copy it before cancelling.'));
    body.append(current);
  }
}
function renderModels(){
  const models = state.models || [];
  const select = $('agent-model');
  const signature = JSON.stringify([models, state.model, state.default_model]);
  if(select.dataset.signature !== signature){
    select.replaceChildren(...models.map(model => {
      const option = element('option', model + (model === state.default_model ? ' (default)' : ''));
      option.value = model; return option;
    }));
    select.value = state.model || '';
    select.dataset.signature = signature;
  }
  select.disabled = historical || state.running || modelChangePending || !state.provider_available || models.length < 2;
  $('model-status').textContent = state.active_model ? 'Running: ' + state.active_model
    : state.result?.model ? 'Last run: ' + state.result.model : models.length ? 'Configured routes; availability is checked when running.' : '';
}
function render(doc){
  const focused=document.activeElement;
  const focusAddress=focused?.dataset.editorAddress;
  const selection=focusAddress?[focused.selectionStart,focused.selectionEnd]:null;
  $('document').replaceChildren();
  const nodes=[...doc.nodes];
  if(!historical){
    for(const [id,draft] of editorDrafts){
      if(!nodes.some(node=>node.id===id))nodes.push({...draft.node,source:'This block was deleted.'});
    }
  }
  for(const node of nodes){
    const exists=doc.nodes.some(saved=>saved.id===node.id);
    const article=element('article');article.id=node.id;
    const head=element('div',undefined,'node-head');
    head.append(element('span',node.id+' · '+(exists?node.kind:'deleted block')+(exists&&node.kind==='code'?' · '+node.language:''),'address'));
    const actions=element('div',undefined,'actions');
    const body=element('div',undefined,'body');
    body.append(node.kind==='code'||node.kind==='raw'?element('pre',displaySource(node)):markdown(node.kind==='section'?'# '+node.source:node.source));
    if(!historical){
      if(activeEditor===node.id){
        renderEditor(node,body,actions,exists);
      }else{
        if(exists)actions.append(button('Edit',()=>openEditor(node)));
        if(editorDrafts.has(node.id))actions.append(button('Resume draft',()=>openEditor(node)));
        if(exists){
          if(node.kind==='code')actions.append(button('Evaluate',()=>mutate({action:'eval',address:node.id})));
          actions.append(button('Move after…',()=>{const after=prompt('Target block address');if(after)return mutate({action:'move',address:node.id,after});}),button('Delete',()=>{if(confirm('Delete '+node.id+'? Sections include their descendants.'))return mutate({action:'delete',address:node.id});}));
        }
      }
    }
    head.append(actions);article.append(head);
    if(exists)executionStatus(node,article);
    article.append(body);
    if(exists)outputs(node,article);
    $('document').append(article);
  }
  if(!historical){
    $('path').textContent=state.path;
    $('status').textContent=state.running?'Running…':(state.status||'ready');
    $('logout').hidden=!state.authentication;
    $('context-tools').hidden=!state.context_epochs;
    $('cache').textContent='Cache candidate prefix: '+((state.cache_candidates||[]).join(', ')||'none')+' · Provider usage: '+JSON.stringify(state.metadata.docloop_provider_usage||{});
    if(state.error)$('error').textContent=state.error;
    if(state.result?.retry_action===false&&!state.result.storage_recovered)storageFailure=state.result.storage_failure||state.result;
    updateHistoryUI();
  }
  $('input').hidden=historical;$('manual-editor').hidden=historical;
  renderModels();
  $('run').disabled=historical||state.running||modelChangePending||!state.provider_available;
  $('stop').disabled=historical||!state.running;
  $('input').querySelector('button[type=submit]').disabled=modelChangePending||!state.provider_available;
  $('provider-status').textContent=state.provider_available?'':'Agent unavailable: configure a provider to run or send instructions. Your draft stays here; manual editing and cell evaluation are available.';
  if(focusAddress&&!historical){
    const area=$(focusAddress)?.querySelector('textarea');
    if(area){area.focus({preventScroll:true});area.setSelectionRange(...selection);}
  }
}
async function refresh(force=false){
  if(!force&&pendingRefresh)return pendingRefresh.promise;
  if(!force&&activeMutations)return;
  if(force){stateGeneration++;pendingRefresh?.controller.abort();}
  const request={controller:new AbortController(),generation:stateGeneration,promise:null};
  pendingRefresh=request;
  request.promise=(async()=>{
    try {
      const fresh=await api('state?fast=1',undefined,request.controller.signal);
      if(request.generation!==stateGeneration)return;
      const previous=state;
      installState(fresh);
      const changed=!previous||state.revision!==previous.revision||state.running!==previous.running||state.error!==previous.error||state.status!==previous.status||state.provider_available!==previous.provider_available||state.model!==previous.model||state.active_model!==previous.active_model||JSON.stringify(state.models)!==JSON.stringify(previous.models)||JSON.stringify(state.history_status)!==JSON.stringify(previous.history_status);
      if((changed||force)&&!historical)render(state);
      checkHistoryStatus();
    } catch(error){if(error.name!=='AbortError'&&request.generation===stateGeneration)throw error;}
    finally {if(pendingRefresh===request)pendingRefresh=null;}
  })();
  return request.promise;
}
$('run').onclick=()=>guard(()=>mutate({action:'run',model:state.model || undefined}));$('stop').onclick=()=>guard(()=>mutate({action:'stop'}));$('refresh').onclick=()=>guard(async()=>{historical=false;await refresh(true);});
$('add-block').onsubmit=e=>{e.preventDefault();guard(async()=>{await mutate({action:'insert',kind:$('kind').value,language:$('language').value,source:$('source').value});$('source').value='';});};$('source').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){$('add-block').requestSubmit();e.preventDefault();}};
$('history').onclick=()=>guard(async()=>{const versions=await api('history');$('versions').hidden=false;$('version').replaceChildren(...versions.map(v=>{const o=element('option',v.date+' · '+v.message);o.value=v.commit;return o;}));});
$('view-version').onclick=()=>guard(async()=>{const doc=await api('version?commit='+$('version').value);activeEditor=undefined;editing=false;historical=true;render(doc);$('status').textContent='Viewing '+$('version').value.slice(0,10);});
$('diff-version').onclick=()=>guard(async()=>{const versions=await api('history');$('diff').textContent=(await api('diff?older='+$('version').value+'&newer='+versions[0].commit)).diff||'No differences';});
$('restore-version').onclick=()=>guard(async()=>{if(confirm('Restore this version as a new commit?'))await mutate({action:'restore',commit:$('version').value});});$('live').onclick=()=>guard(async()=>{historical=false;await refresh(true);});
$('logout').onclick=()=>guard(async()=>{await api('logout',{});location.reload();});
guard(refresh);setInterval(()=>{if(!editing)refresh().catch(e=>{$('error').textContent=e.message;});},2000);

async function loadCheckpoints(){const versions=await api('checkpoints');$('checkpoint-panel').hidden=false;$('checkpoint-version').replaceChildren(...versions.map(v=>{const o=element('option',v.date+' · '+v.message);o.value=v.commit;return o;}));}
$('checkpoints').onclick=()=>guard(loadCheckpoints);
$('create-checkpoint').onclick=()=>guard(async()=>{await mutate({action:'checkpoint'});await loadCheckpoints();$('checkpoint-detail').textContent='Checkpoint created.';});
$('inspect-checkpoint').onclick=()=>guard(async()=>{$('checkpoint-detail').textContent=JSON.stringify(await api('checkpoint?commit='+$('checkpoint-version').value),null,2);});
$('diff-checkpoint').onclick=()=>guard(async()=>{const versions=await api('checkpoints');if(!versions.length)throw Error('Create a checkpoint first');$('checkpoint-detail').textContent=(await api('state-diff?older='+$('checkpoint-version').value+'&newer='+versions[0].commit)).diff||'No differences';});
$('fork-checkpoint').onclick=()=>guard(async()=>{if(confirm('Restore this checkpoint into a new workspace and open it?')){await mutate({action:'restore-state',commit:$('checkpoint-version').value});$('checkpoint-panel').hidden=true;$('versions').hidden=true;$('checkpoint-detail').textContent='';}});

let instructionRequestId;
$('input').onsubmit=e=>{e.preventDefault();guard(async()=>{if(modelChangePending)throw Error('Model selection is still being saved; draft retained.');const source=$('instruction').value;instructionRequestId ||= 'instruction_'+crypto.randomUUID().replaceAll('-','');const requestId=instructionRequestId;await mutate({action:'instruct',source,id:requestId,model:state.model || undefined});if($('instruction').value===source)$('instruction').value='';if(instructionRequestId===requestId)instructionRequestId=undefined;});};
$('instruction').oninput=()=>{instructionRequestId=undefined;};
$('instruction').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){$('input').requestSubmit();e.preventDefault();}};

let contextNextOffset=null, contextReadAddress='';
async function contextCall(request){$('context-preview').textContent='Loading context…';return api('action',{action:'context',request});}
$('inspect-context').onclick=()=>guard(async()=>{
  const result=await contextCall({op:'inspect'});
  $('context-preview').textContent=JSON.stringify(result,null,2);
});
$('compact-context').onclick=()=>guard(async()=>{
  await contextCall({op:'compact',revision:state.revision});
  await refresh(true);
  const result=await contextCall({op:'inspect'});
  $('context-preview').textContent=JSON.stringify(result,null,2);
});
async function readContextPage(offset){
  const result=await contextCall({op:'read',address:contextReadAddress,offset,limit:4000});
  contextNextOffset=result.next_offset;
  $('read-context-next').hidden=contextNextOffset===null;
  $('context-preview').textContent=JSON.stringify(result,null,2);
}
$('read-context').onclick=()=>guard(async()=>{
  contextReadAddress=$('context-address').value.trim();
  await readContextPage(0);
});
$('read-context-next').onclick=()=>guard(()=>readContextPage(contextNextOffset));

// All history IDs, divider labels and accounting remain UI-only. Never annotate
// the messages supplied by ContextBridge or feed this endpoint back into a prompt.
let conversationGeneration=0, conversationData=null, conversationRows=[], conversationBefore=null;
function staleConversation(message='Next context: stale — computing preview…'){
  conversationGeneration++;
  $('context-accounting').dataset.stale='true';
  $('conversation-panel').dataset.stale='true';
  $('context-counter').textContent=message;
  $('history-status').textContent='Inclusion labels are stale while the selected projection is refreshed.';
}
function number(value){return value===null||value===undefined?'unknown':value.toLocaleString();}
function renderAccounting(data){
  const next=data.next, a=next.accounting;
  $('context-counter').textContent=a?'Next context: ~'+number(a.estimated_input_tokens)+' / '+number(a.window_tokens)+' tokens (estimated)':'Next context: unknown — '+(next.error||'projection unavailable');
  $('context-reserve').textContent=a?'Output reserve: '+number(a.output_reserve_tokens)+' · Input budget: '+number(a.input_budget_tokens)+' tokens.':'';
  const last=data.last, measured=last?.provider_measured;
  $('last-context-counter').textContent=last?'Last sent '+last.request_id+': '+(measured?.input_tokens!==null&&measured?.input_tokens!==undefined?number(measured.input_tokens)+' input tokens (provider-measured)':'~'+number(last.accounting?.estimated_input_tokens)+' tokens (estimated; provider usage unknown)')+' · '+last.status:'Last sent: none recorded. Prepared inputs are not sent requests.';
  const detail=$('context-accounting-detail');detail.replaceChildren();
  if(a){
    detail.append(element('p','Next model: '+(a.model||'unknown')+' · revision '+next.revision),element('p','Input hash: '+next.input_hash));
    const labels={system_and_tools:'Known system instructions and tool descriptions',document_and_edits:'Document snapshot and immutable edits',included_chat:'Included chat, revision and suffix',known_framing:'Known JSON message framing'};
    for(const [key,bytes] of Object.entries(a.component_bytes))detail.append(element('p',labels[key]+': '+number(bytes)+' bytes'));
    detail.append(element('p','Output reserve is planning only; this counter does not enforce provider output limits.'),element('p',a.method),element('p',a.unknown_overhead),element('p','Cached input counts toward the context window. Excluded history and unsent drafts do not.'));
    if(a.over_budget_estimate)detail.append(element('p','Estimated input exceeds the configured input budget.'));
  }
  if(last){detail.append(element('p','Last sent model: '+(last.accounting?.model||'unknown')+' · revision '+last.revision+' · input hash '+last.input_hash));detail.append(element('p','Last sent window: '+number(last.accounting?.window_tokens)+' · reserve: '+number(last.accounting?.output_reserve_tokens)+' · dispatch attempts: '+last.dispatch_count));if(measured)detail.append(element('p','Provider measurement: '+measured.source+' · cached input: '+number(measured.cached_input_tokens)+' · output: '+number(measured.output_tokens)));}
}
function renderConversation(data){
  const selected=data.selected, list=$('conversation-history');list.replaceChildren();
  const loaded=new Set(conversationRows.map(e=>e.id));
  let boundary='Per-message labels apply to '+(selected.request_id?'frozen request '+selected.request_id:'next preview')+'.';
  if(selected.status==='unknown')boundary='Projection unknown: '+selected.error;
  else if(!selected.divider_id)boundary+=' No chat messages included; document-only content is labeled separately.';
  else if(!loaded.has(selected.divider_id))boundary+=' Included chat boundary is outside this loaded page ('+data.boundary.replaceAll('_',' ')+'). Load the corresponding history page to see it.';
  if(!conversationRows.length)boundary+=' No retained conversation messages yet.';
  $('history-status').textContent=boundary;
  for(const event of conversationRows){
    if(event.id===selected.divider_id)list.append(element('div','Included chat context starts here','history-divider'));
    const article=element('article');article.dataset.messageId=event.id;article.dataset.nodeId=event.node_id;
    const entry=selected.inclusion[event.id]||{status:'unknown'};
    const labels={included:'Included chat context',truncated:'Truncated in chat context — '+number(entry.omitted_bytes)+' bytes omitted; retained history below is full',document:'Document-only context'+(entry.location==='document_history'?' (historical block)':'')+' — not included as chat'+(entry.omitted_bytes?' · '+number(entry.omitted_bytes)+' bytes omitted':''),history:'History — not sent verbatim',pending:'Pending arrival — not included in this frozen request',unknown:'Inclusion unknown — refresh the projection'};
    article.append(element('span',labels[entry.status]||labels.unknown,'history-inclusion history-'+entry.status),element('div',event.role+' · '+event.date+(event.change==='revision'?' · revised message':''),'history-meta'),element('pre',event.source));
    outputs(event,article);
    if(event.execution)article.append(element('p','Recorded execution: '+event.execution.status,'history-meta'));
    list.append(article);
  }
  $('load-older-history').hidden=!conversationBefore;
}
async function refreshConversation(older=false){
  if(!state)return;
  const path=state.path, revision=state.revision, selection=$('conversation-selection').value;
  staleConversation();const generation=conversationGeneration;
  let query='conversation?selection='+encodeURIComponent(selection);
  if(older&&conversationBefore)query+='&before='+encodeURIComponent(conversationBefore);
  try{
    const data=await api(query);
    if(generation!==conversationGeneration||path!==state.path||revision!==state.revision)return;
    if(data.revision!==state.revision){$('history-status').textContent='Stale projection: a concurrent edit arrived. Waiting for current state.';return;}
    if(older&&conversationData?.selected.input_hash!==data.selected.input_hash){$('history-status').textContent='Projection changed while loading history. Refresh to use the current boundary.';return;}
    const previous=conversationData;
    const pageGap=!older&&conversationRows.length&&data.history.length&&!data.history.some(e=>conversationRows.some(row=>row.id===e.id));
    conversationData=data;
    if(older){const ids=new Set(data.history.map(e=>e.id));conversationRows=[...data.history,...conversationRows.filter(e=>!ids.has(e.id))];conversationBefore=data.before;}
    else if(previous&&previous.conversation===data.conversation&&previous.branch===data.branch&&conversationRows.length&&!pageGap){
      const ids=new Set(conversationRows.map(e=>e.id));
      conversationRows=[...conversationRows,...data.history.filter(e=>!ids.has(e.id))];
    }else{conversationRows=data.history;conversationBefore=data.before;}
    const options=[{id:'next',label:'Next request preview'}];
    if(data.last)options.push({id:data.last.request_id,label:'Last sent · '+data.last.request_id});
    if(selection!=='next'&&!options.some(o=>o.id===selection))options.push({id:selection,label:'Frozen request · '+selection});
    $('conversation-selection').replaceChildren(...options.map(item=>{const option=element('option',item.label);option.value=item.id;return option;}));
    $('conversation-selection').value=selection;
    // A workspace switch must never retain another conversation's loaded events.
    if(previous&&(previous.conversation!==data.conversation||previous.branch!==data.branch)){conversationRows=data.history;conversationBefore=data.before;}
    renderAccounting(data);renderConversation(data);
    if(pageGap)$('history-status').textContent+=' New arrivals moved beyond the loaded page; showing the latest page. Older messages remain available.';
    $('context-accounting').dataset.stale='false';$('conversation-panel').dataset.stale='false';
  }catch(error){if(generation===conversationGeneration){$('context-counter').textContent='Next context: unknown — '+error.message;$('history-status').textContent='Inclusion unknown — '+error.message;}}
}
$('conversation-selection').onchange=()=>refreshConversation();
$('load-older-history').onclick=()=>refreshConversation(true);

$('agent-model').onchange=()=>guard(async()=>{
  const selected=$('agent-model').value;
  modelChangePending=true;
  render(state);
  try { await mutate({action:'model',model:selected}); instructionRequestId=undefined; }
  finally {
    modelChangePending=false;
    $('agent-model').dataset.signature='';
    render(state);
  }
});

$('recover-history').onclick=()=>guard(async()=>{await mutate({action:'recover-history'});storageFailure=null;render(state);$('storage-status').textContent='History repaired for the current document. No action was repeated.';});
