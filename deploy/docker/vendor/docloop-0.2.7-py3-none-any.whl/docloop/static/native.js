"use strict";
// JupyterLab is the live notebook editor; the document renderer still shows Org
// and historical snapshots. Keep its frame stable while agent status changes.
const nativePanel = document.createElement('section');
nativePanel.id = 'native-notebook';
const nativeFrame = document.createElement('iframe');
nativeFrame.title = 'JupyterLab notebook';
nativeFrame.className = 'native-frame';
const nativeNotice = document.createElement('p');
nativeNotice.className = 'native-notice';
const nativeLoadStatus = document.createElement('p');
nativeLoadStatus.className = 'native-load-status';
nativeLoadStatus.setAttribute('role', 'status');
nativeLoadStatus.textContent = 'Loading JupyterLab…';
const nativeToolbar = document.createElement('div');
nativeToolbar.className = 'native-toolbar';
const nativeDescription = document.createElement('div');
nativeDescription.append(nativeLoadStatus, nativeNotice);
let nativeLoadTimer;
function loadingNative() {
  ++nativeGeneration;
  nativeLab = undefined;
  clearInterval(nativeConfigureTimer);
  clearInterval(nativeStatusTimer);
  nativeLoadStatus.textContent = 'Loading JupyterLab…';
  clearTimeout(nativeLoadTimer);
  nativeLoadTimer = setTimeout(() => { nativeLoadStatus.textContent = 'JupyterLab is taking longer to load. You can wait or reload below.'; }, 20000);
}
let nativeSeenRevision;
const nativeReload = document.createElement('button');
nativeReload.textContent = 'Reload notebook from disk';
nativeReload.onclick = () => { if(confirm('Reload JupyterLab from disk? Save your own edits first.')) { loadingNative(); nativeFrame.src = nativeFrame.src; } };
let nativeConfigureTimer, nativeStatusTimer, nativeGeneration = 0, nativeLab;
function compactNative() {
  if (!nativeLab) return;
  const compact = window.innerWidth < 1100;
  nativeLab.shell.mode = compact ? 'single-document' : 'multiple-document';
  if (compact) { nativeLab.shell.collapseLeft(); nativeLab.shell.collapseRight(); }
}
window.addEventListener('resize', compactNative);
nativeFrame.addEventListener('load', () => {
  nativeSeenRevision = state?.revision;
  const generation = ++nativeGeneration;
  nativeLab = undefined;
  clearInterval(nativeConfigureTimer);
  clearInterval(nativeStatusTimer);
  nativeConfigureTimer = setInterval(async () => {
    const lab = nativeFrame.contentWindow?.jupyterapp;
    if (!lab) return;
    clearInterval(nativeConfigureTimer);
    try {
      await lab.restored;
      if (generation !== nativeGeneration) return;
      nativeLab = lab;
      clearTimeout(nativeLoadTimer);
      compactNative();
      function showKernel() {
        const session = lab.shell.currentWidget?.sessionContext;
        nativeLoadStatus.textContent = session ? 'JupyterLab · Kernel: ' + (session.kernelDisplayStatus || 'connecting') : 'JupyterLab loaded · Open a notebook to connect a kernel';
      }
      showKernel();
      nativeStatusTimer = setInterval(showKernel, 1500);
    } catch (error) {
      if (generation === nativeGeneration) {
        clearTimeout(nativeLoadTimer);
        nativeLoadStatus.textContent = 'JupyterLab could not finish loading. Reload to retry.';
      }
    }
  }, 250);
});
const addressed = document.createElement('details');
const addressedTitle = document.createElement('summary');
addressed.className = 'native-evaluator';
addressedTitle.textContent = 'Evaluate a cell with Docloop';
const addressedHelp = document.createElement('p');
addressedHelp.textContent = 'Jupyter Run uses the selected kernel. Use this evaluator for saved shell, MCP, team, or other Docloop code cells; it uses each cell’s language and configured environment.';
const addressedSelect = document.createElement('select');
addressedSelect.setAttribute('aria-label', 'Cell address for Docloop evaluation');
const addressedRun = document.createElement('button');
addressedRun.textContent = 'Evaluate addressed cell';
addressedRun.onclick = () => guard(() => mutate({action:'eval', address:addressedSelect.value}));
const addressedOutput = document.createElement('div');
function renderAddressedOutput() {
  addressedOutput.replaceChildren();
  const node = state?.nodes.find(n => n.id === addressedSelect.value);
  if(node) { executionStatus(node, addressedOutput); outputs(node, addressedOutput); }
}
addressedSelect.onchange = renderAddressedOutput;
addressed.append(addressedTitle, addressedHelp, addressedSelect, addressedRun, addressedOutput);
const kernelNote = document.createElement('p');
kernelNote.className = 'native-kernel-note';
kernelNote.textContent = 'Jupyter Run uses the selected kernel. For saved shell, MCP and team cells, use Evaluate a cell with Docloop below.';
nativeToolbar.append(nativeDescription, nativeReload);
nativePanel.append(nativeToolbar, nativeFrame, kernelNote, addressed);
document.getElementById('document').before(nativePanel);
const originalRender = render;
render = function(doc) {
  originalRender(doc);
  const native = !historical && state.native_jupyter;
  nativePanel.hidden = !native;
  document.body.classList.toggle('native-notebook-open', Boolean(native && native.url));
  document.getElementById('document').hidden = Boolean(native && native.url);
  if(!native)return;
  const selected = addressedSelect.value;
  addressedSelect.replaceChildren(...state.nodes.filter(n => n.kind === 'code').map(n => {
    const option = document.createElement('option'); option.value=n.id; option.textContent=n.id+' · '+n.language; return option;
  }));
  if([...addressedSelect.options].some(o => o.value === selected)) addressedSelect.value=selected;
  addressedRun.disabled = state.running || !addressedSelect.value;
  renderAddressedOutput();
  nativeFrame.hidden = !native.url;
  nativeReload.hidden = !native.url;
  nativeNotice.textContent = native.error || (nativeSeenRevision && state.revision !== nativeSeenRevision
    ? 'Notebook changed on disk. Reload to view the latest saved state. Save your own edits first; stale saves are rejected.'
    : 'Native JupyterLab. Save notebook edits before sending instructions. Reload from disk after agent changes; stale saves are rejected.');
  if (native.url && window.matchMedia('(any-pointer: coarse)').matches) nativeNotice.textContent += ' Swipe the menu bar sideways for Settings and Help.';
  if(native.url && nativeFrame.getAttribute('src') !== native.url) { loadingNative(); nativeFrame.src=native.url; }
  if(!native.url) { clearTimeout(nativeLoadTimer); nativeLoadStatus.textContent = 'Native notebook unavailable'; }
};
if(state)render(state);
