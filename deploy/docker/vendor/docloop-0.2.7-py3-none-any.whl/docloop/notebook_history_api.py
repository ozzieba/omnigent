"""Bounded historical notebook views; browsing never restores or executes a version."""

from __future__ import annotations

import re
import subprocess

from fastapi import HTTPException

from .document import digest
from .formats import decode
from .notebook_api import MAX_DOCUMENT_BYTES, MAX_NODES, NotebookBinding, project_document
from .store import HistoryFailure

COMMIT = re.compile(r"(?:[a-f0-9]{40}|[a-f0-9]{64})\Z")
PAGE_SIZE = 50


def _commit(value: str):
    if not isinstance(value, str) or not COMMIT.fullmatch(value):
        raise HTTPException(400, "A full Git version ID is required")


def _head(store):
    return store.history_status()["commit"]


def _ancestor(store, commit, head):
    _commit(commit)
    if not head:
        raise HTTPException(404, "Saved version not found")
    try:
        # merge-base reports both an unknown commit and repository failures as
        # fatal errors. Resolve the commit first: a quiet lookup distinguishes
        # a missing/non-commit object (exit 1) from unreadable history.
        store.git("rev-parse", "--verify", "--quiet", f"{commit}^{{commit}}")
        store.git("merge-base", "--is-ancestor", commit, head)
    except subprocess.CalledProcessError as exc:
        if exc.returncode == 1:
            raise HTTPException(404, "Version is not in this notebook's selected history") from exc
        raise HistoryFailure(phase="history_read") from exc
    except OSError as exc:
        raise HistoryFailure(phase="history_read") from exc


def history_page(binding: NotebookBinding, before: str | None = None):
    store = binding.store
    if before is not None:
        _commit(before)
    with store.lock():
        head = _head(store)
        rows = []
        if before is not None:
            _ancestor(store, before, head)
        if head:
            args = ["log", "--max-count=" + str(PAGE_SIZE + 1), "--format=%H%x09%aI%x09%s"]
            if before:
                args.append("--skip=1")
            try:
                raw = store.git(*args, before or head, "--", store.path.name)
            except (subprocess.CalledProcessError, OSError) as exc:
                raise HistoryFailure(phase="history_read") from exc
            for row in raw.split("\n"):
                if not row:
                    continue
                commit, date, message = row.split("\t", 2)
                rows.append({"commit": commit, "date": date, "message": message[:500]})
    more = len(rows) > PAGE_SIZE
    rows = rows[:PAGE_SIZE]
    return {
        "schema_version": 1,
        "session_id": binding.session_id,
        "binding_id": binding.binding_id,
        "head": head,
        "versions": rows,
        "next_before": rows[-1]["commit"] if more else None,
    }


def historical_document(binding: NotebookBinding, commit: str):
    store = binding.store
    _commit(commit)
    with store.lock():
        _ancestor(store, commit, _head(store))
        try:
            size = int(store.git("cat-file", "-s", f"{commit}:{store.path.name}").strip())
            if size > MAX_DOCUMENT_BYTES:
                raise HTTPException(413, "Saved notebook exceeds the history viewer size limit")
            raw = store.version(commit)
        except (subprocess.CalledProcessError, OSError) as exc:
            raise HistoryFailure(phase="history_read") from exc
        except (UnicodeError, ValueError) as exc:
            raise HTTPException(404, "Saved notebook not found") from exc
    try:
        doc = decode(raw, store.path.suffix)
    except (ValueError, TypeError, UnicodeError) as exc:
        raise HTTPException(422, "Saved notebook could not be read") from exc
    if len(doc.nodes) > MAX_NODES:
        raise HTTPException(413, "Saved notebook has too many cells for this viewer")
    return {
        "schema_version": 1,
        "session_id": binding.session_id,
        "binding_id": binding.binding_id,
        "commit": commit,
        "read_only": True,
        "document": project_document(binding, doc, digest(raw), read_only=True),
    }
