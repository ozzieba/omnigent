"""Omnigent transport integration; its transcript never becomes model context."""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import threading
from pathlib import Path

from .document import Node, canonical, digest
from .store import Conflict, Store


def _content(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(
            item["text"]
            for item in value
            if isinstance(item, dict)
            and item.get("type") in {"text", "input_text"}
            and isinstance(item.get("text"), str)
        )
    return ""


def ingest(store: Store, value, instructions: str, event_id: str):
    for _ in range(10):
        try:
            return _ingest(store, value, instructions, event_id)
        except Conflict:
            continue
    raise Conflict("Document busy while recording Omnigent input")


def _ingest(store: Store, value, instructions: str, event_id: str):
    """Persist current human input; prior assistant/tool history is transport-only."""
    human_id = event_id
    if isinstance(value, list) and any(isinstance(x, dict) and "role" in x for x in value):
        latest = next(
            (x for x in reversed(value) if isinstance(x, dict) and x.get("role") == "user"), None
        )
        text = _content(latest.get("content")) if latest else ""
        if latest:
            human_id = latest.get("id") or event_id
    else:
        text = _content(value)
    doc, revision = store.read()
    modified = False
    if instructions:
        address = "omnigent-instructions"
        if any(n.id == address for n in doc.nodes):
            if doc.get(address).source != instructions:
                doc.update(address, source=instructions)
                modified = True
        else:
            doc.insert(
                Node(
                    address,
                    "markdown",
                    instructions,
                    metadata={"docloop_role": "instructions", "pinned": True},
                )
            )
            modified = True
    address = "input-" + digest(str(human_id))[:24]
    if text and not any(n.id == address for n in doc.nodes):
        doc.insert(Node(address, "markdown", text, metadata={"docloop_role": "human"}))
        modified = True
    if modified:
        store.save(doc, revision, "Omnigent human input")


def cumulative_usage(previous, current, model=None):
    """Scaffold expects turn totals in Responses names, not Chat aliases."""
    result = dict(previous or {})
    input_tokens = current.get("input_tokens", current.get("prompt_tokens", 0)) or 0
    output_tokens = current.get("output_tokens", current.get("completion_tokens", 0)) or 0
    normalized = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": current.get("total_tokens", input_tokens + output_tokens) or 0,
        "cache_read_input_tokens": current.get(
            "cache_read_input_tokens",
            (current.get("prompt_tokens_details") or {}).get("cached_tokens", 0),
        )
        or 0,
        "cache_creation_input_tokens": current.get("cache_creation_input_tokens", 0) or 0,
    }
    if current.get("cost_usd") is not None and (previous is None or "cost_usd" in previous):
        normalized["cost_usd"] = current["cost_usd"]
    else:
        # SDK treats cost_usd as authoritative for the entire turn. A partial
        # known cost must not replace its token-based estimate for all calls.
        result.pop("cost_usd", None)
    for key, value in normalized.items():
        result[key] = result.get(key, 0) + value
    result["context_tokens"] = current.get("context_tokens", input_tokens)
    if current.get("model") or model:
        result["model"] = current.get("model") or model
    return result


def record_status(store, status, steps):
    for _ in range(10):
        doc, revision = store.read()
        source = canonical({"status": status, "steps": steps})
        if any(n.id == "omnigent-status" for n in doc.nodes):
            doc.update("omnigent-status", source=source)
        else:
            doc.insert(Node("omnigent-status", "raw", source, language="json"))
        try:
            store.save(doc, revision, "Omnigent " + status)
            return
        except Conflict:
            continue
    raise Conflict("Document busy while recording Omnigent status")


def contribution():
    from omnigent.harness_plugins import HarnessContribution

    return HarnessContribution(
        name="docloop",
        valid_harnesses=frozenset({"docloop"}),
        harness_modules={"docloop": "omnigent.community.harness.docloop"},
        model_env_keys={"docloop": "DOCLOOP_MODEL"},
        harness_labels={"docloop": "Document (Jupyter / Org)"},
    )


def configured_document_path() -> Path:
    workspace = Path(os.environ.get("OMNIGENT_RUNNER_WORKSPACE", os.getcwd()))
    return Path(os.environ.get("DOCLOOP_DOCUMENT", str(workspace / "agent.ipynb"))).resolve()


def create_app(*, notebook_resolver=None, native_notebook=None):
    from argparse import Namespace

    from omnigent.runtime.harnesses._scaffold import HarnessApp
    from omnigent.server.schemas import OutputItemDoneEvent, OutputTextDeltaEvent

    from .cli import runtime
    from .omnigent_tools import ToolBridge
    from .runner_notebook import RunnerNotebook, native_notebook_enabled

    native_enabled = native_notebook_enabled(native_notebook)
    if native_enabled and notebook_resolver is not None:
        raise ValueError("Choose native runner binding OR an external notebook resolver, not both")
    runner_notebook = None
    runner_jupyter = None

    class DocumentHarness(HarnessApp):
        async def on_shutdown(self):
            if runner_jupyter is not None:
                await asyncio.to_thread(runner_jupyter.close)

        async def run_turn(self, request, ctx):
            workspace = (
                runner_notebook.workspace
                if runner_notebook is not None
                else Path(os.environ.get("OMNIGENT_RUNNER_WORKSPACE", os.getcwd()))
            )
            store = (
                await asyncio.to_thread(runner_notebook.for_turn, app)
                if runner_notebook is not None
                else Store(configured_document_path())
            )
            path = store.path
            ingest(store, request.input, request.instructions or "", ctx.response_id)
            max_steps = int(os.environ.get("DOCLOOP_MAX_STEPS", "20"))
            if not 1 <= max_steps <= 1000:
                raise ValueError("DOCLOOP_MAX_STEPS must be between 1 and 1000")
            args = Namespace(
                workspace=str(workspace),
                environment=os.environ.get("DOCLOOP_ENVIRONMENT"),
                image=os.environ.get("DOCLOOP_IMAGE"),
                runtime=os.environ.get("DOCLOOP_OCI_RUNTIME"),
                mcp_config=os.environ.get("DOCLOOP_MCP_CONFIG"),
                timeout=60,
                budget_bytes=int(os.environ.get("DOCLOOP_BUDGET_BYTES", "24000")),
                steps=max_steps,
            )
            bridge = ToolBridge(
                ctx,
                request.tools,
                request.model,
                timeout=float(os.environ.get("DOCLOOP_OMNIGENT_TOOL_TIMEOUT", "60")),
            )
            execute = None
            owned_executors = []
            stop = threading.Event()
            status, steps = "paused", 0
            try:
                requested_model = request.model
                # The reserved harness selector requests the configured default.
                if requested_model == "docloop":
                    requested_model = None
                execute, factory = runtime(store, args, mcp_dispatch=bridge, model=requested_model)
                from .python_objects import enabled

                if execute is not None and runner_jupyter is not None and enabled(store.read()[0]):
                    from .notebook_api import NotebookBinding

                    native = runner_jupyter.native(
                        NotebookBinding(app.state.conversation_id, store)
                    )
                    native.app.executor = execute
                    execute.native_jupyter = native
                if execute is not None:
                    owned_executors.append(execute)
                if factory is None:
                    raise ValueError(
                        "Docloop provider unavailable: configure DOCLOOP_MODEL and the "
                        "selected provider endpoint/credential before starting inference"
                    )
                engine = factory()
                evaluator = getattr(engine, "evaluator", None)
                if evaluator is not None and not any(evaluator is e for e in owned_executors):
                    owned_executors.append(evaluator)
                for index in range(max_steps):
                    if ctx.cancelled.is_set():
                        status = "stopped"
                        break
                    stop = threading.Event()
                    steered = False
                    task = asyncio.create_task(asyncio.to_thread(engine.step, stop))
                    try:
                        while not task.done():
                            if ctx.cancelled.is_set():
                                stop.set()
                            injected = await ctx.next_injection(timeout=0.1)
                            if injected is not None:
                                stop.set()
                                steered = True
                                ingest(
                                    store,
                                    injected.input,
                                    injected.instructions or "",
                                    ctx.response_id + "-" + os.urandom(8).hex(),
                                )
                        result = await task
                        steps = index + 1
                        # A fast final step can finish with more than one queued
                        # injection. Materialize the backlog before ending this
                        # turn, including when the step bound is exhausted.
                        while True:
                            injected = await ctx.next_injection(timeout=0.001)
                            if injected is None:
                                break
                            steered = True
                            ingest(
                                store,
                                injected.input,
                                injected.instructions or "",
                                ctx.response_id + "-" + os.urandom(8).hex(),
                            )
                    except asyncio.CancelledError:
                        stop.set()
                        await asyncio.shield(task)
                        raise
                    if message := result.get("message"):
                        # Only Engine's committed prose becomes an assistant message.
                        message_id = (
                            "msg_docloop_" + digest(str(store.path) + ":" + message["node_id"])[:32]
                        )
                        ctx.emit(
                            OutputTextDeltaEvent(
                                type="response.output_text.delta",
                                delta=message["text"],
                                message_id=message_id,
                                index=0,
                                final=True,
                            )
                        )
                        # Message-scoped deltas are not re-buffered by the AP relay.
                        ctx.emit(
                            OutputItemDoneEvent(
                                type="response.output_item.done",
                                item={
                                    "id": message_id,
                                    "type": "message",
                                    "status": "completed",
                                    "role": "assistant",
                                    "agent": "docloop",
                                    "content": [{"type": "output_text", "text": message["text"]}],
                                },
                            )
                        )
                    else:
                        ctx.emit(
                            OutputTextDeltaEvent(
                                type="response.output_text.delta",
                                delta=f"Document {path.name}: {result}\n",
                            )
                        )
                    if result.get("usage"):
                        ctx.provider_usage = cumulative_usage(
                            ctx.provider_usage,
                            result["usage"],
                            getattr(engine.provider, "model", None),
                        )
                    if ctx.cancelled.is_set():
                        status = "stopped"
                        break
                    if steered or result.get("retryable"):
                        continue
                    if result.get("error"):
                        status = "error"
                        raise RuntimeError(result["error"])
                    if result.get("done"):
                        status = "completed"
                        break
                if status == "paused":
                    ctx.emit(
                        OutputTextDeltaEvent(
                            type="response.output_text.delta",
                            delta=f"Paused after {steps} document steps; send another message to continue.\n",
                        )
                    )
            except asyncio.CancelledError:
                status = "stopped"
                raise
            except Exception:
                status = "error"
                raise
            finally:
                primary_error = sys.exc_info()[1]
                stop.set()
                cleanup_errors = []
                try:
                    bridge.cancel()
                except (Exception, asyncio.CancelledError) as exc:
                    cleanup_errors.append(("tool cancellation", exc))
                # Each owned resource gets an attempt even when another cleanup fails.
                closed_teams = []
                for executor in owned_executors:
                    team = getattr(executor, "team", None)
                    if team is None or any(team is t for t in closed_teams):
                        continue
                    closed_teams.append(team)
                    try:
                        await asyncio.to_thread(team.close, timeout=10)
                    except (Exception, asyncio.CancelledError) as exc:
                        cleanup_errors.append(("child execution cleanup", exc))
                for executor in owned_executors:
                    if callable(getattr(executor, "close", None)):
                        try:
                            await asyncio.to_thread(executor.close)
                        except (Exception, asyncio.CancelledError) as exc:
                            cleanup_errors.append(("Python execution cleanup", exc))
                try:
                    await bridge.close()
                except (Exception, asyncio.CancelledError) as exc:
                    cleanup_errors.append(("tool bridge cleanup", exc))
                if ctx.cancelled.is_set() or isinstance(primary_error, asyncio.CancelledError):
                    status = "stopped"
                elif any(isinstance(exc, asyncio.CancelledError) for _, exc in cleanup_errors):
                    status = "stopped"
                elif cleanup_errors:
                    status = "error"
                try:
                    record_status(store, status, steps)
                except (Exception, asyncio.CancelledError) as exc:
                    cleanup_errors.append(("status persistence", exc))
                if cleanup_errors:
                    detail = ", ".join(name for name, _ in cleanup_errors)
                    if primary_error is not None:
                        note = "Docloop cleanup incomplete: " + detail
                        if hasattr(primary_error, "add_note"):
                            primary_error.add_note(note)
                        else:
                            logging.getLogger(__name__).warning(note)
                    else:
                        for _, exc in cleanup_errors:
                            if isinstance(exc, asyncio.CancelledError):
                                raise exc
                        raise RuntimeError(
                            "Docloop cleanup incomplete: " + detail
                        ) from cleanup_errors[0][1]

    harness = DocumentHarness()
    if native_enabled:
        runner_notebook = RunnerNotebook(
            harness,
            configured_document_path(),
            Path(os.environ.get("OMNIGENT_RUNNER_WORKSPACE", os.getcwd())),
        )
    app = harness.build()
    if runner_notebook is not None:
        from .runner_jupyter import RunnerJupyter

        app.state.docloop_notebook = runner_notebook
        notebook_resolver = runner_notebook.resolve
        runner_jupyter = RunnerJupyter(runner_notebook)
        app.state.docloop_jupyter = runner_jupyter
        app.include_router(runner_jupyter.router())
    if notebook_resolver is not None:
        from .notebook_api import notebook_router

        app.include_router(notebook_router(notebook_resolver))
    return app
