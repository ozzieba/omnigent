"""Opt-in notebook access inside Omnigent's existing per-conversation runner.

The launcher owns app.state.conversation_id and app.state.harness_auth_token.
No browser value selects a file or initializes a session. This module does not
register a central-server proxy or introduce another authentication credential.
"""

from __future__ import annotations

import asyncio
import os
import threading
from pathlib import Path
from typing import Literal

from fastapi import HTTPException, Request

from .notebook_api import SESSION_ID, NotebookBinding
from .store import Store


def native_notebook_enabled(explicit: bool | None = None) -> bool:
    """Default off; reject misspelled configuration rather than silently enabling."""
    if explicit is not None:
        if type(explicit) is not bool:
            raise ValueError("native_notebook must be a bool or None")
        return explicit
    setting = os.environ.get("DOCLOOP_NATIVE_NOTEBOOK", "0")
    if setting not in {"0", "1"}:
        raise ValueError("DOCLOOP_NATIVE_NOTEBOOK must be 0 or 1")
    return setting == "1"


class RunnerNotebook:
    """One lazy native Store per configured runner, shared by Engine and pane.

    The configuration is frozen at create_app, before the launcher installs the
    conversation identity. An authenticated first request/turn binds that
    identity; changing it later is a lifecycle error, not a new session.
    """

    def __init__(self, harness, path: Path, workspace: Path):
        if not callable(getattr(harness, "_check_auth", None)) or not callable(
            getattr(harness, "_check_conversation_id", None)
        ):
            raise ValueError("Installed Omnigent scaffold lacks the required runner guards")
        self.harness = harness
        self.path = Path(path).resolve()
        self.workspace = Path(workspace).resolve()
        if self.path.suffix not in {".ipynb", ".org"}:
            raise ValueError("Native notebook must be .ipynb or .org")
        self._lock = threading.RLock()
        self._session_id: str | None = None
        self._store: Store | None = None

    def _session(self, app) -> str:
        session_id = getattr(app.state, "conversation_id", None)
        if not isinstance(session_id, str) or not SESSION_ID.fullmatch(session_id):
            raise HTTPException(503, "Native runner conversation is not initialized")
        with self._lock:
            if self._session_id is not None and self._session_id != session_id:
                raise HTTPException(503, "Native runner conversation binding changed; restart it")
            self._session_id = session_id
        return session_id

    def _get_store(self, *, initialize: bool) -> Store:
        with self._lock:
            if self.path.resolve() != self.path:
                raise HTTPException(503, "Native document location changed; restart the runner")
            if self._store is None:
                if not initialize:
                    if not self.path.is_file():
                        raise HTTPException(404, "No notebook yet; send the first native chat turn")
                    # Store.__init__ initializes Git. A GET must not manufacture
                    # history for an arbitrary imported file. Existing native
                    # history can be reopened after a runner restart.
                    history = self.path.parent / ("." + self.path.name + ".history")
                    if not (history / "HEAD").is_file() or not (history / "docloop.lock").is_file():
                        raise HTTPException(
                            409, "Notebook history is not initialized; open it through native chat"
                        )
                self._store = Store(self.path)
            return self._store

    def for_turn(self, app) -> Store:
        """Only called by the already-authorized native run_turn lifecycle."""
        self._session(app)
        return self._get_store(initialize=True)

    async def resolve(
        self, request: Request, session_id: str, operation: Literal["read", "edit"]
    ) -> NotebookBinding:
        # The native helper intentionally permits tokenless unit-test apps.
        # Notebook routes never inherit that fallback: missing launcher setup
        # means unavailable, before touching any Store or binding a session.
        token = getattr(request.app.state, "harness_auth_token", None)
        if not isinstance(token, str) or not token:
            raise HTTPException(503, "Native runner authentication is not initialized")
        denied = self.harness._check_auth(request)
        if denied is not None:
            raise HTTPException(401, "Native runner authentication required")
        self.harness._check_conversation_id(request, session_id)
        bound = self._session(request.app)
        if bound != session_id:
            raise HTTPException(404, "Conversation is not served by this runner")
        store = await asyncio.to_thread(self._get_store, initialize=False)
        return NotebookBinding(bound, store)
