"""Execution environment seam. Descriptors are safe to persist in a notebook."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path


@dataclass
class LocalEnvironment:
    workspace: Path | str

    def __post_init__(self):
        self.workspace = Path(self.workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self._runtime = threading.local()

    def prepare(self, command):
        return command, self.workspace

    def descriptor(self):
        return {"kind": "local", "workspace": str(self.workspace)}


@dataclass
class OCIEnvironment(LocalEnvironment):
    image: str = "python:3.12-slim"
    runtime: str = "podman"
    network: str = "none"
    memory: str = "1g"
    cpus: float = 1.0
    pids_limit: int = 128

    def prepare(self, command):
        import sys

        command = list(command)
        if command[0] == sys.executable:
            command[0] = "python3"
        helper = Path(__file__).parent
        # Translate only harness helper argv paths. Cell source is arbitrary text and
        # must remain byte-for-byte unchanged, even when it mentions this directory.
        for index, arg in enumerate(command[:2]):
            if str(arg) in {str(helper / "execution.py"), str(helper / "mcp_bridge.py")}:
                command[index] = "/docloop-runtime/" + Path(arg).name
        name = "docloop-" + __import__("uuid").uuid4().hex
        self._runtime.active_name = name
        return [
            self.runtime,
            "run",
            "--rm",
            "--pull=never",
            "--name",
            name,
            "-i",
            "--network",
            self.network,
            "--memory",
            self.memory,
            "--cpus",
            str(self.cpus),
            "--pids-limit",
            str(self.pids_limit),
            "--cap-drop=ALL",
            "--security-opt=no-new-privileges",
            "--user",
            f"{__import__('os').getuid()}:{__import__('os').getgid()}",
            "-v",
            f"{self.workspace}:/workspace:rw",
            "-v",
            f"{helper}:/docloop-runtime:ro",
            "-w",
            "/workspace",
            self.image,
            *command,
        ], self.workspace

    def cleanup(self):
        import subprocess

        name = getattr(self._runtime, "active_name", None)
        if name:
            result = subprocess.run(
                [self.runtime, "rm", "-f", name], capture_output=True, timeout=15
            )
            if result.returncode:
                remaining = subprocess.run(
                    [self.runtime, "container", "inspect", name], capture_output=True, timeout=15
                )
                if remaining.returncode == 0:
                    raise RuntimeError(f"Failed to remove owned container {name}")

    def descriptor(self):
        return {
            "kind": "oci",
            "workspace": str(self.workspace),
            "image": self.image,
            "runtime": self.runtime,
            "network": self.network,
            "memory": self.memory,
            "cpus": self.cpus,
            "pids_limit": self.pids_limit,
        }


def environment_from_descriptor(descriptor):
    """Reconstruct runtime options recorded in the document without hidden defaults."""
    descriptor = dict(descriptor)
    kind = descriptor.pop("kind")
    if kind == "local":
        allowed = {"workspace"}
        factory = LocalEnvironment
    elif kind == "oci":
        allowed = {"workspace", "image", "runtime", "network", "memory", "cpus", "pids_limit"}
        factory = OCIEnvironment
    else:
        raise ValueError(f"Unknown environment kind: {kind}")
    # Workspace-copy provenance is document information, not a runtime option.
    descriptor.pop("workspace_mode", None)
    if set(descriptor) - allowed:
        raise ValueError("Unknown environment descriptor fields")
    return factory(**descriptor)
