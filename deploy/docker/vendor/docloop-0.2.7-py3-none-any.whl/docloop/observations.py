"""Small factual execution summaries derived only from notebook receipts/outputs."""

from .document import digest


def execution_summary(node):
    receipt = node.metadata.get("docloop_execution")
    if not isinstance(receipt, dict):
        return None
    errors = []
    for output in node.outputs:
        if not isinstance(output, dict) or output.get("output_type") != "error":
            continue
        error = {
            "type": str(output.get("ename", "error"))[:64],
            "message": str(output.get("evalue", ""))[:240],
        }
        if error not in errors:
            errors.append(error)
    # Some transports append a generic error after the real Jupyter diagnostic.
    meaningful = [e for e in errors if e != {"type": "error", "message": "error"}]
    return {
        "status": str(receipt.get("status", "unknown"))[:32],
        "source_current": receipt.get("source_hash") == digest(node.language + "\n" + node.source),
        **({"exit_code": receipt["exit_code"]} if type(receipt.get("exit_code")) is int else {}),
        **({"errors": (meaningful or errors)[-2:]} if errors else {}),
    }
