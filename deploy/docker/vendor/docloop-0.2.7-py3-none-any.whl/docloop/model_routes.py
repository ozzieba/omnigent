"""Operator-configured model choices; requests carry IDs, never endpoints or secrets."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping

_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/+-]{0,199}\Z")
_FIELDS = {
    "provider": "DOCLOOP_PROVIDER",
    "llmq_url": "DOCLOOP_LLMQ_URL",
    "endpoint": "DOCLOOP_ENDPOINT",
    "reasoning_effort": "DOCLOOP_REASONING_EFFORT",
}


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate key in DOCLOOP_MODEL_ROUTES")
        result[key] = value
    return result


class ModelCatalog:
    """Snapshot deployment configuration without mutating the process environment."""

    def __init__(self, environ: Mapping[str, str]):
        self._environ = dict(environ)
        self.default = self._environ.get("DOCLOOP_MODEL", "").strip()
        raw = self._environ.get("DOCLOOP_MODELS", "")
        choices = list(dict.fromkeys(x.strip() for x in raw.split(",") if x.strip()))
        if not self.default:
            raise ValueError("Set DOCLOOP_MODEL to an explicitly selected metered model")
        self.models = tuple(choices or [self.default])
        if len(self.models) > 100 or any(not _ID.fullmatch(x) for x in self.models):
            raise ValueError("Invalid configured model identifiers")
        if self.default not in self.models:
            raise ValueError("DOCLOOP_MODEL must be included in DOCLOOP_MODELS")
        try:
            routes = json.loads(
                self._environ.get("DOCLOOP_MODEL_ROUTES", "{}"), object_pairs_hook=_object
            )
        except (TypeError, json.JSONDecodeError) as exc:
            raise ValueError("Invalid DOCLOOP_MODEL_ROUTES JSON") from exc
        if not isinstance(routes, dict) or set(routes) - set(self.models):
            raise ValueError("Model routes must name configured models only")
        for route in routes.values():
            if not isinstance(route, dict) or set(route) - set(_FIELDS):
                raise ValueError("Model routes accept provider, llmq_url and endpoint only")
            if any(not isinstance(v, str) or not v.strip() for v in route.values()):
                raise ValueError("Model route values must be nonempty strings")
            if route.get("provider", "llmq") not in {"llmq", "llmq-api", "chat", "codex-cli"}:
                raise ValueError("Unknown model route provider")
        self._routes = routes

    def resolve(self, model=None):
        selected = self.default if model is None else model
        if not isinstance(selected, str) or selected not in self.models:
            raise ValueError("Selected model is not configured; no fallback was attempted")
        return selected

    def environment(self, model=None):
        selected = self.resolve(model)
        env = dict(self._environ)
        for field, value in self._routes.get(selected, {}).items():
            env[_FIELDS[field]] = value
        env["DOCLOOP_MODEL"] = selected
        return env

    def public(self):
        # No endpoint, credential, header or filesystem path is a browser field.
        return {"default_model": self.default, "models": list(self.models)}
