"""Private, content-addressed Python namespace lineage. Load only in the kernel."""

from __future__ import annotations

import copyreg
import hashlib
import io
import json
import os
import re
import sys
import tempfile
from types import ModuleType

from .document import digest, pretty

MODULE = "_docloop_session"
MAX_BYTES = 64 * 1024 * 1024
SHA = re.compile(r"[a-f0-9]{64}")


def _restore_match(pattern, string, pos, endpos, span, groups):
    """Recreate a regex result without silently discarding a session variable."""
    candidates = (
        pattern.fullmatch(string, pos, endpos),
        pattern.match(string, pos, endpos),
        pattern.search(string, span[0], endpos),
    )
    for candidate in candidates:
        if candidate is not None and candidate.span() == span and candidate.groups() == groups:
            return candidate
    raise ValueError("Python checkpoint regex match could not be restored")


def _reduce_match(value):
    return (
        _restore_match,
        (value.re, value.string, value.pos, value.endpos, value.span(), value.groups()),
    )


copyreg.pickle(re.Match, _reduce_match)


class BoundedBuffer(io.BytesIO):
    def write(self, value):
        if self.tell() + len(value) > MAX_BYTES:
            raise ValueError("Python checkpoint exceeds 64 MiB")
        return super().write(value)


def namespace():
    module = ModuleType(MODULE)
    # Register before serialization/loading so function globals retain their identity.
    sys.modules[MODULE] = module
    return module


class CheckpointStore:
    def __init__(self, store):
        self.store = store
        self.directory = store.history_dir / "python-state"
        self.directory.mkdir(mode=0o700, exist_ok=True)
        self.pointer = self.directory / "CURRENT"
        self.selected = self.head()

    def head(self):
        if not self.pointer.exists():
            return None
        value = self.pointer.read_text().strip()
        if not SHA.fullmatch(value):
            raise ValueError("Invalid Python checkpoint pointer")
        return value

    def _read(self, ident, suffix, limit=MAX_BYTES):
        if not isinstance(ident, str) or not SHA.fullmatch(ident):
            raise ValueError("Expected a checkpoint content hash")
        path = self.directory / (ident + suffix)
        with path.open("rb") as stream:
            raw = stream.read(limit + 1)
        if len(raw) > limit or hashlib.sha256(raw).hexdigest() != ident:
            raise ValueError("Python checkpoint content does not match its hash")
        return raw

    def manifest(self, ident):
        value = json.loads(self._read(ident, ".json", 65536))
        if value.get("version") != 1 or value.get("document") != digest(str(self.store.path)):
            raise ValueError("Python checkpoint belongs to a different document")
        if value.get("parent") is not None and not SHA.fullmatch(value["parent"]):
            raise ValueError("Invalid Python lineage parent")
        return value

    def history(self, limit=50):
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError("Python history limit must be 1..1000")
        result, current, seen = [], self.head(), set()
        while current and len(result) < limit:
            if current in seen:
                raise ValueError("Python lineage contains a cycle")
            seen.add(current)
            manifest = self.manifest(current)
            result.append({"id": current, **manifest})
            current = manifest["parent"]
        return result

    def _write(self, raw, suffix):
        ident = hashlib.sha256(raw).hexdigest()
        path = self.directory / (ident + suffix)
        try:
            with path.open("xb") as stream:
                os.chmod(path, 0o600)
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
        except FileExistsError:
            if self._read(ident, suffix) != raw:
                raise ValueError("Checkpoint content collision")
        return ident

    def save(self, module, *, code, restored_from=None):
        import dill

        parent = self.selected
        buffer = BoundedBuffer()
        # A failure leaves CURRENT unchanged. Unsupported values are never dropped.
        dill.dump_module(buffer, module=module)
        blob = self._write(buffer.getvalue(), ".pickle")
        manifest = {
            "version": 1,
            "document": digest(str(self.store.path)),
            "parent": parent,
            "namespace": blob,
            "notebook_revision_observed": self.store.read()[1],
            "code_sha256": digest(code),
            "python": list(sys.version_info[:3]),
            "serializer": {"name": "dill", "version": dill.__version__},
            "bytes": len(buffer.getvalue()),
            "restored_from": restored_from,
        }
        ident = self._write(pretty(manifest).encode(), ".json")
        with self.store.lock():
            if self.head() != parent:
                raise ValueError("Python lineage advanced; checkpoint not selected")
            fd, temporary = tempfile.mkstemp(dir=self.directory, prefix=".head-")
            try:
                with os.fdopen(fd, "w") as stream:
                    stream.write(ident + "\n")
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, self.pointer)
                directory = os.open(self.directory, os.O_DIRECTORY)
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        self.selected = ident
        return {"id": ident, **manifest}

    def load(self, ident=None):
        import dill

        current = self.head()
        self.selected = current
        if ident is not None:
            ancestor, seen = current, set()
            while ancestor != ident:
                if ancestor is None or ancestor in seen or len(seen) >= 10000:
                    raise ValueError("Requested Python checkpoint is not in the current lineage")
                seen.add(ancestor)
                ancestor = self.manifest(ancestor)["parent"]
            current = ident
        if current is None:
            return namespace()
        manifest = self.manifest(current)
        if manifest["python"] != list(sys.version_info[:3]) or manifest["serializer"] != {
            "name": "dill",
            "version": dill.__version__,
        }:
            raise ValueError(
                "Python or serializer version changed; use the recorded environment to restore"
            )
        raw = self._read(manifest["namespace"], ".pickle")
        previous = sys.modules.get(MODULE)
        module = namespace()
        try:
            dill.load_module(io.BytesIO(raw), module=module)
        except BaseException:
            if previous is not None:
                sys.modules[MODULE] = previous
            else:
                sys.modules.pop(MODULE, None)
            raise
        return module


class RestorePython(Exception):
    """End the current cell and replace its namespace with a selected ancestor."""
