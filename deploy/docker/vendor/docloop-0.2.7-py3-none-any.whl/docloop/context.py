"""Deterministic UTF-8 bounded document projection; no persistent process memory."""

from __future__ import annotations

from dataclasses import dataclass

from .document import Document, canonical, digest
from .observations import execution_summary


def clip(text: str, limit: int) -> str:
    raw = text.encode()
    if len(raw) <= limit:
        return text
    marker = b"\n... [omitted; read by address] ...\n"
    if limit < len(marker):
        return raw[: max(0, limit)].decode("utf-8", "ignore")
    available = limit - len(marker)
    return (
        raw[: available * 3 // 4].decode("utf-8", "ignore")
        + marker.decode()
        + (
            raw[-(available - available * 3 // 4) :] if available - available * 3 // 4 else b""
        ).decode("utf-8", "ignore")
    )


@dataclass(frozen=True)
class Projection:
    text: str
    receipt: dict
    unchanged_prefix_nodes: list[str]
    omitted: list[str]


def project(doc: Document, budget_bytes: int = 24000, node_bytes: int = 4096) -> Projection:
    from .python_objects import CONVERSATION_ROLES, STATE_KEY, VIEW_SOURCES, enabled

    python_state = enabled(doc)
    if budget_bytes < 1024 or node_bytes < 256:
        raise ValueError("Projection requires budget >= 1024 and node_bytes >= 256")
    # Reserved footer and metadata space keeps node quotas independent of content.
    metadata = {
        k: v
        for k, v in doc.metadata.items()
        if k not in {"docloop_cache", "docloop_provider_usage", STATE_KEY}
    }
    header = "DOCUMENT\nmetadata=" + clip(canonical(metadata), min(512, budget_bytes // 8)) + "\n"
    instructions = [
        n
        for n in doc.nodes
        if n.metadata.get("docloop_role") == "user_instruction"
        and n.metadata.get("instruction_status") in {"pending", "active", "paused"}
    ]
    instruction_text = ""
    if instructions:
        source = "\n".join(f"[{n.id}] {n.source}" for n in reversed(instructions))
        if python_state and len(source.encode()) > budget_bytes // 3:
            raise ValueError("Python instructions exceed instruction byte budget")
        instruction_text = (
            "\nCURRENT HUMAN INSTRUCTIONS (latest first; read omitted content by address)\n"
            + (source if python_state else clip(source, budget_bytes // 3))
            + "\n"
        )
    footer_bound = (
        len(
            (
                f"\nPROJECTION omitted={len(doc.nodes)} addresses="
                "\nCache candidate unchanged prefix nodes= (not provider cache confirmation).\n"
            ).encode()
        )
        + 160
        + 120
    )
    available = budget_bytes - len(header.encode()) - footer_bound - len(instruction_text.encode())
    cap = min(node_bytes, max(256, available // 2))
    chunks = []
    for node in doc.nodes:
        if python_state and node.metadata.get("docloop_role") in CONVERSATION_ROLES | {
            "tool_inventory"
        }:
            continue
        label = f"\n[{node.id}] kind={node.kind} language={clip(node.language, 64)} level={node.level}\n"
        execution = execution_summary(node)
        if execution is not None:
            label += "execution=" + clip(canonical(execution), min(512, cap // 2)) + "\n"
        if node.metadata:
            label += "metadata=" + clip(canonical(node.metadata), min(256, cap // 8)) + "\n"
        # Source has priority; outputs lose their middle first.
        source_budget = cap - len(label.encode()) - 80
        if python_state and node.id in VIEW_SOURCES:
            # A long view definition must not crowd out its rendered instructions.
            source_budget = min(source_budget, cap // 3)
        source = clip(node.source, source_budget)
        rest = cap - len((label + source).encode()) - 30
        output = "\noutputs=" + clip(canonical(node.outputs), max(0, rest)) if node.outputs else ""
        chunks.append((node.id, label + source + output + "\n"))
    # Keep a stable leading prefix and latest nodes (new human input remains visible).
    selected = [
        i for i, (address, _) in enumerate(chunks) if python_state and address in VIEW_SOURCES
    ]
    used = sum(len(chunks[i][1].encode()) for i in selected)
    if used > available:
        raise ValueError("Python context views exceed the document byte budget")
    prefix_budget = used + (available - used) // 2
    for index, (_, chunk) in enumerate(chunks):
        if index in selected:
            continue
        if used + len(chunk.encode()) > prefix_budget:
            break
        selected.append(index)
        used += len(chunk.encode())
    for index in reversed(range(len(chunks))):
        if index in selected:
            continue
        size = len(chunks[index][1].encode())
        if used + size <= available:
            selected.append(index)
            used += size
    selected.sort()
    omitted = [address for i, (address, _) in enumerate(chunks) if i not in selected]
    entries = [{"id": chunks[i][0], "hash": digest(chunks[i][1])} for i in selected]
    previous = doc.metadata.get("docloop_cache", {}).get("nodes", [])
    unchanged = []
    if doc.metadata.get("docloop_cache", {}).get("header") == digest(header):
        for current, old in zip(entries, previous):
            if current != old:
                break
            unchanged.append(current["id"])
    footer = (
        "\nPROJECTION omitted=" + str(len(omitted)) + " addresses=" + clip(",".join(omitted), 160)
    )
    footer += "\nCache candidate unchanged prefix nodes=" + clip(",".join(unchanged), 120)
    footer += " (not provider cache confirmation).\n"
    text = header + "".join(chunks[i][1] for i in selected) + instruction_text + footer
    assert len(text.encode()) <= budget_bytes
    return Projection(text, {"header": digest(header), "nodes": entries}, unchanged, omitted)
