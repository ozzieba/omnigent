"""Private local object transport; no provider-visible connector tool definitions."""

from __future__ import annotations

import asyncio
import json
import os
import socketserver
import threading
import uuid
from pathlib import Path

from .document import pretty
from .python_objects import STATE_KEY, conversation_from


class PythonObjectsServer:
    def __init__(self, app, directory):
        self.app = app
        self.cancel_event = None
        self.path = str(Path(directory) / "python-objects.sock")
        owner = self

        class Handler(socketserver.StreamRequestHandler):
            def handle(self):
                self.connection.settimeout(65)
                raw = self.rfile.readline(1_000_001)
                try:
                    if len(raw) > 1_000_000 or not raw.endswith(b"\n"):
                        raise ValueError("Python object request exceeds its limit")
                    request = json.loads(raw)
                    result = {"result": owner.call(request["method"], request["arguments"])}
                except Exception as exc:
                    result = {"error": f"{type(exc).__name__}: {exc}"}
                data = pretty(result).encode()
                if len(data) > 16_000_000:
                    data = b'{"error":"Python object result exceeds its limit"}'
                self.wfile.write(json.dumps(json.loads(data), ensure_ascii=False).encode() + b"\n")

        class Server(socketserver.ThreadingUnixStreamServer):
            daemon_threads = True

        self.server = Server(self.path, Handler)
        os.chmod(self.path, 0o600)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def call(self, method, arguments):
        if self.app._closed:
            raise ValueError("Session is closing")
        store = self.app.store
        if method == "state":
            doc, _ = store.read()
            return {
                "document": str(store.path),
                "tools": doc.metadata.get(STATE_KEY, {}).get("tools", []),
                "conversation": conversation_from(doc),
                "connectors": sorted(getattr(self.app.executor, "mcp_config", {})),
            }
        executor = self.app.executor
        event = self.cancel_event
        if event is not None and event.is_set():
            raise InterruptedError("Python execution was cancelled before object dispatch")
        if method == "eval":
            node = store.read()[0].get(arguments["address"])
            if node.language in {"python", "python3", "jupyter", "jupyter-python"}:
                raise ValueError("Python cells must run in their current kernel namespace")
            revision = executor(arguments["address"], arguments["revision"], cancel_event=event)
            return {
                "revision": revision,
                "outputs": store.read()[0].get(arguments["address"]).outputs,
            }
        if method not in {"tool", "mcp", "team"}:
            raise ValueError("Unknown Python object method")
        call_id = uuid.uuid4().hex
        journal = store.history_dir / "python-calls"
        journal.mkdir(mode=0o700, exist_ok=True)
        before = {
            "id": call_id,
            "method": method,
            "arguments": arguments,
            "status": "running",
            "notebook_revision": store.read()[1],
        }

        def record(suffix, value):
            path = journal / (call_id + suffix + ".json")
            with path.open("x") as stream:
                os.chmod(path, 0o600)
                stream.write(pretty(value))
                stream.flush()
                os.fsync(stream.fileno())

        record("-start", before)
        try:
            if method == "team":
                if getattr(executor, "team", None) is None:
                    raise ValueError("Team execution is not configured")
                result = executor.team.dispatch(arguments)
                record("-finish", {"status": "returned", "result": result})
                return result
            if method == "tool":
                bridge = getattr(executor, "mcp_dispatch", None)
                if bridge is None:
                    raise ValueError("No active Omnigent tool dispatcher")
                outcome = bridge(
                    {
                        "server": "omnigent",
                        "op": "call",
                        "tool": arguments["name"],
                        "arguments": arguments.get("arguments", {}),
                    },
                    call_id=call_id,
                    cancel_event=event,
                )
                record("-finish", outcome)
                if outcome["status"] != "ok":
                    raise RuntimeError(outcome["output"])
                try:
                    return json.loads(outcome["output"])
                except ValueError:
                    return outcome["output"]
            from .mcp_bridge import evaluate

            result = asyncio.run(evaluate(arguments, executor.mcp_config))
            record("-finish", {"status": "returned", "result": result})
            return result
        except BaseException:
            # A start without finish is an unknown effect, never a retry instruction.
            raise

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
