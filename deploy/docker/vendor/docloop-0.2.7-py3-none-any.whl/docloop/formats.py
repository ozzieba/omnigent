"""Native format adapters; parser trivia preserves unedited Org text exactly."""

from __future__ import annotations

import copy
import json
import re

from .document import Document, Node, canonical, digest


def _text(value):
    return "".join(value) if isinstance(value, list) else value


def _fresh_id(preferred, raw, index, used):
    candidate = preferred or f"n-{digest(str(index) + raw)[:16]}"
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", candidate) or candidate in used:
        candidate = f"n-{digest(str(index) + raw)[:24]}"
    while candidate in used:
        candidate = f"n-{digest(candidate)[:24]}"
    used.add(candidate)
    return candidate


def decode(text: str, suffix: str) -> Document:
    if suffix == ".ipynb":
        raw = json.loads(text)
        if raw.get("nbformat") != 4:
            raise ValueError("Only nbformat v4 is supported")
        doc = Document(
            metadata=raw.get("metadata", {}),
            extra={k: v for k, v in raw.items() if k not in {"cells", "metadata"}},
        )
        used = set()
        for i, cell in enumerate(raw["cells"]):
            metadata = copy.deepcopy(cell.get("metadata", {}))
            semantic = metadata.pop("docloop_node", {})
            # Native editors preserve metadata when converting a cell's type.
            # Preserve our finer markdown roles only while the native type is
            # still markdown; stale metadata must not undo an external conversion.
            native_kind = cell["cell_type"]
            semantic_kind = semantic.get("kind", native_kind)
            kind = (
                semantic_kind
                if native_kind == "markdown" and semantic_kind in {"section", "item", "markdown"}
                else native_kind
            )
            doc.nodes.append(
                Node(
                    id=_fresh_id(cell.get("id"), canonical(cell), i, used),
                    kind=kind,
                    source=_text(cell["source"]),
                    language=semantic.get(
                        "language",
                        raw.get("metadata", {}).get("language_info", {}).get("name", "python"),
                    ),
                    level=semantic.get("level", 1),
                    outputs=cell.get("outputs", []),
                    metadata=metadata,
                    extra={
                        k: v
                        for k, v in cell.items()
                        if k not in {"id", "cell_type", "source", "metadata", "outputs"}
                    },
                )
            )
        doc.validate()
        return doc
    if suffix != ".org":
        raise ValueError(f"Unsupported document format: {suffix}")
    return _decode_org(text)


def encode(doc: Document, suffix: str, *, stabilize: bool = False) -> str:
    doc.validate()
    if suffix == ".ipynb":
        raw = {
            **doc.extra,
            "nbformat": 4,
            "nbformat_minor": 5,
            "metadata": doc.metadata,
            "cells": [],
        }
        for node in doc.nodes:
            cell_type = node.kind if node.kind in {"code", "raw"} else "markdown"
            cell = {
                **node.extra,
                "id": node.id,
                "cell_type": cell_type,
                "source": node.source,
                "metadata": {
                    **node.metadata,
                    "docloop_node": {
                        "kind": node.kind,
                        "language": node.language,
                        "level": node.level,
                    },
                },
            }
            if cell_type == "code":
                cell.update(outputs=node.outputs, execution_count=node.extra.get("execution_count"))
            else:
                cell.pop("execution_count", None)
            raw["cells"].append(cell)
        return json.dumps(raw, ensure_ascii=False, indent=1) + "\n"
    if suffix != ".org":
        raise ValueError(f"Unsupported document format: {suffix}")
    parts = []
    if doc.metadata or doc.extra:
        parts.append(
            "#+DOCLOOP_DOCUMENT: "
            + canonical({"metadata": doc.metadata, "extra": doc.extra})
            + "\n"
        )
    for node in doc.nodes:
        if parts and not parts[-1].endswith(("\n", "\r")):
            parts.append("\n")
        if node.original is not None and node.original_digest == node.fingerprint():
            if stabilize and not node.original.startswith("#+DOCLOOP_NODE: "):
                payload = node.value()
                payload.pop("source")
                parts.append("#+DOCLOOP_NODE: " + canonical(payload) + "\n")
            parts.append(node.original)
            continue
        # The payload preserves semantic data; native text remains editable in Emacs.
        payload = node.value()
        payload.pop("source")
        parts.append("#+DOCLOOP_NODE: " + canonical(payload) + "\n")
        if node.kind == "code":
            headers = node.extra.get("org_headers", "")
            parts.append(f"#+name: {node.id}\n#+begin_src {node.language}{headers}\n")
            parts.append(_escape_org(node.source) + "\n#+end_src\n")
        elif node.kind == "section":
            parts.append("*" * node.level + " " + node.source + "\n")
            if node.extra.get("org_heading_tail"):
                parts.append(node.extra["org_heading_tail"])
        elif node.kind == "item":
            parts.append(node.extra.get("org_bullet", "- ") + node.source + "\n")
        else:
            # Framing prevents Markdown headings and block delimiters being parsed as nodes.
            parts.append(
                "#+begin_docloop_text\n" + _escape_org(node.source) + "\n#+end_docloop_text\n"
            )
        if node.outputs:
            output = "\n".join(
                _text(o.get("text", o.get("data", {}).get("text/plain", ""))) for o in node.outputs
            )
            parts.append(
                f"#+RESULTS: {node.id}\n#+begin_example\n"
                + _escape_org(output)
                + "\n#+end_example\n"
            )
    return "".join(parts)


def _escape_org(text):
    return re.sub(r"(?m)^(,*[\*]|,*#\+)", r",\1", text)


def _unescape_org(text):
    return re.sub(r"(?m)^,(,*[\*]|,*#\+)", r"\1", text)


def _decode_org(text):
    lines = text.splitlines(keepends=True)
    doc = Document()
    used = set()
    i = 0
    while i < len(lines):
        if lines[i].startswith("#+DOCLOOP_DOCUMENT: "):
            payload = json.loads(lines[i].split(": ", 1)[1])
            doc.metadata = payload["metadata"]
            doc.extra = payload["extra"]
            i += 1
            continue
        start = i
        payload = {}
        if lines[i].startswith("#+DOCLOOP_NODE: "):
            payload = json.loads(lines[i].split(": ", 1)[1])
            i += 1
            if i == len(lines):
                raise ValueError("Node marker without content")
        preferred = payload.get("id")
        content_start = i
        name = re.match(r"#\+name:\s*(\S+)\s*$", lines[i], re.I)
        if name and i + 1 < len(lines) and re.match(r"#\+begin_src\s", lines[i + 1], re.I):
            preferred = preferred or name[1]
            i += 1
        code = re.match(r"#\+begin_src\s+(\S+)([^\r\n]*)", lines[i], re.I)
        block = re.match(r"#\+begin_(\w+)", lines[i], re.I)
        heading = re.match(r"(\*+) +(.*?)(?:\r?\n)?$", lines[i])
        item = re.match(r"(\s*(?:[-+] |\d+[.)] ))(.*?)(?:\r?\n)?$", lines[i])
        extra = payload.get("extra", {}).copy()
        if code or lines[i].lower().startswith("#+begin_docloop_text"):
            end_pattern = r"#\+end_src\s*$" if code else r"#\+end_docloop_text\s*$"
            i += 1
            body_start = i
            while i < len(lines) and not re.match(end_pattern, lines[i], re.I):
                i += 1
            if i == len(lines):
                raise ValueError("Unterminated Org block")
            source = _unescape_org("".join(lines[body_start:i]).removesuffix("\n"))
            kind = "code" if code else payload.get("kind", "markdown")
            if code:
                extra["org_headers"] = code[2]
            i += 1
        elif block:
            end_pattern = r"#\+end_" + re.escape(block[1]) + r"\s*$"
            i += 1
            while i < len(lines) and not re.match(end_pattern, lines[i], re.I):
                i += 1
            if i == len(lines):
                raise ValueError("Unterminated Org block")
            i += 1
            kind, source = "raw", "".join(lines[content_start:i])
        elif heading:
            kind, source = "section", heading[2]
            i += 1
            tail_start = i
            if i < len(lines) and re.match(r"\s*(?:SCHEDULED:|DEADLINE:|CLOSED:)", lines[i]):
                i += 1
            if i < len(lines) and lines[i].strip().upper() == ":PROPERTIES:":
                i += 1
                while i < len(lines) and lines[i].strip().upper() != ":END:":
                    i += 1
                if i == len(lines):
                    raise ValueError("Unterminated heading property drawer")
                i += 1
            if i > tail_start:
                extra["org_heading_tail"] = "".join(lines[tail_start:i])
        elif item:
            kind, source = "item", item[2]
            extra["org_bullet"] = item[1]
            i += 1
        else:
            kind = payload.get("kind", "markdown")
            i += 1
            while i < len(lines) and not re.match(
                r"(?:\*+ |\s*(?:[-+] |\d+[.)] )|#\+(?:name:|begin_|DOCLOOP_))",
                lines[i],
                re.I,
            ):
                i += 1
            source = "".join(lines[content_start:i])
        outputs = payload.get("outputs", [])
        result_at = i
        if code:
            while result_at < len(lines) and not lines[result_at].strip():
                result_at += 1
        if (
            (code or payload)
            and result_at < len(lines)
            and re.match(r"#\+RESULTS:", lines[result_at], re.I)
        ):
            cursor = result_at + 1
            result_text = None
            if cursor < len(lines) and lines[cursor].lower().strip() == "#+begin_example":
                cursor += 1
                result_start = cursor
                while cursor < len(lines) and lines[cursor].lower().strip() != "#+end_example":
                    cursor += 1
                if cursor == len(lines):
                    raise ValueError("Unterminated results block")
                result_text = _unescape_org("".join(lines[result_start:cursor]).removesuffix("\n"))
                cursor += 1
            elif cursor < len(lines) and lines[cursor].startswith(":"):
                result_lines = []
                while cursor < len(lines) and lines[cursor].startswith(":"):
                    result_lines.append(re.sub(r"^: ?", "", lines[cursor]))
                    cursor += 1
                result_text = "".join(result_lines)
            if result_text is not None:
                expected_text = "\n".join(
                    _text(o.get("text", o.get("data", {}).get("text/plain", ""))) for o in outputs
                )
                if result_text != expected_text:
                    outputs = [{"output_type": "stream", "name": "stdout", "text": result_text}]
                i = cursor
        raw = "".join(lines[start:i])
        node = Node(
            id=_fresh_id(preferred, raw, start, used),
            kind=kind,
            source=source,
            language=code[1] if code else payload.get("language", "python"),
            level=len(heading[1]) if heading else payload.get("level", 1),
            outputs=outputs,
            metadata=payload.get("metadata", {}),
            extra=extra,
            original=raw,
        )
        node.original_digest = node.fingerprint()
        doc.nodes.append(node)
    doc.validate()
    return doc
