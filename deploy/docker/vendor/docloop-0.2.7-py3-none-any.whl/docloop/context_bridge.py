"""Derived context epochs around the authoritative native document and its IDs."""

from __future__ import annotations

import copy
import json
import re
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict, dataclass

from .document import canonical, digest
from .observations import execution_summary
from .store import Conflict

# Only conversational prose belongs in the rolling tail. Tool observations and
# errors remain addressed document memory, including receipts from older versions.
PROSE_ROLES = {"agent", "human"}
PROTECTED_ROLES = {"user_instruction", "human", "instructions", "tool_inventory"}
POLICY_KEY = "docloop_context"


@dataclass(frozen=True)
class Limits:
    budget_bytes: int = 24000
    preview_bytes: int = 1024
    recent_count: int = 8
    read_bytes: int = 16000

    def __post_init__(self):
        for key, low, high in [
            ("budget_bytes", 4096, 1000000),
            ("preview_bytes", 64, 16000),
            ("recent_count", 0, 100),
            ("read_bytes", 4, 1000000),
        ]:
            value = getattr(self, key)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"{key} must be {low}..{high}")


@dataclass(frozen=True)
class FrozenRequest:
    request_id: str
    revision: str
    epoch: int
    blocks: tuple[str, ...]
    messages_json: str
    input_hash: str

    @property
    def messages(self):
        return json.loads(self.messages_json)

    def value(self):
        return {**asdict(self), "messages": self.messages}


def materialize(blocks):
    """Replay the public snapshot/edit contract, preserving native node order."""
    state = None
    for raw in blocks:
        block = json.loads(raw)
        if block["type"] == "snapshot":
            state = block["document"]
        else:
            nodes = {n["id"]: n for n in state["nodes"]}
            for address in block["delete"]:
                nodes.pop(address, None)
            nodes.update({n["id"]: n for n in block["upsert"]})
            state = {
                "metadata": block["metadata"],
                "extra": block["extra"],
                "nodes": [nodes[address] for address in block["order"]],
            }
    return state


class ContextBridge:
    def __init__(self, store, limits=None):
        self.store = store
        self.limits = limits or Limits()
        self.path = store.history_dir / "context.sqlite3"
        # Private derived data shares the native history's backup/lifecycle boundary.
        with self._db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS blobs (ref TEXT PRIMARY KEY, text TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT);
                CREATE TABLE IF NOT EXISTS requests (
                    id TEXT PRIMARY KEY, protocol TEXT NOT NULL, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS request_ui (id TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS dispatches (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL,
                    phase TEXT NOT NULL, value TEXT NOT NULL);
            """)
        self.path.chmod(0o600)

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        try:
            db.execute("PRAGMA synchronous=FULL")
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _raw(db, text):
        ref = "sha256:" + digest(text)
        db.execute("INSERT OR IGNORE INTO blobs VALUES (?,?)", (ref, text))
        return ref

    def archive(self, text):
        """Retain a complete tool observation before display truncation."""
        with self._db() as db:
            return self._raw(db, text)

    def result(self, value, limit=4000):
        """Bound the entire result envelope, including reference and metadata."""
        if type(limit) is not int or not 256 <= limit <= self.limits.read_bytes:
            raise ValueError("Result limit must be 256..owner read limit")
        text = canonical(value)
        raw = text.encode()
        ref = self.archive(text)
        low, high = 0, min(limit, len(raw))

        def envelope(size):
            preview = raw[:size].decode("utf-8", "ignore")
            return {
                "ref": ref,
                "text": preview,
                "total_bytes": len(raw),
                "omitted_bytes": len(raw) - len(preview.encode()),
            }

        while low < high:
            middle = (low + high + 1) // 2
            if len(canonical(envelope(middle)).encode()) <= limit:
                low = middle
            else:
                high = middle - 1
        return envelope(low)

    def _preview(self, db, value, limit):
        text = value if isinstance(value, str) else canonical(value)
        raw = text.encode()
        selected = raw[:limit].decode("utf-8", "ignore")
        return {
            "text": selected,
            "ref": self._raw(db, text),
            "total_bytes": len(raw),
            "omitted_bytes": len(raw) - len(selected.encode()),
        }

    def _policy(self, doc):
        configured = doc.metadata.get(POLICY_KEY, {})
        if not isinstance(configured, dict) or set(configured) - {
            "budget_bytes",
            "preview_bytes",
            "recent_count",
            "views",
            "generation",
        }:
            raise ValueError("Invalid context policy")
        policy = {
            k: getattr(self.limits, k) for k in ("budget_bytes", "preview_bytes", "recent_count")
        }
        policy.update(configured)
        for key, minimum in [("budget_bytes", 4096), ("preview_bytes", 64), ("recent_count", 0)]:
            value = policy[key]
            if type(value) is not int or not minimum <= value <= getattr(self.limits, key):
                raise ValueError(f"{key} exceeds owner bounds")
        views = policy.setdefault("views", {})
        if not isinstance(views, dict) or any(
            mode not in {"preview", "omit", "full"} for mode in views.values()
        ):
            raise ValueError("Views must map native node IDs to preview, omit, or full")
        for address in views:
            if not isinstance(address, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", address):
                raise ValueError("Invalid view address")
        generation = policy.setdefault("generation", 0)
        if type(generation) is not int or generation < 0:
            raise ValueError("Invalid context generation")
        return policy

    def _render(self, db, doc, revision, protocol):
        from .python_objects import CONVERSATION_ROLES, STATE_KEY, VIEW_SOURCES, enabled

        python_state = enabled(doc)
        policy = self._policy(doc)
        nodes, prose, python_views = [], [], []
        pinned = set()
        full_candidates = []
        for node in doc.nodes:
            value = node.value()
            # The complete native value is retained even when its projection is omitted.
            ref = self._raw(db, canonical(value))
            role = node.metadata.get("docloop_role")
            active_instruction = role == "user_instruction" and node.metadata.get(
                "instruction_status"
            ) in {"pending", "active", "paused"}
            if (
                python_state
                and role in CONVERSATION_ROLES | {"tool_inventory"}
                and not active_instruction
            ):
                continue
            protected = role in PROTECTED_ROLES
            if policy["views"].get(node.id) == "omit" and not protected:
                continue
            selected = {
                "id": node.id,
                "kind": node.kind,
                "language": node.language,
                "level": node.level,
                "native_ref": ref,
            }
            execution = execution_summary(node)
            if execution is not None:
                selected["execution"] = execution
            full = policy["views"].get(node.id) == "full"
            if protected or full:
                pinned.add(node.id)
            for field in ("source", "outputs", "metadata", "extra"):
                limit = policy["preview_bytes"]
                # Never silently discard owner instructions or registered tool schemas.
                if full or field == "source" and role in PROTECTED_ROLES - {"human"}:
                    text = (
                        value[field] if isinstance(value[field], str) else canonical(value[field])
                    )
                    limit = len(text.encode())
                selected[field] = self._preview(db, value[field], limit)
            if full and not protected:
                full_candidates.append((selected, value))
            if python_state and node.id in VIEW_SOURCES:
                python_views.append(selected)
            elif role in PROSE_ROLES:
                prose.append((role, selected))
            else:
                nodes.append(selected)
        metadata = {
            k: v
            for k, v in doc.metadata.items()
            if k not in {POLICY_KEY, "docloop_cache", "docloop_provider_usage", STATE_KEY}
        }
        document = {
            "nodes": nodes,
            "metadata": self._preview(db, metadata, policy["preview_bytes"]),
            "extra": self._preview(db, doc.extra, policy["preview_bytes"]),
        }
        # Retain the last N messages in EACH direction, in original document order.
        remaining = dict.fromkeys(PROSE_ROLES, policy["recent_count"])
        recent = []
        for role, selected in reversed(prose):
            if remaining[role] > 0:
                recent.append(selected)
                remaining[role] -= 1
        recent.reverse()

        row = db.execute("SELECT value FROM state WHERE id=1").fetchone()
        old = json.loads(row[0]) if row else None
        profile = "python-views-v1" if python_state else "native"
        omitted_count = 0

        def messages(current_blocks, omitted=None):
            unchanged = []
            if old and old.get("profile") == profile and old.get("protocol") == digest(protocol):
                for current, previous in zip(current_blocks, old["blocks"]):
                    if current != previous:
                        break
                    unchanged.append(current)
            tail = (
                "CURRENT PYTHON VIEWS\n"
                + canonical(
                    {
                        "cells": python_views,
                        "omitted_nodes": omitted_count if omitted is None else omitted,
                        "cache_candidate": {
                            "unchanged_blocks": len(unchanged),
                            "bytes": sum(len(block.encode()) for block in unchanged),
                            "provider_confirmed": False,
                        },
                    }
                )
                if python_state
                else "RECENT PROSE\n" + canonical(recent)
            )
            return [
                {"role": "system", "content": protocol},
                *[
                    {"role": "user", "content": "NATIVE DOCUMENT MEMORY BLOCK\n" + block}
                    for block in current_blocks
                ],
                {
                    "role": "user",
                    "content": tail + "\nRevision: " + revision,
                },
            ]

        def snapshot_size(indices):
            selected = {**document, "nodes": [nodes[i] for i in sorted(indices)]}
            block = canonical({"type": "snapshot", "document": selected})
            return len(canonical(messages([block], len(nodes) - len(indices))).encode())

        if python_state and snapshot_size(range(len(nodes))) > policy["budget_bytes"]:
            # Reserve current views and owner/full cells, then a stable prefix and
            # recent cells. Complete omitted values remain in the native notebook.
            selected = {i for i, node in enumerate(nodes) if node["id"] in pinned}
            base_size = snapshot_size(selected)
            if base_size > policy["budget_bytes"]:
                # Execution can enlarge a full cell after its view was selected.
                # Collapse the largest optional expansion first; keep its address
                # visible and its requested policy intact for a later smaller result.
                candidates = []
                for current, value in full_candidates:
                    preview = {
                        **current,
                        "view": {
                            "requested": "full",
                            "rendered": "preview",
                            "reason": "context_budget",
                        },
                    }
                    for field in ("source", "outputs", "metadata", "extra"):
                        preview[field] = self._preview(db, value[field], policy["preview_bytes"])
                    savings = len(canonical(current).encode()) - len(canonical(preview).encode())
                    if savings > 0:
                        candidates.append((savings, current["id"], current, preview))
                for _, _, current, preview in sorted(candidates, key=lambda c: (-c[0], c[1])):
                    current.clear()
                    current.update(preview)
                    base_size = snapshot_size(selected)
                    if base_size <= policy["budget_bytes"]:
                        break
            if base_size > policy["budget_bytes"]:
                raise ValueError("Python context views and pinned cells exceed owner byte budget")
            prefix_budget = base_size + (policy["budget_bytes"] - base_size) // 2
            for index in range(len(nodes)):
                if index in selected:
                    continue
                if snapshot_size(selected | {index}) > prefix_budget:
                    break
                selected.add(index)
            for index in reversed(range(len(nodes))):
                if (
                    index not in selected
                    and snapshot_size(selected | {index}) <= policy["budget_bytes"]
                ):
                    selected.add(index)
            omitted_count = len(nodes) - len(selected)
            nodes = [nodes[i] for i in sorted(selected)]
            document = {**document, "nodes": nodes}

        epoch = old["epoch"] if old else 0
        blocks = old["blocks"][:] if old else []
        reset = not old or old["policy"] != policy or old.get("profile", "native") != profile
        if not reset and old["document"] != document:
            before = {n["id"]: n for n in old["document"]["nodes"]}
            after = {n["id"]: n for n in nodes}
            blocks.append(
                canonical(
                    {
                        "type": "edit",
                        "delete": sorted(before.keys() - after.keys()),
                        "upsert": [n for n in nodes if before.get(n["id"]) != n],
                        "order": [n["id"] for n in nodes],
                        "metadata": document["metadata"],
                        "extra": document["extra"],
                    }
                )
            )

        if reset or len(canonical(messages(blocks)).encode()) > policy["budget_bytes"]:
            epoch += 1
            blocks = [canonical({"type": "snapshot", "document": document})]
        serialized = canonical(messages(blocks))
        if len(serialized.encode()) > policy["budget_bytes"]:
            raise ValueError(
                "Context exceeds owner byte budget after local compaction; "
                "reduce previews/recent prose or configure explicit views"
            )
        state = {
            "epoch": epoch,
            "blocks": blocks,
            "document": document,
            "policy": policy,
            "profile": profile,
            "protocol": digest(protocol),
        }
        return state, serialized

    def prepare(self, request_id, protocol, *, model_config=None):
        if not isinstance(request_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", request_id):
            raise ValueError("Invalid inference request ID")
        with self.store.lock(), self._db() as db:
            row = db.execute(
                "SELECT protocol,value FROM requests WHERE id=?", (request_id,)
            ).fetchone()
            if row:
                if row[0] != digest(protocol):
                    raise Conflict("Frozen request ID reused with a different protocol")
                ui_row = db.execute(
                    "SELECT value FROM request_ui WHERE id=?", (request_id,)
                ).fetchone()
                if model_config and ui_row:
                    if json.loads(ui_row[0])["accounting"]["model"] != model_config["model"]:
                        raise Conflict("Frozen request ID reused with a different model")
                value = json.loads(row[1])
                value["blocks"] = tuple(value["blocks"])
                return FrozenRequest(**value)
            doc, revision = self.store.read()
            state, serialized = self._render(db, doc, revision, protocol)
            frozen = FrozenRequest(
                request_id,
                revision,
                state["epoch"],
                tuple(state["blocks"]),
                serialized,
                digest(serialized),
            )
            state["last_request_id"] = request_id
            db.execute("INSERT OR REPLACE INTO state VALUES (1,?)", (canonical(state),))
            db.execute(
                "INSERT INTO requests VALUES (?,?,?)",
                (request_id, digest(protocol), canonical(asdict(frozen))),
            )
            from .history_ui import model_configuration, projection_metadata

            ui = projection_metadata(
                self.store,
                doc,
                revision,
                serialized,
                state["blocks"],
                model_config or model_configuration(),
                db,
            )
            db.execute("INSERT INTO request_ui VALUES (?,?)", (request_id, canonical(ui)))
            return frozen

    def record_dispatch(self, request_id, phase, usage=None):
        """Append transport evidence outside document metadata and frozen prompt bytes."""
        if phase not in {"dispatched", "returned", "failed"}:
            raise ValueError("Unknown dispatch phase")
        with self._db() as db:
            if not db.execute("SELECT 1 FROM requests WHERE id=?", (request_id,)).fetchone():
                raise ValueError("Unknown frozen request")
            db.execute(
                "INSERT INTO dispatches(id,phase,value) VALUES (?,?,?)",
                (request_id, phase, canonical({"usage": usage})),
            )

    def conversation(
        self, protocol, *, selection="next", before=None, limit=50, enabled=True, model=None
    ):
        from .history_ui import model_configuration, projection_metadata, provider_measurement

        if type(limit) is not int or not 1 <= limit <= 200:
            raise ValueError("History page limit must be 1..200")
        with self.store.lock(), self._db() as db:
            doc, revision = self.store.read()
            history = self.store.conversation_history()
            events = history["events"]
            try:
                if not enabled:
                    raise ValueError(
                        "Context epochs is disabled; legacy input accounting is unknown"
                    )
                state, serialized = self._render(db, doc, revision, protocol)
                next_ui = projection_metadata(
                    self.store,
                    doc,
                    revision,
                    serialized,
                    state["blocks"],
                    model_configuration(model),
                    db,
                )
                next_ui.update(request_id=None, status="preview", provider_measured=None)
            except ValueError as exc:
                next_ui = {
                    "revision": revision,
                    "request_id": None,
                    "status": "unknown",
                    "error": str(exc),
                    "included_message_ids": [],
                    "divider_id": None,
                    "inclusion": {},
                    "known_history_ids": [],
                    "accounting": None,
                }

            def sent(request_id):
                row = db.execute(
                    "SELECT value FROM request_ui WHERE id=?", (request_id,)
                ).fetchone()
                if not row:
                    raise ValueError(
                        "No retained UI receipt for this request; old receipts cannot be inferred"
                    )
                value = json.loads(row[0])
                if value.get("branch") != history["branch"]:
                    raise ValueError("Frozen request belongs to another conversation branch")
                evidence = db.execute(
                    "SELECT seq,phase,value FROM dispatches WHERE id=? ORDER BY seq", (request_id,)
                ).fetchall()
                if not any(r[1] == "dispatched" for r in evidence):
                    raise ValueError("Request prepared but not dispatched")
                value.update(
                    request_id=request_id,
                    status=evidence[-1][1],
                    provider_measured=None,
                    provider_usage=None,
                    dispatch_count=sum(r[1] == "dispatched" for r in evidence),
                )
                for seq, phase, raw in evidence:
                    usage = json.loads(raw).get("usage")
                    if phase == "dispatched":
                        value.update(
                            provider_measured=None,
                            provider_usage=None,
                            dispatch_sequence=seq,
                            measurement_sequence=None,
                        )
                    if phase == "returned":
                        value.update(
                            provider_measured=provider_measurement(usage),
                            provider_usage=usage,
                            measurement_sequence=seq,
                        )
                return value

            last = None
            for request_id, raw in db.execute(
                "SELECT d.id,u.value FROM dispatches d JOIN request_ui u ON u.id=d.id "
                "WHERE d.phase='dispatched' ORDER BY d.seq DESC"
            ):
                if json.loads(raw).get("branch") == history["branch"]:
                    last = sent(request_id)
                    break
            selected = copy.deepcopy(
                next_ui if selection == "next" else last if selection == "last" else sent(selection)
            )
            if selected is None:
                raise ValueError("No request has been dispatched")
            known = set(selected["known_history_ids"])
            for event in events:
                if event["id"] not in selected["inclusion"]:
                    status = (
                        "unknown"
                        if selected["status"] == "unknown"
                        else "pending"
                        if selection != "next" and event["id"] not in known
                        else "history"
                    )
                    selected["inclusion"][event["id"]] = {"status": status, "omitted_bytes": 0}
            end = len(events)
            if before is not None:
                indexes = [i for i, e in enumerate(events) if e["id"] == before]
                if not indexes:
                    raise ValueError("History cursor is not in this conversation branch")
                end = indexes[0]
            page = events[max(0, end - limit) : end]
            divider = selected["divider_id"]
            ids = [e["id"] for e in events]
            boundary = (
                "none"
                if divider is None
                else "in_page"
                if divider in [e["id"] for e in page]
                else "before_page"
                if ids.index(divider) < max(0, end - limit)
                else "after_page"
            )
            return {
                "revision": revision,
                "conversation": str(self.store.path),
                "history_head": history["head"],
                "branch": history["branch"],
                "history": page,
                "total": len(events),
                "before": page[0]["id"] if end > limit else None,
                "boundary": boundary,
                "selected": selected,
                "next": next_ui,
                "last": last,
            }

    def inspect(self, protocol=""):
        with self.store.lock(), self._db() as db:
            doc, revision = self.store.read()
            state, serialized = self._render(db, doc, revision, protocol)
            row = db.execute("SELECT value FROM state WHERE id=1").fetchone()
            previous = json.loads(row[0]) if row else {}
            last = None
            if previous.get("last_request_id"):
                record = db.execute(
                    "SELECT value FROM requests WHERE id=?", (previous["last_request_id"],)
                ).fetchone()
                last = json.loads(record[0])
            return {
                "profile": "native-epochs-v1",
                "cache_qualified": False,
                "revision": revision,
                "policy": self._policy(doc),
                "next": {
                    "messages": json.loads(serialized),
                    "input_hash": digest(serialized),
                    "epoch": state["epoch"],
                    "bytes": len(serialized.encode()),
                },
                "last": last,
                "index": [{"id": n.id, "kind": n.kind} for n in doc.nodes],
            }

    def read(self, address, field="source", offset=0, limit=4000):
        if (
            type(offset) is not int
            or offset < 0
            or type(limit) is not int
            or not 4 <= limit <= self.limits.read_bytes
        ):
            raise ValueError("read requires offset >= 0 and limit within owner bounds (minimum 4)")
        if not isinstance(address, str):
            raise ValueError("Address must be a native node ID or content hash")
        if address.startswith("sha256:"):
            if not re.fullmatch(r"sha256:[a-f0-9]{64}", address):
                raise ValueError("Invalid content hash")
            with self._db() as db:
                row = db.execute("SELECT text FROM blobs WHERE ref=?", (address,)).fetchone()
                if row is None:
                    raise ValueError("Unknown content hash")
                text = row[0]
        else:
            doc, _ = self.store.read()
            if address == "/":
                value = [{"id": n.id, "kind": n.kind} for n in doc.nodes]
            else:
                if field not in {"source", "outputs", "metadata", "extra"}:
                    raise ValueError("Unknown native field")
                value = getattr(doc.get(address), field)
            text = value if isinstance(value, str) else canonical(value)
        raw = text.encode()
        if offset > len(raw) or offset < len(raw) and raw[offset] & 0xC0 == 0x80:
            raise ValueError("Offset must be a UTF-8 byte boundary within content")
        selected = raw[offset : offset + limit].decode("utf-8", "ignore")
        end = offset + len(selected.encode())
        return {
            "address": address,
            "field": field,
            "text": selected,
            "offset": offset,
            "next_offset": end if end < len(raw) else None,
            "total_bytes": len(raw),
        }

    def _edit_policy(self, revision, changes):
        doc, actual = self.store.read()
        if actual != revision:
            raise Conflict("Document changed before context policy update")
        policy = copy.deepcopy(self._policy(doc))
        policy.update(changes)
        doc.metadata[POLICY_KEY] = policy
        self._policy(doc)
        return {
            "revision": self.store.save(doc, revision, "Configure native context"),
            "policy": policy,
        }

    def configure(self, revision, changes):
        if not isinstance(changes, dict) or set(changes) - {
            "budget_bytes",
            "preview_bytes",
            "recent_count",
        }:
            raise ValueError("Only bounded projection policy fields can be configured")
        return self._edit_policy(revision, changes)

    def view(self, revision, address, mode):
        if mode not in {"preview", "omit", "full"}:
            raise ValueError("View must be preview, omit, or full")
        doc, actual = self.store.read()
        if actual != revision:
            raise Conflict("Document changed before view update")
        if doc.get(address).metadata.get("docloop_role") in PROTECTED_ROLES:
            raise ValueError("Instruction and tool inventory views are owner controlled")
        views = {**self._policy(doc)["views"], address: mode}
        return self._edit_policy(revision, {"views": views})

    def compact(self, revision):
        doc, actual = self.store.read()
        if actual != revision:
            raise Conflict("Document changed before compaction")
        return self._edit_policy(revision, {"generation": self._policy(doc)["generation"] + 1})

    def patch(self, revision, edits):
        from .engine import Engine

        doc, actual = self.store.read()
        if actual != revision:
            raise Conflict("Document changed before context patch")
        if not isinstance(edits, list) or not 1 <= len(edits) <= 16:
            raise ValueError("Patch requires 1..16 native edits")
        for call in edits:
            if not isinstance(call, dict) or call.get("op") not in {
                "create",
                "update",
                "delete",
                "move",
            }:
                raise ValueError("Patch supports native create/update/delete/move only")
            if call["op"] != "create":
                affected = (
                    doc.subtree(call["address"])
                    if call["op"] in {"delete", "move"}
                    else [doc.get(call["address"])]
                )
                if any(n.metadata.get("docloop_role") in PROTECTED_ROLES for n in affected):
                    raise ValueError("Instruction and tool inventory nodes are owner controlled")
            changes = call.get("node", {}) if call["op"] == "create" else call.get("changes", {})
            if not isinstance(changes, dict):
                raise ValueError("Node/changes must be an object")
            if "metadata" in changes:
                metadata = changes["metadata"]
                if not isinstance(metadata, dict):
                    raise ValueError("Metadata must be an object")

                def protected(k):
                    return k.startswith("docloop_") or k.startswith("instruction_")

                before = doc.get(call["address"]).metadata if call["op"] == "update" else {}
                if {k: v for k, v in metadata.items() if protected(k)} != {
                    k: v for k, v in before.items() if protected(k)
                }:
                    raise ValueError("Native lifecycle metadata is owner controlled")
            Engine._apply(doc, call, simulate=True)
        return {"revision": self.store.save(doc, revision, "Apply native context patch")}

    def call(self, request, protocol=""):
        if not isinstance(request, dict):
            raise ValueError("Context tool request must be an object")
        op = request.get("op")
        args = {k: v for k, v in request.items() if k != "op"}
        if op == "inspect":
            if args:
                raise ValueError("inspect has no arguments")
            return self.inspect(protocol)
        if op in {"create", "update", "delete", "move"}:
            # The protocol advertises single native edits as well as atomic batches.
            # Both paths must share revision and owner-metadata checks.
            revision = args.pop("revision", None)
            if not isinstance(revision, str) or not revision:
                raise ValueError("Native edits require the current request revision")
            return self.patch(revision, [{"op": op, **args}])
        if op not in {"read", "patch", "configure", "view", "compact"}:
            raise ValueError("Unknown context tool")
        try:
            return getattr(self, op)(**args)
        except TypeError as exc:
            raise ValueError("Invalid context tool arguments") from exc
