"""Fresh Chat Completions requests, including LLMQ's metered text envelope."""

from __future__ import annotations

import http.client
import json
import os
import selectors
import shutil
import signal
import socket
import subprocess
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from urllib.parse import urlsplit

PYTHON_TEXT_PROTOCOL = """Transport contract for this text-only provider endpoint:
Return a JSON object with exactly calls, note, and done. calls is either [] or one
object {"op":"run_python","code":"Python source"}. note is a string; done is a boolean.
When finished, return {"calls":[],"note":"Your answer","done":true}.
Return code as data for the caller to evaluate; this provider has no execution tools.
Do not use markdown fences or call any other operation.
"""

REASONING_EFFORTS = {"none", "low", "medium", "high", "xhigh", "max"}
_CODEX_MAX_OUTPUT_BYTES = 2_000_000
_CODEX_METADATA_MAX_BYTES = 8_000_000


@dataclass
class Reply:
    calls: list[dict]
    note: str = ""
    done: bool = False
    usage: dict | None = None


def parse_reply(response: dict, *, python_tool=False, text_tools=False) -> Reply:
    message = response["choices"][0]["message"]
    if message.get("tool_calls"):
        calls = []
        for call in message["tool_calls"]:
            function = call["function"]
            arguments = json.loads(function["arguments"])
            if python_tool and (
                function["name"] != "run_python"
                or not isinstance(arguments, dict)
                or set(arguments) != {"code"}
                or not isinstance(arguments["code"], str)
            ):
                raise ValueError("Provider must call only run_python(code)")
            calls.append({**arguments, "op": function["name"]})
        return Reply(calls, message.get("content") or "", False, response.get("usage"))
    content = (message.get("content") or "").strip()
    if python_tool and not text_tools:
        return Reply([], content, True, response.get("usage"))
    if content.startswith("```") and content.endswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    value = json.loads(content)
    if not isinstance(value, dict) or set(value) - {"calls", "note", "done"}:
        raise ValueError("Reply must contain only calls, note and done")
    calls, note, done = value.get("calls", []), value.get("note", ""), value.get("done", False)
    if not isinstance(calls, list) or not isinstance(note, str) or type(done) is not bool:
        raise ValueError("Invalid reply envelope")
    if python_tool and (
        len(calls) > 1
        or any(
            not isinstance(call, dict)
            or set(call) != {"op", "code"}
            or call["op"] != "run_python"
            or not isinstance(call["code"], str)
            for call in calls
        )
        or (done and calls)
    ):
        raise ValueError("Provider must call only run_python(code), or finish without calls")
    return Reply(calls, note, done, response.get("usage"))


class ChatProvider:
    def __init__(
        self,
        endpoint: str,
        model: str,
        api_key: str = "",
        *,
        timeout: float = 240,
        headers: dict | None = None,
        max_body_bytes: int = 65536,
        tool_transport: str = "native",
    ):
        if not endpoint.startswith(("http://", "https://")):
            raise ValueError("Explicit HTTP(S) chat completions endpoint required")
        self.endpoint, self.model, self.api_key = endpoint, model, api_key
        self.timeout, self.headers, self.max_body_bytes = timeout, headers or {}, max_body_bytes
        if tool_transport not in {"native", "text"}:
            raise ValueError("Unknown provider tool transport")
        self.tool_transport = tool_transport

    @classmethod
    def from_env(cls, *, agent_id=None, model=None, environ=None):
        from .model_routes import ModelCatalog

        env = ModelCatalog(os.environ if environ is None else environ).environment(model)
        mode = env.get("DOCLOOP_PROVIDER", "llmq")
        model = env.get("DOCLOOP_MODEL", "")
        if not model:
            raise ValueError("Set DOCLOOP_MODEL to an explicitly selected metered model")
        reasoning_effort = env.get("DOCLOOP_REASONING_EFFORT", "").strip().lower() or None
        if reasoning_effort is not None:
            if reasoning_effort not in REASONING_EFFORTS:
                raise ValueError("DOCLOOP_REASONING_EFFORT must be none, low, medium, high, xhigh or max")
            if mode != "codex-cli":
                raise ValueError("DOCLOOP_REASONING_EFFORT requires DOCLOOP_PROVIDER=codex-cli")
        if mode == "codex-cli":
            if model != "gpt-6-luna":
                raise ValueError("codex-cli currently supports the explicitly cataloged gpt-6-luna model")
            # The reviewed tool-isolated catalog requires an explicit effort. Luna's
            # documented target for this provider is max when the operator omits it.
            reasoning_effort = reasoning_effort or "max"
            executable = _resolve_codex_executable(
                env.get("DOCLOOP_CODEX_EXECUTABLE", "codex"), env.get("PATH")
            )
            process_env = _codex_process_environment(env)
            features_output, models_output = _codex_metadata(executable, tuple(sorted(process_env.items())))
            timeout = _codex_timeout(env.get("DOCLOOP_CODEX_TIMEOUT_SECONDS", "240"))
            from .codex_cli_config import tool_free_catalog, tool_free_config

            tool_free_config(features_output)
            tool_free_catalog(models_output, model, reasoning_effort)
            return CodexCLIProvider(
                executable,
                model,
                features_output=features_output,
                models_output=models_output,
                effort=reasoning_effort,
                process_env=process_env,
                timeout=timeout,
            )
        if mode in {"llmq", "llmq-api"}:
            if env.get("OMNIGENT_QUOTA_ROUTE", "personal-llmq") != "personal-llmq":
                raise ValueError("LLMQ is a personal route; configure the explicit work provider")
            base = env.get("DOCLOOP_LLMQ_URL", "").rstrip("/")
            if not base:
                raise ValueError("Set DOCLOOP_LLMQ_URL to the guarded gateway mount; no fallback")
            if mode == "llmq-api":
                route = urlsplit(base)
                if (
                    not route.path.endswith(("/api/openrouter", "/api/vast"))
                    or route.query
                    or route.fragment
                    or route.username is not None
                ):
                    raise ValueError(
                        "llmq-api requires the configured /api/openrouter or /api/vast mount"
                    )
            endpoint = base + "/w/agent-infra/v1/chat/completions"
            key = env.get("DOCLOOP_API_KEY", env.get("LLMQ_API_KEY", ""))
            if not key and env.get("DOCLOOP_API_KEY_FILE"):
                key = Path(env["DOCLOOP_API_KEY_FILE"]).read_text().strip()
            if not key:
                raise ValueError("LLMQ API credential required")
            headers = {
                "X-LLM-Workstream": "agent-infra",
                "X-LLM-Project-ID": "agent-infra",
            }
            if mode == "llmq":
                headers["X-LLM-Agent-ID"] = agent_id or env.get(
                    "DOCLOOP_AGENT_ID", "document-harness"
                )
            # API gateway admission uses the authenticated token actor. A document
            # agent ID is not that actor and would fail its optional assertion.
        elif mode == "chat":
            endpoint = env.get("DOCLOOP_ENDPOINT", "")
            key, headers = env.get("DOCLOOP_API_KEY", ""), {}
        else:
            raise ValueError("DOCLOOP_PROVIDER must be llmq, llmq-api or chat")
        return cls(
            endpoint,
            model,
            key,
            headers=headers,
            tool_transport="text" if mode == "llmq" else "native",
        )

    def complete(self, messages: list[dict], cancel_event=None, *, tools=None) -> Reply:
        # There is deliberately no message history or previous response ID here.
        text_tools = tools is not None and self.tool_transport == "text"
        if text_tools:
            from .python_harness import RUN_PYTHON

            if tools != [RUN_PYTHON]:
                raise ValueError("Text transport supports only run_python")
            messages = [{"role": "system", "content": PYTHON_TEXT_PROTOCOL}, *messages]
        request = {
                "model": self.model,
                "messages": messages,
                "stream": False,
                **(
                    {"tools": tools, "parallel_tool_calls": False}
                    if tools is not None and not text_tools
                    else {}
                ),
            }
        body = json.dumps(request, ensure_ascii=False).encode()
        if len(body) > self.max_body_bytes:
            raise ValueError(
                "Serialized request exceeds provider body budget; lower context budget"
            )
        headers = {"Content-Type": "application/json", **self.headers}
        if not any(key.lower() in {"idempotency-key", "x-request-id"} for key in headers):
            headers["Idempotency-Key"] = uuid.uuid4().hex
        if self.api_key:
            headers["Authorization"] = "Bearer " + self.api_key
        url = urlsplit(self.endpoint)
        connection_type = (
            http.client.HTTPSConnection if url.scheme == "https" else http.client.HTTPConnection
        )
        connection = connection_type(url.hostname, url.port, timeout=self.timeout)
        finished = threading.Event()

        def watch_cancel():
            while not finished.wait(0.05):
                if cancel_event is not None and cancel_event.is_set():
                    sock = connection.sock
                    if sock is not None:
                        try:
                            sock.shutdown(socket.SHUT_RDWR)
                        except OSError:
                            pass
                        connection.close()
                        return

        watcher = None
        if cancel_event is not None:
            if cancel_event.is_set():
                raise InterruptedError("Inference cancelled")
            watcher = threading.Thread(target=watch_cancel, daemon=True)
            watcher.start()
        try:
            path = url.path or "/"
            if url.query:
                path += "?" + url.query
            connection.request("POST", path, body=body, headers=headers)
            response = connection.getresponse()
            raw = response.read(2_000_001)
            if response.status >= 400:
                # Do not echo response bodies which may contain credentials or upstream details.
                raise RuntimeError(f"Provider HTTP {response.status} {response.reason}")
        finally:
            finished.set()
            connection.close()
            if watcher is not None:
                watcher.join(timeout=1)
        if len(raw) > 2_000_000:
            raise ValueError("Provider reply too large")
        return parse_reply(json.loads(raw), python_tool=tools is not None, text_tools=text_tools)


def _resolve_codex_executable(value, path=None):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("DOCLOOP_CODEX_EXECUTABLE must name the Codex CLI")
    executable = shutil.which(value, path=path)
    if not executable:
        raise ValueError("Codex CLI executable was not found")
    return os.path.realpath(executable)


def _codex_process_environment(source):
    # Do not forward API keys or unrelated application credentials to the CLI.
    allowed = {
        "CODEX_HOME",
        "HOME",
        "PATH",
        "TMPDIR",
        "TEMP",
        "TMP",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "HTTP_PROXY",
        "HTTPS_PROXY",
        "ALL_PROXY",
        "NO_PROXY",
        "http_proxy",
        "https_proxy",
        "all_proxy",
        "no_proxy",
    }
    return {
        key: value
        for key, value in source.items()
        if key in allowed and isinstance(value, str) and "\x00" not in value
    }


def _codex_timeout(value):
    try:
        timeout = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("DOCLOOP_CODEX_TIMEOUT_SECONDS must be from 5 to 1800") from exc
    if not 5 <= timeout <= 1800:
        raise ValueError("DOCLOOP_CODEX_TIMEOUT_SECONDS must be from 5 to 1800")
    return timeout


@lru_cache(maxsize=4)
def _codex_metadata(executable, environment_items):
    """Read bounded CLI feature/model metadata once per executable environment."""
    env = dict(environment_items)
    with tempfile.TemporaryDirectory(prefix="docloop-codex-meta-") as empty_cwd:
        outputs = []
        for command in ([executable, "features", "list"], [executable, "debug", "models"]):
            try:
                result = subprocess.run(
                    command,
                    cwd=empty_cwd,
                    env=env,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    timeout=30,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise ValueError("Codex CLI metadata discovery failed") from exc
            if (
                result.returncode != 0
                or len(result.stdout) > _CODEX_METADATA_MAX_BYTES
                or not result.stdout
            ):
                raise ValueError("Codex CLI metadata discovery failed")
            outputs.append(result.stdout.decode("utf-8", errors="strict"))
    return tuple(outputs)


class CodexCLIProvider:
    """Tool-isolated Codex CLI transport with a strict Docloop JSON reply."""

    def __init__(
        self,
        executable,
        model,
        *,
        features_output,
        models_output,
        effort=None,
        process_env=None,
        timeout=240,
    ):
        if effort is not None and effort not in REASONING_EFFORTS:
            raise ValueError("Invalid reasoning effort")
        if not isinstance(model, str) or not model:
            raise ValueError("An explicit Codex model is required")
        self.executable = executable
        self.model = model
        self.effort = effort
        self.features_output = features_output
        self.models_output = models_output
        self.process_env = _codex_process_environment(
            os.environ if process_env is None else process_env
        )
        self.process_env.setdefault("PATH", os.defpath)
        self.timeout = timeout

    def complete(self, messages: list[dict], cancel_event=None, *, tools=None) -> Reply:
        from .codex_cli_config import build_codex_exec_command

        if cancel_event is not None and cancel_event.is_set():
            raise InterruptedError("Inference cancelled")
        text_tools = tools is not None
        if text_tools:
            from .python_harness import RUN_PYTHON

            if tools != [RUN_PYTHON]:
                raise ValueError("Codex CLI text transport supports only run_python")
            messages = [{"role": "system", "content": PYTHON_TEXT_PROTOCOL}, *messages]
        if not isinstance(messages, list) or any(
            not isinstance(message, dict)
            or message.get("role") not in {"system", "user", "assistant"}
            or not isinstance(message.get("content"), str)
            for message in messages
        ):
            raise ValueError("Codex CLI transport accepts text messages only")
        if text_tools:
            transport_instruction = (
                "The only action available is a run_python call in the final JSON object's "
                "calls array. Docloop executes that code in its configured Python environment. "
                "Use it to inspect or change files and run tests when the conversation calls "
                "for that. Codex CLI's read-only sandbox limits its own native process tools; "
                "it does not limit Docloop's run_python environment. The task's explicit "
                "workspace is writable through run_python. "
                "Do not use Codex CLI's native tools or access external context directly. "
            )
        else:
            transport_instruction = (
                "Codex CLI native tools are disabled. The calls array in your final JSON "
                "is Docloop's action interface, not a Codex CLI native tool call. "
                "Use the supplied system protocol's calls when the task requires them. "
                "For this provider transport, encode each complete Docloop call object "
                "as a JSON string inside calls; Docloop decodes each string before execution. "
                "For example: {\"calls\":[\"{\\\"op\\\":\\\"eval\\\",\\\"address\\\":\\\"inspect\\\"}\"],\"note\":\"\",\"done\":false}. "
                "For document actions, create or update code cells and eval them to read "
                "or change workspace files; the next request will contain their results. "
                "Do not access files or external context through Codex CLI itself. "
            )
        prompt = (
            "You are Docloop's model-only inference backend. Follow the supplied system "
            "messages and return the required final JSON object. "
            + transport_instruction
            + "The following JSON array is the complete conversation to answer:\n"
            + json.dumps(messages, ensure_ascii=False, separators=(",", ":"))
        ).encode("utf-8")
        if len(prompt) > _CODEX_MAX_OUTPUT_BYTES:
            raise ValueError("Serialized Codex prompt exceeds the provider budget")

        with tempfile.TemporaryDirectory(prefix="docloop-codex-config-") as config_dir, tempfile.TemporaryDirectory(
            prefix="docloop-codex-empty-"
        ) as empty_cwd:
            schema_path = os.path.join(config_dir, "reply-schema.json")
            command = build_codex_exec_command(
                self.executable,
                empty_cwd,
                self.model,
                self.effort,
                schema_path,
                self.features_output,
                models_output=self.models_output,
                python_tool=text_tools,
            )
            output = self._run(command, empty_cwd, prompt, cancel_event)
        final_text, usage = self._parse_events(output)
        if not text_tools:
            envelope = json.loads(final_text)
            calls = envelope.get("calls")
            if not isinstance(calls, list) or any(not isinstance(call, str) for call in calls):
                raise ValueError("Codex CLI document calls must be JSON strings")
            envelope["calls"] = [json.loads(call) for call in calls]
            final_text = json.dumps(envelope, ensure_ascii=False)
        response = {
            "choices": [{"message": {"content": final_text}}],
            "usage": usage,
        }
        return parse_reply(response, python_tool=text_tools, text_tools=text_tools)

    def _run(self, command, cwd, prompt, cancel_event):
        try:
            process = subprocess.Popen(
                command,
                cwd=cwd,
                env=self.process_env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                bufsize=0,
            )
        except OSError as exc:
            raise RuntimeError("Codex CLI could not be started") from exc
        selector = selectors.DefaultSelector()
        output = bytearray()
        deadline = time.monotonic() + self.timeout
        sent = 0
        stdin_closed = False
        try:
            os.set_blocking(process.stdin.fileno(), False)
            os.set_blocking(process.stdout.fileno(), False)
            selector.register(process.stdout, selectors.EVENT_READ, "stdout")
            if prompt:
                selector.register(process.stdin, selectors.EVENT_WRITE, "stdin")
            else:
                process.stdin.close()
                stdin_closed = True
            eof = False
            while not eof or process.poll() is None:
                if cancel_event is not None and cancel_event.is_set():
                    _terminate_process_group(process)
                    raise InterruptedError("Inference cancelled")
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    _terminate_process_group(process)
                    raise TimeoutError("Codex CLI inference timed out")
                if process.poll() is not None and not stdin_closed:
                    selector.unregister(process.stdin)
                    process.stdin.close()
                    stdin_closed = True
                for key, _ in selector.select(min(0.1, remaining)):
                    if key.data == "stdin":
                        try:
                            sent += os.write(
                                process.stdin.fileno(), prompt[sent : sent + 65536]
                            )
                        except BlockingIOError:
                            continue
                        except (BrokenPipeError, OSError):
                            selector.unregister(process.stdin)
                            process.stdin.close()
                            stdin_closed = True
                            continue
                        if sent == len(prompt):
                            selector.unregister(process.stdin)
                            process.stdin.close()
                            stdin_closed = True
                        continue
                    try:
                        chunk = os.read(key.fileobj.fileno(), 65536)
                    except BlockingIOError:
                        continue
                    if not chunk:
                        eof = True
                        selector.unregister(key.fileobj)
                        continue
                    output.extend(chunk)
                    if len(output) > _CODEX_MAX_OUTPUT_BYTES:
                        _terminate_process_group(process)
                        raise ValueError("Codex CLI event stream exceeded the output budget")
            status = process.wait(timeout=1)
            if status != 0:
                raise RuntimeError("Codex CLI inference failed")
            return bytes(output)
        finally:
            selector.close()
            if process.poll() is None:
                _terminate_process_group(process)
            try:
                process.stdin.close()
            except OSError:
                pass
            try:
                process.stdout.close()
            except OSError:
                pass

    @staticmethod
    def _parse_events(output):
        try:
            events = [json.loads(line) for line in output.decode("utf-8").splitlines() if line]
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Codex CLI returned malformed JSONL") from exc
        if not events:
            raise ValueError("Codex CLI returned no events")
        allowed_events = {
            "thread.started",
            "turn.started",
            "item.started",
            "item.completed",
            "turn.completed",
        }
        messages = []
        usage = None
        completed = False
        for event in events:
            if not isinstance(event, dict) or event.get("type") not in allowed_events:
                raise ValueError("Codex CLI emitted an unsupported or unsafe event")
            kind = event["type"]
            if completed:
                raise ValueError("Codex CLI emitted events after turn completion")
            if kind in {"item.started", "item.completed"}:
                item = event.get("item")
                if not isinstance(item, dict) or item.get("type") not in {"agent_message", "reasoning"}:
                    raise ValueError("Codex CLI emitted a tool or unknown item event")
                if kind == "item.completed" and item.get("type") == "agent_message":
                    text = item.get("text")
                    if not isinstance(text, str):
                        raise ValueError("Codex CLI final message is missing text")
                    messages.append(text)
            if kind == "turn.completed":
                raw_usage = event.get("usage")
                if not isinstance(raw_usage, dict):
                    raise ValueError("Codex CLI did not return usage")
                input_tokens = raw_usage.get("input_tokens")
                output_tokens = raw_usage.get("output_tokens")
                cached_tokens = raw_usage.get("cached_input_tokens", 0)
                reasoning_tokens = raw_usage.get("reasoning_output_tokens", 0)
                if any(type(value) is not int or value < 0 for value in (
                    input_tokens, output_tokens, cached_tokens, reasoning_tokens
                )):
                    raise ValueError("Codex CLI returned invalid usage")
                usage = {
                    "prompt_tokens": input_tokens,
                    "prompt_tokens_details": {"cached_tokens": cached_tokens},
                    "completion_tokens": output_tokens,
                    "completion_tokens_details": {"reasoning_tokens": reasoning_tokens},
                    "total_tokens": input_tokens + output_tokens,
                }
                completed = True
        final_messages = []
        for message in messages:
            try:
                candidate = json.loads(message)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict) and set(candidate) == {"calls", "note", "done"}:
                final_messages.append(message)
        if not completed or len(final_messages) != 1 or messages[-1] != final_messages[0]:
            kinds = [
                event.get("item", {}).get("type")
                for event in events
                if event.get("type") == "item.completed"
            ]
            raise ValueError(
                "Codex CLI did not return one completed final message "
                f"(completed={completed}, message_count={len(messages)}, "
                f"envelope_count={len(final_messages)}, item_types={kinds})"
            )
        return final_messages[0], usage


def _terminate_process_group(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        process.wait()
        return
    try:
        process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()
