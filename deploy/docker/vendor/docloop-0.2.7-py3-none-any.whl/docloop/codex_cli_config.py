"""Tool-free native Codex CLI configuration for the reviewed 0.156.0 catalog."""

from __future__ import annotations

import copy
import json
import os
import re
from pathlib import Path
from typing import Any

NATIVE_CLI_VERSION = "codex-cli 0.156.0"
NATIVE_MODEL = "gpt-6-luna"
NATIVE_EFFORT = "max"

_FEATURE_LINE = re.compile(
    r"([a-z][a-z0-9_.]*)\s+(under development|stable|experimental|deprecated|removed)\s+(true|false)"
)
_FEATURE_STAGES = {"under development", "stable", "experimental", "deprecated", "removed"}
_REQUIRED_TOOL_FEATURES = frozenset(
    {
        "apps",
        "browser_use",
        "browser_use_external",
        "browser_use_full_cdp_access",
        "code_mode_host",
        "codex_apps_mcp_2026_07_28",
        "computer_use",
        "enable_mcp_apps",
        "image_generation",
        "in_app_browser",
        "in_app_local_automation",
        "mcp_2026_07_28",
        "search_tool",
        "shell_tool",
        "skill_mcp_dependency_install",
        "skill_search",
        "standalone_web_search",
        "tool_call_mcp_elicitation",
        "tool_search",
        "unified_exec",
        "unified_exec_tty",
        "view_image",
    }
)
_REQUIRED_MODEL_FIELDS = frozenset(
    {
        "apply_patch_tool_type",
        "experimental_supported_tools",
        "include_apps_usage_instructions",
        "include_plugin_usage_instructions",
        "include_skills_usage_instructions",
        "node_repl_disabled",
        "shell_type",
        "slug",
        "supported_in_api",
        "supported_reasoning_levels",
        "supports_search_tool",
        "tool_mode",
        "web_search_tool_type",
    }
)
_MODEL_FIELDS_0_156 = frozenset(
    {
        "additional_speed_tiers",
        "availability_nux",
        "available_access_programs",
        "apply_patch_tool_type",
        "base_instructions",
        "comp_hash",
        "context_window",
        "default_reasoning_level",
        "default_reasoning_summary",
        "default_verbosity",
        "description",
        "display_name",
        "effective_context_window_percent",
        "experimental_supported_tools",
        "include_apps_usage_instructions",
        "include_plugin_usage_instructions",
        "include_skills_usage_instructions",
        "input_modalities",
        "max_context_window",
        "model_messages",
        "multi_agent_version",
        "node_repl_auto_review_required",
        "node_repl_disabled",
        "priority",
        "service_tiers",
        "shell_type",
        "slug",
        "supports_image_detail_original",
        "supports_experimental_context",
        "supports_reasoning_effort_updates",
        "supports_search_tool",
        "support_verbosity",
        "supported_in_api",
        "supported_reasoning_levels",
        "tool_mode",
        "truncation_policy",
        "upgrade",
        "use_responses_lite",
        "visibility",
        "web_search_tool_type",
    }
)


class CodexCLIConfigError(ValueError):
    """A local Codex catalog or configuration did not match the reviewed contract."""


def _feature_catalog(features_output: str) -> dict[str, tuple[str, bool]]:
    if not isinstance(features_output, str) or not features_output.strip():
        raise CodexCLIConfigError("Codex feature catalog is unavailable")
    features: dict[str, tuple[str, bool]] = {}
    for line in features_output.splitlines():
        value = line.strip()
        if not value:
            continue
        match = _FEATURE_LINE.fullmatch(value)
        if match is None:
            raise CodexCLIConfigError("Codex feature catalog is malformed")
        name, stage, enabled = match.groups()
        if stage not in _FEATURE_STAGES or name in features:
            raise CodexCLIConfigError("Codex feature catalog is unsupported")
        features[name] = (stage, enabled == "true")
    if not _REQUIRED_TOOL_FEATURES <= features.keys():
        raise CodexCLIConfigError("Codex feature catalog is incomplete")
    skip_skills = features.get("skip_host_skill_discovery")
    if skip_skills is None or skip_skills[0] in {"removed", "deprecated"}:
        raise CodexCLIConfigError("Codex skill-discovery guard is unsupported")
    return features


def _reject_json_constant(_value: str) -> None:
    raise ValueError("non-standard JSON constant")


def tool_free_config(features_output: str) -> dict[str, Any]:
    """Disable all configurable 0.156.0 features and optional tool surfaces."""
    features = _feature_catalog(features_output)
    config: dict[str, Any] = {
        "apps._default.enabled": False,
        "approval_policy": "never",
        "forced_login_method": "chatgpt",
        "history.persistence": "none",
        "model_provider": "openai",
        "project_doc_max_bytes": 0,
        "suppress_unstable_features_warning": True,
        "web_search": "disabled",
    }
    for name, (stage, _enabled) in features.items():
        if stage not in {"removed", "deprecated"}:
            config[f"features.{name}"] = False
    # This is a safety feature, not a tool: prevent host skill discovery entirely.
    config["features.skip_host_skill_discovery"] = True
    return {key: config[key] for key in sorted(config)}


def output_schema(*, python_tool: bool = True) -> dict[str, Any]:
    """Return Docloop's strict, bounded final JSON envelope schema."""
    if python_tool:
        call_schema = {
            "type": "object",
            "properties": {
                "op": {"type": "string", "enum": ["run_python"]},
                "code": {"type": "string"},
            },
            "required": ["op", "code"],
            "additionalProperties": False,
        }
        max_calls = 1
    else:
        # The API requires additionalProperties=false for every object. A
        # serialized call retains Engine's flexible operation-specific fields.
        call_schema = {"type": "string"}
        max_calls = 16
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "calls": {
                "type": "array",
                "items": call_schema,
                "maxItems": max_calls,
            },
            "note": {"type": "string"},
            "done": {"type": "boolean"},
        },
        "required": ["calls", "note", "done"],
        "additionalProperties": False,
    }


def tool_free_catalog(
    models_output: str,
    model: str = NATIVE_MODEL,
    effort: str = NATIVE_EFFORT,
) -> dict[str, Any]:
    """Isolate one exact refreshed model row and clear every advertised tool field."""
    if model != NATIVE_MODEL:
        raise CodexCLIConfigError("Codex model is outside the reviewed allowlist")
    try:
        catalog = json.loads(models_output, parse_constant=_reject_json_constant)
    except (TypeError, ValueError):
        raise CodexCLIConfigError("Codex model catalog is malformed") from None
    if not isinstance(catalog, dict) or set(catalog) != {"models"}:
        raise CodexCLIConfigError("Codex model catalog is unsupported")
    models = catalog.get("models")
    if not isinstance(models, list) or not models:
        raise CodexCLIConfigError("Codex model catalog is unavailable")
    slugs: set[str] = set()
    for entry in models:
        if not isinstance(entry, dict) or not isinstance(entry.get("slug"), str):
            raise CodexCLIConfigError("Codex model catalog is malformed")
        if entry["slug"] in slugs:
            raise CodexCLIConfigError("Codex model catalog has duplicate entries")
        slugs.add(entry["slug"])
    matches = [entry for entry in models if entry["slug"] == model]
    if len(matches) != 1:
        raise CodexCLIConfigError("Exact gpt-6-luna catalog entry required")
    source = matches[0]
    if not _REQUIRED_MODEL_FIELDS <= source.keys():
        raise CodexCLIConfigError("Codex model catalog entry is incomplete")
    if source.get("supported_in_api") is not True:
        raise CodexCLIConfigError("Codex model is not supported by the API")
    levels = source.get("supported_reasoning_levels")
    supported_efforts = {
        level["effort"]
        for level in levels
        if isinstance(level, dict) and isinstance(level.get("effort"), str)
    } if isinstance(levels, list) else set()
    if effort not in supported_efforts:
        raise CodexCLIConfigError("Codex model does not support requested reasoning effort")
    if source.keys() - _MODEL_FIELDS_0_156:
        raise CodexCLIConfigError("Codex model catalog added an unreviewed field")

    result = copy.deepcopy(source)
    result.update(
        shell_type="disabled",
        apply_patch_tool_type=None,
        experimental_supported_tools=[],
        supports_search_tool=False,
        tool_mode="function",
        include_apps_usage_instructions=False,
        include_plugin_usage_instructions=False,
        include_skills_usage_instructions=False,
        node_repl_disabled=True,
    )
    if any(
        (
            result["shell_type"] != "disabled",
            result["apply_patch_tool_type"] is not None,
            result["experimental_supported_tools"] != [],
            result["supports_search_tool"] is not False,
            result["include_apps_usage_instructions"] is not False,
            result["include_plugin_usage_instructions"] is not False,
            result["include_skills_usage_instructions"] is not False,
            result["node_repl_disabled"] is not True,
        )
    ):
        raise CodexCLIConfigError("Codex model still advertises a tool")
    return {"models": [result]}


def _write_new_private_json(path: Path, value: dict[str, Any]) -> None:
    data = json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n"
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        try:
            path.unlink()
        except OSError:
            pass
        raise


def build_codex_exec_command(
    executable: str,
    cwd: str | os.PathLike[str],
    model: str,
    effort: str,
    schema_path: str | os.PathLike[str],
    features_output: str,
    *,
    models_output: str,
    python_tool: bool = True,
) -> list[str]:
    """Write private schema/catalog files and return fixed, tool-free exec argv.

    The caller supplies output from ``codex features list`` and refreshed
    ``codex debug models`` for the same installed CLI. The execution directory
    must already exist and be empty; schema/catalog artifacts live beside the
    schema path, outside that working root.
    """
    if not isinstance(executable, str) or not executable.strip():
        raise CodexCLIConfigError("Codex executable is unavailable")
    if model != NATIVE_MODEL or not isinstance(effort, str) or not effort:
        raise CodexCLIConfigError("Only gpt-6-luna with a catalog-supported effort is reviewed")
    config = tool_free_config(features_output)
    isolated = tool_free_catalog(models_output, model, effort)

    supplied_work_dir = Path(cwd)
    if supplied_work_dir.is_symlink():
        raise CodexCLIConfigError("Codex execution directory must not be a symlink")
    work_dir = supplied_work_dir.resolve()
    if not work_dir.is_dir() or next(work_dir.iterdir(), None) is not None:
        raise CodexCLIConfigError("Codex execution directory must be empty")
    schema = Path(schema_path).resolve()
    if not schema.is_absolute() or not schema.parent.is_dir():
        raise CodexCLIConfigError("Codex output schema path is invalid")
    if schema == work_dir or work_dir in schema.parents:
        raise CodexCLIConfigError("Codex output artifacts must stay outside its working directory")
    catalog_path = schema.with_name("codex-model-catalog.json")
    if schema == catalog_path or schema.exists() or catalog_path.exists():
        raise CodexCLIConfigError("Codex output artifact path is already in use")

    _write_new_private_json(schema, output_schema(python_tool=python_tool))
    try:
        _write_new_private_json(catalog_path, isolated)
    except BaseException:
        schema.unlink(missing_ok=True)
        raise

    config.update(
        model_catalog_json=str(catalog_path),
        model_reasoning_effort=effort,
    )
    command = [
        executable,
        "exec",
        "--ignore-user-config",
        "--ignore-rules",
        "--ephemeral",
        "--json",
        "--strict-config",
        "--sandbox",
        "read-only",
        "--skip-git-repo-check",
        "--output-schema",
        str(schema),
        "-m",
        model,
        "-C",
        str(work_dir),
    ]
    for key, value in sorted(config.items()):
        command.extend(["-c", f"{key}={json.dumps(value, ensure_ascii=False, separators=(',', ':'))}"])
    command.append("-")
    return command
