"""Session-authorized notebook projections over the native Docloop Store.

The host must authorize every request and resolve the SAME Store used by the
session's Engine. This module neither chooses filesystem paths from HTTP input
nor creates an alternate provider, executor, or transcript.
"""

from __future__ import annotations

import asyncio
import copy
import inspect
import json
import re
from dataclasses import dataclass
from typing import Awaitable, Callable, Literal
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from .document import Node, canonical, digest
from .formats import encode
from .storage_response import history_state, storage_error
from .store import Conflict, HistoryFailure, SaveFailure, Store

MAX_BODY_BYTES = 1024 * 1024
MAX_DOCUMENT_BYTES = 8 * 1024 * 1024
MAX_NODE_BYTES = 256 * 1024
MAX_OUTPUT_BYTES = 64 * 1024
MAX_NODES = 4096
RECEIPTS_KEY = "docloop_notebook_edits"
PROTECTED_ROLES = frozenset(
    {
        "human",
        "user_instruction",
        "instructions",
        "tool_inventory",
        "context_tool",
        "read",
        "error",
        "status",
        "execution",
    }
)
SESSION_ID = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")
NODE_ID = re.compile(r"[A-Za-z0-9_-]{1,64}\Z")
REVISION = re.compile(r"[a-f0-9]{64}\Z")


@dataclass(frozen=True)
class NotebookBinding:
    session_id: str
    store: Store

    @property
    def binding_id(self) -> str:
        return digest(canonical([self.session_id, str(self.store.path)]))


Resolver = Callable[
    [Request, str, Literal["read", "edit"]], NotebookBinding | Awaitable[NotebookBinding]
]


def _editable(node: Node) -> bool:
    return (
        node.id != "omnigent-status"
        and node.metadata.get("docloop_role") not in PROTECTED_ROLES
        and not node.metadata.get("pinned", False)
    )


def _bounded(text: str, size: int) -> tuple[str, bool]:
    raw = text.encode("utf-8")
    if len(raw) <= size:
        return text, False
    return raw[:size].decode("utf-8", errors="ignore"), True


def _output_text(node: Node) -> tuple[str, bool]:
    parts: list[str] = []
    size = 0
    for output in node.outputs:
        if not isinstance(output, dict):
            continue
        # Imported notebooks may contain malformed rich output metadata. Text
        # remains useful even when "data" is absent or is not an object.
        data = output.get("data")
        text = output.get("text")
        if text is None and isinstance(data, dict):
            text = data.get("text/plain", "")
        if isinstance(text, list):
            text = "".join(x for x in text if isinstance(x, str))
        if not isinstance(text, str):
            text = ""
        if output.get("output_type") == "error":
            text = f"{output.get('ename', 'Error')}: {output.get('evalue', '')}"
        if not text:
            continue
        # Separators consume the SAME byte allowance as output, including at
        # Unicode boundaries. Empty/malformed output entries add no newlines.
        addition = ("\n" if parts else "") + text
        addition, cut = _bounded(addition, max(0, MAX_OUTPUT_BYTES - size))
        if addition:
            parts.append(addition)
            size += len(addition.encode("utf-8"))
        if cut:
            return "".join(parts), True
    # Rich HTML/JavaScript output is deliberately never sent to the renderer.
    return "".join(parts), False


def _read(binding: NotebookBinding):
    path = binding.store.path
    if not path.is_file():
        raise HTTPException(404, "This session has no initialized Docloop notebook")
    if path.stat().st_size > MAX_DOCUMENT_BYTES:
        raise HTTPException(413, "Notebook exceeds the bounded pane size; use its native editor")
    doc, revision = binding.store.read()
    if len(doc.nodes) > MAX_NODES:
        raise HTTPException(413, "Notebook has too many nodes for this pane")
    return doc, revision


def project_document(binding: NotebookBinding, doc, revision: str, *, read_only=False) -> dict:
    nodes = []
    for node in doc.nodes:
        source, truncated = _bounded(node.source, MAX_NODE_BYTES)
        output, output_truncated = _output_text(node)
        role = node.metadata.get("docloop_role")
        nodes.append(
            {
                "id": node.id,
                "kind": node.kind,
                "language": node.language,
                "level": node.level,
                "source": source,
                "source_truncated": truncated,
                "source_bytes": len(node.source.encode("utf-8")),
                "output_text": output,
                "output_truncated": output_truncated,
                "role": role if isinstance(role, str) else None,
                "editable": not read_only and _editable(node) and not truncated,
            }
        )
    return {
        "schema_version": 1,
        "session_id": binding.session_id,
        "binding_id": binding.binding_id,
        "revision": revision,
        "document_name": binding.store.path.name,
        "format": binding.store.path.suffix.lstrip("."),
        "nodes": nodes,
        "capabilities": {
            "edit_source": not read_only,
            "create_node": not read_only,
            "direct_execution": False,
        },
        "execution_hint": "Execute cells through this session's native chat and configured executor.",
    }


def snapshot(binding: NotebookBinding) -> dict:
    doc, revision = _read(binding)
    return {
        **project_document(binding, doc, revision),
        "history_status": history_state(binding.store),
    }


def validate_edit(body: dict) -> dict:
    if not isinstance(body, dict) or set(body) != {
        "revision",
        "binding_id",
        "change_id",
        "changes",
    }:
        raise ValueError("Expected revision, binding_id, change_id and changes only")
    if not isinstance(body["revision"], str) or not REVISION.fullmatch(body["revision"]):
        raise ValueError("A full current document revision is required")
    if not isinstance(body["binding_id"], str) or not REVISION.fullmatch(body["binding_id"]):
        raise ValueError("A full session binding ID is required")
    try:
        change_id = UUID(body["change_id"])
    except (ValueError, TypeError, AttributeError) as exc:
        raise ValueError("change_id must be a canonical UUIDv4") from exc
    if change_id.version != 4 or str(change_id) != body["change_id"]:
        raise ValueError("change_id must be a canonical UUIDv4")
    changes = body["changes"]
    if not isinstance(changes, list) or not 1 <= len(changes) <= 64:
        raise ValueError("Supply between 1 and 64 edits")
    addresses = set()
    for change in changes:
        if not isinstance(change, dict):
            raise ValueError("Every edit must be an object")
        op = change.get("op")
        allowed = (
            {"op", "id", "source"} if op == "update" else {"op", "id", "source", "kind", "language"}
        )
        if op not in {"update", "create"} or set(change) - allowed:
            raise ValueError("Only source updates and new markdown/code nodes are supported")
        if not {"op", "id", "source"} <= set(change):
            raise ValueError("Every edit requires op, id and source")
        node_id, source = change["id"], change["source"]
        if not isinstance(node_id, str) or not NODE_ID.fullmatch(node_id):
            raise ValueError("Invalid node ID")
        if node_id in addresses:
            raise ValueError("A node may occur only once in one atomic edit")
        addresses.add(node_id)
        if not isinstance(source, str) or len(source.encode("utf-8")) > MAX_NODE_BYTES:
            raise ValueError("Node source must be bounded UTF-8 text")
        if op == "create":
            if change.get("kind") not in {"markdown", "code"}:
                raise ValueError("New nodes must be markdown or code")
            language = change.get("language", "python")
            if (
                not isinstance(language, str)
                or len(language) > 64
                or not re.fullmatch(r"[A-Za-z0-9_+.-]+", language)
            ):
                raise ValueError("Invalid language")
    return body


def apply_edit(binding: NotebookBinding, body: dict) -> bool:
    """Return whether this exact edit was already applied; never retry a CAS failure."""
    validate_edit(body)
    if body["binding_id"] != binding.binding_id:
        raise Conflict("The session/document binding changed; reload before editing")
    doc, revision = _read(binding)
    receipts = doc.metadata.get(RECEIPTS_KEY, [])
    if not isinstance(receipts, list) or any(
        not isinstance(receipt, dict)
        or not isinstance(receipt.get("change_id"), str)
        or not isinstance(receipt.get("request_hash"), str)
        for receipt in receipts
    ):
        raise ValueError("Notebook edit receipts are malformed")
    request_hash = digest(canonical(body))
    for receipt in receipts:
        if receipt.get("change_id") == body["change_id"]:
            if receipt.get("request_hash") != request_hash:
                raise Conflict("change_id was already used for a different edit")
            if binding.store.history_status()["status"] != "recorded":
                raise HistoryFailure(
                    phase="history_pending",
                    installed=True,
                    history="pending",
                    current_revision=revision,
                )
            return True
    if revision != body["revision"]:
        raise Conflict("Document changed; your draft has not been applied")
    candidate = copy.deepcopy(doc)
    for change in body["changes"]:
        if change["op"] == "update":
            node = candidate.get(change["id"])
            if not _editable(node):
                raise HTTPException(
                    403, "Recorded conversation, tool receipts and pinned nodes are read-only"
                )
            if len(node.source.encode("utf-8")) > MAX_NODE_BYTES:
                raise HTTPException(403, "Truncated source must be edited in the native editor")
            candidate.update(change["id"], source=change["source"])
        else:
            if change["id"] == "omnigent-status":
                raise ValueError("Reserved node ID")
            candidate.insert(
                Node(
                    change["id"],
                    change["kind"],
                    change["source"],
                    language=change.get("language", "python"),
                )
            )
    candidate.metadata[RECEIPTS_KEY] = (
        receipts
        + [
            {
                "change_id": body["change_id"],
                "request_hash": request_hash,
            }
        ]
    )[-512:]
    # Check the actual native serialization including new edit receipts and Org
    # stabilization metadata, not merely the submitted source sizes. Rejection
    # must leave both the file and its native history untouched.
    if len(candidate.nodes) > MAX_NODES:
        raise HTTPException(413, "Edit would exceed the pane node limit")
    encoded = encode(candidate, binding.store.path.suffix, stabilize=True)
    if len(encoded.encode("utf-8")) > MAX_DOCUMENT_BYTES:
        raise HTTPException(413, "Edit would exceed the bounded pane document size")
    binding.store.save(candidate, revision, "Notebook pane edit " + body["change_id"])
    return False


def _response(data: dict, status_code: int = 200) -> JSONResponse:
    return JSONResponse(
        data,
        status_code=status_code,
        headers={
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
            "Vary": "Authorization, Cookie",
        },
    )


def notebook_router(resolve: Resolver, *, prefix: str = "/v1") -> APIRouter:
    """Host resolver must authorize BEFORE opening a Store; no permissive default."""
    if not callable(resolve):
        raise ValueError("An authorizing session resolver is required")
    router = APIRouter(prefix=prefix)

    async def bound(request: Request, session_id: str, operation: Literal["read", "edit"]):
        if not SESSION_ID.fullmatch(session_id):
            raise HTTPException(400, "Invalid session ID")
        binding = resolve(request, session_id, operation)
        if inspect.isawaitable(binding):
            binding = await binding
        if not isinstance(binding, NotebookBinding) or binding.session_id != session_id:
            raise HTTPException(503, "No verified Docloop binding for this session")
        return binding

    @router.get("/sessions/{session_id}/docloop/document")
    async def get_document(request: Request, session_id: str):
        binding = await bound(request, session_id, "read")
        return _response(await asyncio.to_thread(snapshot, binding))

    @router.get("/sessions/{session_id}/docloop/versions")
    async def get_versions(request: Request, session_id: str, before: str | None = None):
        from .notebook_history_api import history_page

        binding = await bound(request, session_id, "read")
        try:
            return _response(await asyncio.to_thread(history_page, binding, before))
        except SaveFailure as exc:
            return _response(storage_error(exc), 503)

    @router.get("/sessions/{session_id}/docloop/versions/{commit}")
    async def get_version(request: Request, session_id: str, commit: str):
        from .notebook_history_api import historical_document

        binding = await bound(request, session_id, "read")
        try:
            return _response(await asyncio.to_thread(historical_document, binding, commit))
        except SaveFailure as exc:
            return _response(storage_error(exc), 503)

    async def edit_body(request):
        # Custom header + JSON prevents cross-origin form submissions. The host's
        # normal identity/CSRF checks remain authoritative and run above.
        if request.headers.get("x-docloop-edit") != "1":
            raise HTTPException(403, "Notebook edits require the session UI request header")
        if request.headers.get("sec-fetch-site") == "cross-site":
            raise HTTPException(403, "Cross-site notebook edits are not accepted")
        if request.headers.get("content-type", "").split(";", 1)[0].strip() != "application/json":
            raise HTTPException(415, "Notebook edits require application/json")
        chunks, size = [], 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > MAX_BODY_BYTES:
                raise HTTPException(413, "Notebook edit exceeds the request size limit")
            chunks.append(chunk)
        return chunks

    @router.post("/sessions/{session_id}/docloop/recover-history")
    async def recover_history(request: Request, session_id: str):
        binding = await bound(request, session_id, "edit")
        chunks = await edit_body(request)
        try:
            body = json.loads(b"".join(chunks))
            if not isinstance(body, dict) or set(body) != {"revision", "binding_id"}:
                raise ValueError("Expected revision and binding_id only")
            if not isinstance(body["revision"], str) or not REVISION.fullmatch(body["revision"]):
                raise ValueError("A full current document revision is required")
            if body["binding_id"] != binding.binding_id:
                raise Conflict("The session/document binding changed; reload before recovery")
            await asyncio.to_thread(binding.store.recover_history, body["revision"])
            return _response(await asyncio.to_thread(snapshot, binding))
        except SaveFailure as exc:
            return _response(storage_error(exc), 503)
        except Conflict as exc:
            return _response({"error": str(exc), "code": "revision_conflict"}, 409)
        except (ValueError, TypeError, UnicodeError) as exc:
            return _response({"error": str(exc), "code": "recovery_rejected"}, 400)

    @router.patch("/sessions/{session_id}/docloop/document")
    async def edit_document(request: Request, session_id: str):
        binding = await bound(request, session_id, "edit")
        chunks = await edit_body(request)
        try:
            body = json.loads(b"".join(chunks))
            replayed = await asyncio.to_thread(apply_edit, binding, body)
        except SaveFailure as exc:
            return _response(storage_error(exc), 503)
        except Conflict as exc:
            return _response(
                {"error": str(exc), "code": "revision_conflict", "outcome": "not_applied"}, 409
            )
        except HTTPException as exc:
            return _response(
                {"error": str(exc.detail), "code": "edit_rejected", "outcome": "not_applied"},
                exc.status_code,
            )
        except (ValueError, TypeError, UnicodeError) as exc:
            return _response(
                {"error": str(exc), "code": "edit_rejected", "outcome": "not_applied"}, 400
            )
        try:
            current = await asyncio.to_thread(snapshot, binding)
        except Exception:
            # The edit already committed. A failed readback is not a rejected
            # write; preserve its identity so the UI retries the same receipt.
            return _response(
                {
                    "error": "Edit applied, but its refreshed view is unavailable. Retry the same edit to reconcile.",
                    "code": "edit_applied_snapshot_unavailable",
                    "outcome": "applied",
                    "change_id": body["change_id"],
                    "binding_id": binding.binding_id,
                    "replayed": replayed,
                },
                503,
            )
        return _response(
            {"document": current, "replayed": replayed, "change_id": body["change_id"]}
        )

    return router
