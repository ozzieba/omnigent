"""Coherent, forkable notebook + filesystem snapshots in a private Git store."""

from __future__ import annotations

import difflib
import json
import os
import re
import stat
import subprocess
import time
from pathlib import Path, PurePosixPath

from .document import canonical, digest
from .formats import decode
from .store import Conflict, Store

EXCLUDED = [
    ".git",
    "**/.git",
    "**/*.history/",
    "**/*.children/",
    "**/*.forks/",
    ".venv/",
    "**/.venv/",
    "node_modules/",
    "**/node_modules/",
    "__pycache__/",
    "**/__pycache__/",
    ".env",
    ".env.*",
    "**/.env",
    "**/.env.*",
    "*.pem",
    "*.key",
    ".docloop-*",
]


class Checkpoints:
    def __init__(self, store: Store, *, workspace=None, max_bytes=256_000_000, max_files=20_000):
        self.store = store
        self.workspace = Path(workspace).resolve() if workspace is not None else None
        self.max_bytes, self.max_files = max_bytes, max_files
        self.repo = store.history_dir / "state.git"
        with store.lock():
            if not self.repo.exists():
                subprocess.run(["git", "init", "--bare", "--quiet", str(self.repo)], check=True)
                (self.repo / "info/exclude").write_text("\n".join(EXCLUDED) + "\n")

    def git(self, *args, data=None, workspace=None):
        env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
        env.update(
            GIT_AUTHOR_NAME="Docloop",
            GIT_AUTHOR_EMAIL="docloop@localhost",
            GIT_COMMITTER_NAME="Docloop",
            GIT_COMMITTER_EMAIL="docloop@localhost",
        )
        command = ["git", "--git-dir", str(self.repo)]
        if workspace is not None:
            command += ["--work-tree", str(workspace)]
        result = subprocess.run(
            command + list(args),
            input=data,
            capture_output=True,
            cwd=workspace or self.store.path.parent,
            env=env,
            check=True,
        )
        return result.stdout

    def _head(self):
        try:
            return self.git("rev-parse", "--verify", "refs/heads/checkpoints").decode().strip()
        except subprocess.CalledProcessError:
            return None

    def _environment(self, doc, *, store=None, use_override=True):
        store = store or self.store
        try:
            node = doc.get("docloop-environment")
        except ValueError:
            descriptor = {"kind": "local", "workspace": str(store.path.parent)}
        else:
            descriptor = json.loads(node.source)
        if not isinstance(descriptor, dict) or not isinstance(descriptor.get("workspace"), str):
            raise ValueError("Malformed checkpoint environment descriptor")
        workspace = (self.workspace if use_override else None) or Path(
            descriptor["workspace"]
        ).resolve()
        if not workspace.is_dir():
            raise ValueError("Checkpoint workspace must be an existing directory")
        return workspace, descriptor

    def _workspace_tree(self, workspace, notebooks=()):
        self.git("read-tree", "--empty", workspace=workspace)
        eligible = self.git("ls-files", "--others", "--exclude-standard", "-z", workspace=workspace)
        paths = [os.fsdecode(raw) for raw in eligible.split(b"\0") if raw]
        excluded_notebooks = {self.store.path, *notebooks}
        paths = [p for p in paths if workspace / p not in excluded_notebooks]
        if len(paths) > self.max_files:
            raise ValueError("Workspace file count exceeds checkpoint limit")
        total = 0
        index = []
        for relative in paths:
            path = workspace / relative
            info = path.lstat()
            if not (stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode)):
                raise ValueError(f"Unsupported checkpoint file type: {relative}")
            total += info.st_size
            if total > self.max_bytes:
                raise ValueError("Workspace size exceeds checkpoint byte limit")
            if stat.S_ISLNK(info.st_mode):
                data, mode = os.fsencode(os.readlink(path)), "120000"
            else:
                with path.open("rb") as stream:
                    data = stream.read(self.max_bytes + 1)
                mode = "100755" if info.st_mode & 0o111 else "100644"
            after = path.lstat()
            if (info.st_ino, info.st_size, info.st_mtime_ns, info.st_mode) != (
                after.st_ino,
                after.st_size,
                after.st_mtime_ns,
                after.st_mode,
            ):
                raise Conflict(f"File changed while checkpointing: {relative}")
            if len(data) > self.max_bytes:
                raise ValueError("Workspace size exceeds checkpoint byte limit")
            oid = self.git("hash-object", "-w", "--stdin", data=data).decode().strip()
            index.append(f"{mode} {oid}\t".encode() + os.fsencode(relative) + b"\0")
        if index:
            self.git(
                "update-index", "-z", "--index-info", data=b"".join(index), workspace=workspace
            )
        tree = self.git("write-tree").decode().strip()
        entries = self._entries(tree)
        if any(mode == "160000" for mode, _, _, _ in entries):
            raise ValueError("Nested repositories require a separate checkpoint")
        return tree, entries

    def _entries(self, tree):
        entries = []
        for entry in self.git("ls-tree", "-r", "-z", "--long", tree).split(b"\0"):
            if not entry:
                continue
            header, path = entry.split(b"\t", 1)
            mode, kind, oid, size = header.decode().split()
            if kind != "blob":
                raise ValueError("Checkpoint requires ordinary files, not nested repositories")
            entries.append((mode, oid, int(size), os.fsdecode(path)))
        return entries

    def _directories(self, workspace):
        directories = []
        for parent, names, _ in os.walk(workspace, followlinks=False):
            retained = []
            for name in names:
                path = Path(parent) / name
                if path.is_symlink():
                    continue
                relative = path.relative_to(workspace).as_posix()
                try:
                    ignored = self.git(
                        "check-ignore",
                        "--no-index",
                        "--stdin",
                        "-z",
                        data=os.fsencode(relative + "/") + b"\0",
                        workspace=workspace,
                    )
                except subprocess.CalledProcessError as exc:
                    if exc.returncode != 1:
                        raise
                    ignored = b""
                if not ignored:
                    directories.append(relative)
                    retained.append(name)
            names[:] = retained
            if len(directories) > self.max_files:
                raise ValueError("Workspace directory count exceeds checkpoint limit")
        return sorted(directories)

    @staticmethod
    def _team(doc):
        from .team import Team

        return Team._state(doc)

    def _agent_graph(self, root_doc):
        """Follow only explicit child references; running or ambiguous workers must quiesce."""
        found = []
        seen = {str(self.store.path)}
        pending = [(self.store, root_doc)]
        while pending:
            owner, doc = pending.pop()
            for node in doc.nodes:
                receipt = node.metadata.get("docloop_execution", {})
                if receipt.get("status") in {"running", "unknown"}:
                    raise Conflict(
                        "Execution must be quiescent and resolved before checkpoint: " + node.id
                    )
            for ident, child in sorted(self._team(doc)["children"].items()):
                if child.get("status") not in {
                    "paused",
                    "complete",
                    "cancelled",
                    "error",
                    "interrupted",
                }:
                    raise Conflict("Child activity must be quiescent before checkpoint: " + ident)
                path = Path(child["path"]).resolve()
                if str(path) in seen:
                    raise ValueError("Child graph contains a cycle or duplicate notebook reference")
                seen.add(str(path))
                if len(seen) > 64:
                    raise ValueError("Checkpoint child graph exceeds 64 notebooks")
                if not path.is_file():
                    raise ValueError("Referenced child notebook is missing: " + ident)
                # Read without constructing Store: checkpoint reads must not initialize child history.
                raw = path.read_bytes()
                child_doc = decode(raw.decode(), path.suffix)
                entry = {
                    "path": str(path),
                    "doc": child_doc,
                    "raw": raw,
                    "notebook": "notebook" + path.suffix,
                    "relative": f"agents/agent-{len(found):04d}",
                }
                found.append(entry)
                pending.append((owner, child_doc))
        return found

    def _snapshot_child(self, entry):
        path = Path(entry["path"])
        raw = entry["raw"]
        if path.read_bytes() != raw:
            raise Conflict("Child changed while traversing checkpoint graph")
        doc = decode(raw.decode(), path.suffix)
        try:
            node = doc.get("docloop-environment")
        except ValueError:
            environment = {"kind": "local", "workspace": str(path.parent)}
        else:
            environment = json.loads(node.source)
        if not isinstance(environment, dict) or not isinstance(environment.get("workspace"), str):
            raise ValueError("Malformed child environment descriptor")
        workspace = Path(environment["workspace"]).resolve()
        if not workspace.is_dir():
            raise ValueError("Child workspace is missing")
        directories = self._directories(workspace)
        tree, entries = self._workspace_tree(workspace, notebooks=[path])
        return {
            **{k: v for k, v in entry.items() if k != "doc"},
            "raw": raw,
            "environment": environment,
            "workspace": str(workspace),
            "workspace_tree": tree,
            "directories": directories,
            "files": [p for _, _, _, p in entries],
            "bytes": sum(x[2] for x in entries),
        }

    def _agent_tree(self, snapshot):
        blob = self.git("hash-object", "-w", "--stdin", data=snapshot["raw"]).decode().strip()
        return (
            self.git(
                "mktree",
                data=(
                    f"100644 blob {blob}\t{snapshot['notebook']}\n"
                    f"040000 tree {snapshot['workspace_tree']}\tworkspace\n"
                ).encode(),
            )
            .decode()
            .strip()
        )

    def create(self, expected_revision, message="Checkpoint notebook and workspace"):
        with self.store.lock():
            doc, revision = self.store.read()
            if expected_revision != revision:
                raise Conflict("Document changed before checkpoint")
            notebook = self.store.path.read_bytes()
            workspace, environment = self._environment(doc)
            graph = self._agent_graph(doc)
            children = [self._snapshot_child(entry) for entry in graph]
            directories = self._directories(workspace)
            tree, entries = self._workspace_tree(workspace)
            verify_tree, _ = self._workspace_tree(workspace)
            if (
                tree != verify_tree
                or directories != self._directories(workspace)
                or self.store.path.read_bytes() != notebook
            ):
                raise Conflict("Workspace or notebook changed during checkpoint; retry when idle")
            for child in children:
                path, child_workspace = Path(child["path"]), Path(child["workspace"])
                child_tree, _ = self._workspace_tree(child_workspace, notebooks=[path])
                if (
                    path.read_bytes() != child["raw"]
                    or child_tree != child["workspace_tree"]
                    or self._directories(child_workspace) != child["directories"]
                ):
                    raise Conflict("Child notebook or workspace changed during checkpoint")
            if (
                sum(child["bytes"] for child in children) + sum(x[2] for x in entries)
                > self.max_bytes
            ):
                raise ValueError("Combined checkpoint byte limit exceeded")
            if sum(len(child["files"]) for child in children) + len(entries) > self.max_files:
                raise ValueError("Combined checkpoint file count limit exceeded")
            if self.store.path.read_bytes() != notebook:
                raise Conflict("Notebook changed while verifying child snapshots")
            if (
                len(notebook)
                + sum(len(child["raw"]) + child["bytes"] for child in children)
                + sum(x[2] for x in entries)
                > self.max_bytes
            ):
                raise ValueError("Combined notebook and workspace byte limit exceeded")
            manifest = {
                "schema": 1,
                "source": str(self.store.path),
                "agents": [{k: v for k, v in child.items() if k != "raw"} for child in children],
                "created_at": time.time(),
                "environment": environment,
                "workspace": str(workspace),
                "notebook": "notebook" + self.store.path.suffix,
                "notebook_revision": digest(notebook.decode()),
                "workspace_tree": tree,
                "files": [p for _, _, _, p in entries],
                "directories": directories,
                "excluded": EXCLUDED,
                "respects_gitignore": True,
                "bytes": sum(size for _, _, size, _ in entries),
            }
            note_blob = self.git("hash-object", "-w", "--stdin", data=notebook).decode().strip()
            manifest_blob = (
                self.git("hash-object", "-w", "--stdin", data=canonical(manifest).encode())
                .decode()
                .strip()
            )
            agent_entries = "".join(
                f"040000 tree {self._agent_tree(child)}\t{Path(child['relative']).name}\n"
                for child in children
            )
            agents_tree = self.git("mktree", data=agent_entries.encode()).decode().strip()
            root = (
                self.git(
                    "mktree",
                    data=(
                        f"100644 blob {manifest_blob}\tmanifest.json\n"
                        f"100644 blob {note_blob}\t{manifest['notebook']}\n"
                        f"040000 tree {tree}\tworkspace\n"
                        f"040000 tree {agents_tree}\tagents\n"
                    ).encode(),
                )
                .decode()
                .strip()
            )
            parent = self._head()
            commit_args = ["commit-tree", root, "-m", message]
            if parent:
                commit_args += ["-p", parent]
            commit = self.git(*commit_args).decode().strip()
            self.git("update-ref", "refs/heads/checkpoints", commit, parent or "0" * 40)
            return commit

    def inspect(self, commit):
        if not re.fullmatch(r"[a-f0-9]{40}", commit):
            raise ValueError("Checkpoint must be a full commit ID")
        manifest = json.loads(self.git("show", commit + ":manifest.json"))
        if manifest.get("schema") != 1 or manifest.get("notebook") not in {
            "notebook.ipynb",
            "notebook.org",
        }:
            raise ValueError("Unsupported checkpoint format")
        return manifest

    def history(self):
        if self._head() is None:
            return []
        rows = self.git("log", "refs/heads/checkpoints", "--format=%H%x09%aI%x09%s").decode()
        return [
            dict(zip(("commit", "date", "message"), row.split("\t", 2)))
            for row in rows.splitlines()
        ]

    def diff(self, older, newer):
        old, new = self.inspect(older), self.inspect(newer)
        filesystem = self.git(
            "diff", "--no-ext-diff", "--no-textconv", older, newer, "--", "workspace"
        ).decode(errors="replace")

        def lines(commit, manifest):
            raw = self.git("show", commit + ":" + manifest["notebook"]).decode()
            doc = decode(raw, Path(manifest["notebook"]).suffix)
            return [canonical({"metadata": doc.metadata, "extra": doc.extra}) + "\n"] + [
                canonical(n.value()) + "\n" for n in doc.nodes
            ]

        notebook = "".join(difflib.unified_diff(lines(older, old), lines(newer, new), older, newer))
        agents = self.git(
            "diff", "--no-ext-diff", "--no-textconv", older, newer, "--", "agents"
        ).decode(errors="replace")
        environment = "".join(
            difflib.unified_diff(
                [canonical(old["environment"]) + "\n"],
                [canonical(new["environment"]) + "\n"],
                "environment-before",
                "environment-after",
            )
        )
        return filesystem + notebook + agents + environment

    def restore(self, commit, destination):
        manifest = self.inspect(commit)
        destination = Path(destination).absolute()
        if destination.is_symlink() or (destination.exists() and any(destination.iterdir())):
            raise ValueError("Restore destination must be a new or empty directory")
        children = manifest.get("agents", [])
        if not isinstance(children, list) or len(children) > 63:
            raise ValueError("Invalid checkpoint child graph")
        snapshots = [
            {**manifest, "relative": "", "path": manifest.get("source", str(self.store.path))},
            *children,
        ]
        paths, workspaces, documents = {}, {}, []
        for index, snapshot in enumerate(snapshots):
            relative = snapshot["relative"]
            if index and not re.fullmatch(r"agents/agent-[0-9]{4}", relative):
                raise ValueError("Invalid child snapshot location")
            if snapshot["notebook"] not in {"notebook.org", "notebook.ipynb"}:
                raise ValueError("Invalid child notebook format")
            target = destination / relative / snapshot["notebook"]
            source = snapshot["path"]
            if source in paths:
                raise ValueError("Duplicate notebook in checkpoint graph")
            paths[source] = target
            old_workspace = str(Path(snapshot["workspace"]).resolve())
            workspaces.setdefault(old_workspace, destination / relative / "workspace")
        # Preserve nested workspace sharing as well as exact shared-workspace aliases.
        for source in sorted(workspaces, key=lambda value: len(Path(value).parts)):
            for ancestor in sorted(workspaces, key=lambda value: len(Path(value).parts)):
                if source != ancestor and Path(source).is_relative_to(ancestor):
                    workspaces[source] = workspaces[ancestor] / Path(source).relative_to(ancestor)
                    break
        files, directory_paths = {}, set()
        for snapshot in snapshots:
            prefix = snapshot["relative"] + "/" if snapshot["relative"] else ""
            workspace = workspaces[str(Path(snapshot["workspace"]).resolve())]
            entries = self._entries(commit + ":" + prefix + "workspace")
            directory_paths.add(workspace)
            for relative in snapshot.get("directories", []):
                path = PurePosixPath(relative)
                if path.is_absolute() or ".." in path.parts or not path.parts:
                    raise ValueError("Invalid checkpoint directory")
                directory_paths.add(workspace / relative)
            for mode, oid, _, relative in entries:
                path = PurePosixPath(relative)
                if (
                    path.is_absolute()
                    or ".." in path.parts
                    or not path.parts
                    or mode not in {"100644", "100755", "120000"}
                ):
                    raise ValueError("Invalid checkpoint path or mode")
                target = workspace / relative
                if target in files and files[target] != (mode, oid):
                    raise ValueError("Overlapping workspaces disagree in checkpoint")
                files[target] = (mode, oid)
            raw = self.git("show", commit + ":" + prefix + snapshot["notebook"]).decode()
            doc = decode(raw, Path(snapshot["notebook"]).suffix)
            environment = {**snapshot["environment"], "workspace": str(workspace)}
            try:
                doc.update("docloop-environment", source=canonical(environment))
            except ValueError:
                from .document import Node

                doc.insert(Node("docloop-environment", "raw", canonical(environment)))
            try:
                team_node = doc.get("docloop-team-state")
            except ValueError:
                pass
            else:
                state = self._team(doc)
                for child in state["children"].values():
                    if child["path"] not in paths:
                        raise ValueError(
                            "Checkpoint lacks referenced child snapshot; cannot fork safely"
                        )
                    child["path"] = str(paths[child["path"]])
                    child.pop("owner_pid", None)
                    if child.get("status") in {"starting", "running", "cancelling"}:
                        child["status"] = "interrupted"
                if state.get("parent") in paths:
                    state["parent"] = str(paths[state["parent"]])
                else:
                    # Forking a child alone creates a detached root, never a live link to its old parent.
                    state.pop("parent", None)
                doc.update(team_node.id, source=canonical(state))
            doc.metadata["docloop_restored_from"] = {
                "checkpoint": commit,
                "source": snapshot["path"],
            }
            documents.append((paths[snapshot["path"]], doc))
        # Preflight all destination topology before materializing any file.
        for path in [*files, *directory_paths, *(target for target, _ in documents)]:
            for ancestor in path.parents:
                if ancestor == destination:
                    break
                if ancestor in files:
                    raise ValueError("Checkpoint file conflicts with destination directory")
        if any(path in files for path in directory_paths):
            raise ValueError("Checkpoint directory conflicts with file")
        destination.mkdir(parents=True, exist_ok=True)
        for path in sorted(directory_paths, key=lambda value: len(value.parts)):
            path.mkdir(parents=True, exist_ok=True)
        for path, (mode, oid) in files.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            data = self.git("cat-file", "blob", oid)
            if mode == "120000":
                os.symlink(os.fsdecode(data), path)
            else:
                path.write_bytes(data)
                path.chmod(0o755 if mode == "100755" else 0o644)
        restored = []
        for target, doc in documents:
            store = Store(target)
            store.save(doc, store.read()[1], f"Fork from checkpoint {commit}")
            restored.append(store)
        return restored[0]
