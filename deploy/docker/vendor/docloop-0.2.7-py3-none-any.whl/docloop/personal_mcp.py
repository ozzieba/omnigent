"""Private OAuth header command for one independent personal-cloud MCP grant."""

from __future__ import annotations

import fcntl
import json
import math
import os
import stat
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

USER_AGENT = "docloop/0.2.0 (+https://mcp.ozba.me)"


class CredentialError(RuntimeError):
    pass


def private_read(path, *, projected=False):
    # Kubernetes projected secret symlinks are supported; validate the opened
    # target, so replacement of the link cannot change the checked file.
    flags = os.O_RDONLY | (0 if projected else os.O_NOFOLLOW)
    with os.fdopen(os.open(path, flags), "rb") as stream:
        info = os.fstat(stream.fileno())
        mode = stat.S_IMODE(info.st_mode)
        allowed = mode == 0o600 and info.st_uid == os.geteuid()
        if projected:
            allowed = (
                info.st_uid in {0, os.geteuid()}
                and not mode & 0o037
                and (not mode & 0o040 or info.st_gid in {*os.getgroups(), os.getegid()})
            )
        if not stat.S_ISREG(info.st_mode) or not allowed:
            raise CredentialError("Credential file permissions or ownership are unsafe")
        data = stream.read(1_000_001)
    if len(data) > 1_000_000:
        raise CredentialError("Credential file is too large")
    return data


def token_string(value):
    if not isinstance(value, str) or not value or any(ord(c) < 33 or ord(c) > 126 for c in value):
        raise CredentialError("Malformed credential")
    return value


def validate(tokens, client, resource):
    if not isinstance(tokens, dict):
        raise CredentialError("Malformed token store")
    token_string(tokens.get("access_token"))
    token_string(tokens.get("refresh_token"))
    expiry = float(tokens["expires_at"])
    if not math.isfinite(expiry):
        raise CredentialError("Malformed token expiry")
    if tokens.get("client_id", client) != client or tokens.get("resource", resource) != resource:
        raise CredentialError("Token grant does not match configured client/resource")
    return tokens


def save(path, tokens):
    fd, name = tempfile.mkstemp(prefix=".oauth-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(tokens, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise CredentialError("Token endpoint redirect refused")


def headers(env=None):
    env = os.environ if env is None else env

    def config(key):
        value = env.get("PERSONAL_CLOUD_" + key)
        if not value:
            raise CredentialError("Missing personal MCP configuration")
        return value

    try:
        path = Path(config("TOKEN_PATH"))
        seed = Path(config("TOKEN_SEED"))
        route_path = Path(config("ROUTE_KEY_PATH"))
        endpoint, resource, client = (
            config("TOKEN_ENDPOINT"),
            config("RESOURCE"),
            config("CLIENT_ID"),
        )
        from urllib.parse import urlencode, urlsplit

        url = urlsplit(endpoint)
        if url.scheme != "https" and not (
            url.scheme == "http" and url.hostname in {"localhost", "127.0.0.1", "::1"}
        ):
            raise CredentialError("Token endpoint requires HTTPS")
        if url.username or url.password or url.fragment:
            raise CredentialError("Invalid token endpoint")
        route = token_string(private_read(route_path, projected=True).decode().strip())
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd = os.open(str(path) + ".lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "a") as lock:
            if (
                not stat.S_ISREG(os.fstat(lock.fileno()).st_mode)
                or stat.S_IMODE(os.fstat(lock.fileno()).st_mode) & 0o077
            ):
                raise CredentialError("Token lock must be private and regular")
            fcntl.flock(lock, fcntl.LOCK_EX)
            # All readers recheck after the lock: only one process consumes a
            # rotating refresh token, and a restart never overwrites a live store.
            if not path.exists():
                if path.is_symlink():
                    raise CredentialError("Invalid token destination")
                tokens = validate(json.loads(private_read(seed, projected=True)), client, resource)
                save(path, tokens)
            tokens = validate(json.loads(private_read(path)), client, resource)
            if time.time() >= float(tokens["expires_at"]) - 120:
                request = urllib.request.Request(
                    endpoint,
                    data=urlencode(
                        {
                            "grant_type": "refresh_token",
                            "refresh_token": tokens["refresh_token"],
                            "client_id": client,
                            "resource": resource,
                        }
                    ).encode(),
                    headers={
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Accept": "application/json",
                        "User-Agent": USER_AGENT,
                    },
                )
                with urllib.request.build_opener(NoRedirect).open(request, timeout=30) as response:
                    payload = json.loads(response.read(1_000_001))
                lifetime = float(payload.get("expires_in", 3600))
                if not math.isfinite(lifetime) or lifetime <= 120:
                    raise CredentialError("Token lifetime is insufficient")
                updated = {
                    **tokens,
                    "access_token": payload["access_token"],
                    "refresh_token": payload.get("refresh_token") or tokens["refresh_token"],
                    "expires_at": time.time() + lifetime,
                    "client_id": client,
                    "resource": resource,
                    "scope": payload.get("scope", tokens.get("scope", "mcp:admin")),
                }
                validate(updated, client, resource)
                save(path, updated)
                tokens = updated
            return {
                "Authorization": "Bearer " + tokens["access_token"],
                "x-personal-cloud-route-key": route,
                "User-Agent": USER_AGENT,
            }
    except CredentialError:
        raise
    except Exception:
        # Never expose endpoint bodies, URLs, credentials, or parsing snippets.
        raise CredentialError("Personal MCP credentials unavailable or refresh failed") from None


def main():
    try:
        print(json.dumps(headers()))
        return 0
    except CredentialError as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
