"""Private native Jupyter process: notebook writes use Docloop's versioned store."""

from __future__ import annotations

import json
import os
import secrets
from pathlib import Path

import nbformat
from jupyter_server.services.contents.filemanager import FileContentsManager
from jupyter_server.services.kernels.kernelmanager import MappingKernelManager
from tornado.web import HTTPError

from .formats import decode, encode
from .storage_response import storage_error
from .store import Conflict, SaveFailure, Store


class Contents(FileContentsManager):
    _edit_sessions = None

    def get(self, path, content=True, **kwargs):
        if not content or Path(self._get_os_path(path)).resolve() != Path(
            os.environ["DOCLOOP_NATIVE_DOCUMENT"]
        ):
            return super().get(path, content=content, **kwargs)
        store = Store(os.environ["DOCLOOP_NATIVE_DOCUMENT"])
        with store.lock():
            model = super().get(path, content=content, **kwargs)
            _, revision = store.read()
        if self._edit_sessions is None:
            self._edit_sessions = {}
        session = secrets.token_hex(24)
        self._edit_sessions[session] = revision
        model["content"]["metadata"]["docloop_native_revision"] = session
        return model

    def save(self, model, path=""):
        if Path(self._get_os_path(path)).resolve() != Path(os.environ["DOCLOOP_NATIVE_DOCUMENT"]):
            return super().save(model, path)
        raw = model.get("content")
        if not isinstance(raw, dict):
            raise HTTPError(400, "Notebook content required")
        session = raw.get("metadata", {}).pop("docloop_native_revision", None)
        revision = (self._edit_sessions or {}).get(session)
        if not revision:
            raise HTTPError(409, "Reload notebook before saving: no document revision")
        store = Store(os.environ["DOCLOOP_NATIVE_DOCUMENT"])
        try:
            doc = decode(json.dumps(raw), ".ipynb")
            old, _ = store.read()
            previous = {node.id: node for node in old.nodes}
            for node in doc.nodes:
                if node.id in previous and (
                    node.source,
                    node.kind,
                    node.language,
                    node.outputs,
                    node.extra.get("execution_count"),
                ) != (
                    previous[node.id].source,
                    previous[node.id].kind,
                    previous[node.id].language,
                    previous[node.id].outputs,
                    previous[node.id].extra.get("execution_count"),
                ):
                    node.metadata.pop("docloop_execution", None)
            # Normalize IDs/metadata before signing, retaining only the trust
            # attestations supplied by Jupyter for its normal check-and-sign.
            signing_notebook = nbformat.from_dict(json.loads(encode(doc, ".ipynb")))
            for node in doc.nodes:
                if node.kind == "code":
                    node.metadata.pop("trusted", None)
            saved_revision = store.save(doc, revision, "Save from native Jupyter")
            self._edit_sessions[session] = saved_revision
            with store.lock():
                if store.read()[1] == saved_revision:
                    self.check_and_sign(signing_notebook, path)
        except SaveFailure as exc:
            # Advance only when these exact bytes were installed; never accept a
            # different editor's newer revision as this tab's base.
            if exc.installed is True and exc.current_revision == exc.attempted_revision:
                self._edit_sessions[session] = exc.current_revision
            outcome = storage_error(exc)
            raise HTTPError(503, outcome["error"], reason=outcome["code"]) from exc
        except Conflict as exc:
            raise HTTPError(
                409, "Agent or another editor changed this notebook; reload before saving"
            ) from exc
        return self.get(path, content=False)

    def _is_active(self, path):
        return Path(self._get_os_path(path)).resolve() == Path(
            os.environ["DOCLOOP_NATIVE_DOCUMENT"]
        )

    def delete_file(self, path):
        if self._is_active(path):
            raise HTTPError(409, "The active Docloop notebook cannot be deleted")
        return super().delete_file(path)

    def rename_file(self, old_path, new_path):
        if self._is_active(old_path) or self._is_active(new_path):
            raise HTTPError(409, "The active Docloop notebook cannot be renamed or replaced")
        return super().rename_file(old_path, new_path)

    def restore_checkpoint(self, checkpoint_id, path):
        if self._is_active(path):
            raise HTTPError(409, "Use Docloop Versions to restore the active notebook")
        return super().restore_checkpoint(checkpoint_id, path)


class Kernels(MappingKernelManager):
    def cwd_for_path(self, path, **kwargs):
        return os.environ["DOCLOOP_NATIVE_WORKSPACE"]


def main():
    from jupyterlab.labapp import LabApp

    server = LabApp.initialize_server(
        argv=[
            "--no-browser",
            '--ServerApp.tornado_settings={"compress_response":True}',
            "--LabApp.expose_app_in_browser=True",
            "--LabApp.custom_css=True",
            "--ServerApp.ip=127.0.0.1",
            "--ServerApp.port_retries=0",
            "--ServerApp.port=" + os.environ["DOCLOOP_NATIVE_PORT"],
            "--ServerApp.base_url=" + os.environ.get("DOCLOOP_NATIVE_BASE_URL", "/jupyter/"),
            "--ServerApp.allow_root=True",
            "--ServerApp.root_dir=" + str(Path(os.environ["DOCLOOP_NATIVE_DOCUMENT"]).parent),
            "--ServerApp.contents_manager_class=docloop.jupyter_server.Contents",
            "--ServerApp.kernel_manager_class=docloop.jupyter_server.Kernels",
            "--ServerApp.disable_check_xsrf=True",
            "--ServerApp.allow_remote_access=True",
            "--ServerApp.terminals_enabled=False",
        ],
    )

    # The outer host authenticates browsers; only the internal proxy needs this token.
    def browser_config(_handler, config):
        if os.environ.get("DOCLOOP_PYTHON_SOCKET"):
            # This kernel does not implement debugger source mapping. Jupyter's
            # debugger handlers otherwise request modules after every execution.
            config = {
                **config,
                "disabledExtensions": [
                    *config.get("disabledExtensions", []),
                    "@jupyterlab/debugger-extension",
                ],
            }
        return {**config, "token": ""}

    server.web_app.settings["page_config_hook"] = browser_config
    server.start()


if __name__ == "__main__":
    main()
