"""JupyterLab HTTP and kernel channels inside an authenticated Docloop harness."""

from __future__ import annotations

import asyncio
import contextlib
import os
import re
import threading
from types import SimpleNamespace
from urllib.parse import urlsplit

import httpx
from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, StreamingResponse
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed, InvalidHandshake

from .native import NativeJupyter, native_cache_control

MAX_BODY = 32_000_000
METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE"]
REQUEST_HEADERS = {
    "accept",
    "accept-encoding",
    "content-type",
    "if-none-match",
    "if-modified-since",
}
RESPONSE_HEADERS = {
    "content-type",
    "content-length",
    "content-encoding",
    "content-disposition",
    "etag",
    "last-modified",
    "vary",
}


def same_origin(connection):
    """Protect cookie-authenticated browser writes at every HTTP/WS boundary."""
    origin = connection.headers.get("origin")
    if origin is None:
        # Browser writes/WS send Origin. Bearer-authenticated SDK clients may omit it.
        if connection.headers.get("authorization", "").lower().startswith("bearer "):
            return
        raise HTTPException(403, "Jupyter requires a same-origin request")
    expected = str(connection.url).split("/", 3)[:3]
    scheme = {"ws:": "http:", "wss:": "https:"}.get(expected[0], expected[0])
    if origin != scheme + "//" + expected[2]:
        raise HTTPException(403, "Jupyter requires a same-origin request")


async def bounded_body(request: Request):
    if request.headers.get("content-encoding", "identity").lower() != "identity":
        raise HTTPException(415, "Compressed Jupyter requests are not supported")
    parts, size = [], 0
    async for part in request.stream():
        size += len(part)
        if size > MAX_BODY:
            raise HTTPException(413, "Jupyter request exceeds the size limit")
        parts.append(part)
    return b"".join(parts)


async def shuttle(browser: WebSocket, upstream):
    async def to_kernel():
        while True:
            event = await browser.receive()
            if event["type"] == "websocket.disconnect":
                return
            data = event.get("bytes") if event.get("bytes") is not None else event.get("text")
            if data is not None:
                size = len(data.encode()) if isinstance(data, str) else len(data)
                if size > MAX_BODY:
                    await browser.close(1009, "Kernel message exceeds the size limit")
                    return
                await upstream.send(data)

    async def to_browser():
        async for data in upstream:
            if isinstance(data, bytes):
                await browser.send_bytes(data)
            else:
                await browser.send_text(data)

    tasks = {asyncio.create_task(to_kernel()), asyncio.create_task(to_browser())}
    try:
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            with contextlib.suppress(ConnectionClosed, WebSocketDisconnect):
                task.result()
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


class RunnerJupyter:
    """One on-demand Jupyter process for the already-bound document and workspace."""

    def __init__(self, notebook):
        self.notebook = notebook
        self.environment_kind = os.environ.get("DOCLOOP_ENVIRONMENT")
        self._native = None
        self._closed = False
        self._lock = threading.Lock()

    def native(self, binding):
        with self._lock:
            if self._closed:
                raise HTTPException(503, "Jupyter is shutting down")
            if self._native is None:
                app = SimpleNamespace(store=binding.store, executor=None, _closed=False)
                self._native = NativeJupyter(
                    app, base_url=f"/v1/sessions/{binding.session_id}/docloop/jupyter/"
                )
                # The selected local workspace can differ from the notebook directory.
                app.executor = SimpleNamespace(environment=None)
                app.workspace = self.notebook.workspace
                if self.environment_kind:
                    app.executor.environment = SimpleNamespace(
                        workspace=self.notebook.workspace,
                        descriptor=lambda: {"kind": self.environment_kind},
                    )
            elif self._native.app.store is not binding.store:
                raise HTTPException(503, "Jupyter document binding changed")
            return self._native

    def close(self):
        with self._lock:
            self._closed = True
            if self._native is not None:
                self._native.app._closed = True
                self._native.close()

    def router(self):
        router = APIRouter(prefix="/v1/sessions/{session_id}/docloop")

        @router.get("/jupyter")
        async def describe(request: Request, session_id: str):
            binding = await self.notebook.resolve(request, session_id, "read")
            native = self.native(binding)
            return JSONResponse(
                native.descriptor() or {"error": "This document is not ipynb"},
                headers={"Cache-Control": "no-store"},
            )

        @router.api_route("/jupyter/{path:path}", methods=METHODS)
        async def proxy(request: Request, session_id: str, path: str):
            binding = await self.notebook.resolve(request, session_id, "read")
            if request.method not in {"GET", "HEAD"}:
                same_origin(request)
            native = self.native(binding)
            if (
                path.startswith("/")
                or "\\" in path
                or any(p in {".", ".."} for p in path.split("/"))
            ):
                raise HTTPException(400, "Invalid Jupyter path")
            body = await bounded_body(request)
            target = native.base_url + path
            if request.url.query:
                target += "?" + request.url.query
            try:
                await asyncio.to_thread(native.ensure_http, request.method, target)
            except (OSError, ValueError) as exc:
                raise HTTPException(
                    503, "Jupyter could not start; inspect its private runtime log"
                ) from exc
            base = f"http://127.0.0.1:{native.port}"
            headers = {k: v for k, v in request.headers.items() if k.lower() in REQUEST_HEADERS}
            headers.update({"Authorization": "token " + native.token, "Origin": base})
            client = httpx.AsyncClient(base_url=base, follow_redirects=False, timeout=45)
            try:
                response = await client.send(
                    client.build_request(request.method, target, headers=headers, content=body),
                    stream=True,
                )
            except httpx.HTTPError as exc:
                await client.aclose()
                raise HTTPException(502, "Jupyter connection failed") from exc
            output_headers = {
                k: v for k, v in response.headers.items() if k.lower() in RESPONSE_HEADERS
            }
            location = response.headers.get("location")
            if location:
                parsed = urlsplit(location)
                if (
                    parsed.netloc and parsed.netloc != urlsplit(base).netloc
                ) or not parsed.path.startswith(native.base_url):
                    await response.aclose()
                    await client.aclose()
                    raise HTTPException(502, "Unexpected Jupyter redirect")
                output_headers["Location"] = parsed.path + (
                    "?" + parsed.query if parsed.query else ""
                )
            output_headers["Cache-Control"] = native_cache_control(
                request.method,
                target,
                response.status_code,
                response.headers.get("cache-control", ""),
                native.base_url,
            )
            output_headers["Content-Security-Policy"] = "frame-ancestors 'self'"

            async def content():
                size = 0
                try:
                    async for chunk in response.aiter_raw():
                        size += len(chunk)
                        if size > MAX_BODY:
                            raise ValueError("Jupyter response exceeds the size limit")
                        yield chunk
                finally:
                    await response.aclose()
                    await client.aclose()

            return StreamingResponse(
                content(), status_code=response.status_code, headers=output_headers
            )

        @router.websocket("/jupyter/api/kernels/{kernel_id}/channels")
        async def channels(websocket: WebSocket, session_id: str, kernel_id: str):
            try:
                binding = await self.notebook.resolve(websocket, session_id, "read")
                same_origin(websocket)
                if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", kernel_id):
                    raise HTTPException(400, "Invalid kernel identity")
                native = self.native(binding)
                await asyncio.to_thread(native.ensure)
                target = (
                    f"ws://127.0.0.1:{native.port}"
                    + native.base_url
                    + f"api/kernels/{kernel_id}/channels"
                )
                if websocket.url.query:
                    target += "?" + websocket.url.query
                async with connect(
                    target,
                    additional_headers={"Authorization": "token " + native.token},
                    origin=f"http://127.0.0.1:{native.port}",
                    max_size=MAX_BODY,
                    open_timeout=15,
                    close_timeout=3,
                ) as upstream:
                    # Empty protocol selects Jupyter's standard channel framing at both ends.
                    await websocket.accept()
                    await shuttle(websocket, upstream)
            except HTTPException as exc:
                with contextlib.suppress(RuntimeError, WebSocketDisconnect):
                    await websocket.close(
                        4400 + exc.status_code % 100, "Jupyter access unavailable"
                    )
            except (
                OSError,
                ValueError,
                RuntimeError,
                TimeoutError,
                ConnectionClosed,
                InvalidHandshake,
                WebSocketDisconnect,
            ):
                with contextlib.suppress(RuntimeError, WebSocketDisconnect):
                    await websocket.close(1011, "Jupyter channel unavailable")
            finally:
                with contextlib.suppress(RuntimeError, WebSocketDisconnect):
                    await websocket.close(1000)

        return router
