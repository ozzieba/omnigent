"""The document is the agent's memory."""
