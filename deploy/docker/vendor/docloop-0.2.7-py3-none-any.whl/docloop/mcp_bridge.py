"""One cell, one fresh MCP session. Config is supplied on stdin, never in argv."""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from contextlib import AsyncExitStack

# OCI helpers are mounted as a flat read-only directory, without an installed package.
if __package__:
    from .tool_catalog import discover, validate_discovery
else:
    from tool_catalog import discover, validate_discovery


async def evaluate(request, servers):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    operation = request.get("op", "call")
    if operation in {"list", "describe"}:
        validate_discovery(request)
    server = servers[request["server"]]
    async with AsyncExitStack() as stack:
        if "command" in server:
            transport = await stack.enter_async_context(
                stdio_client(
                    StdioServerParameters(
                        command=server["command"],
                        args=server.get("args", []),
                        env=server.get("env"),
                    )
                )
            )
        else:
            # MCP SDK v1 transport API (dependency is pinned below v2).
            from mcp.client.streamable_http import streamablehttp_client

            headers = dict(server.get("headers", {}))
            if "headers_command" in server:
                command = server["headers_command"]
                if (
                    not isinstance(command, list)
                    or not command
                    or not all(isinstance(arg, str) for arg in command)
                ):
                    raise ValueError("headers_command must be an argv list")
                # Allow the credential helper's bounded 30-second refresh to
                # finish and persist a rotating grant before this outer timeout.
                result = subprocess.run(command, check=True, capture_output=True, timeout=45)
                resolved = json.loads(result.stdout)
                if not isinstance(resolved, dict) or not all(
                    isinstance(k, str) and isinstance(v, str) for k, v in resolved.items()
                ):
                    raise ValueError("Header helper must return a JSON object of strings")
                headers.update(resolved)
            transport = await stack.enter_async_context(
                streamablehttp_client(server["url"], headers=headers)
            )
        session = await stack.enter_async_context(ClientSession(transport[0], transport[1]))
        await session.initialize()
        if operation in {"list", "describe"}:
            tools, cursors, cursor = [], set(), None
            for _ in range(100):
                page = await session.list_tools(cursor=cursor)
                tools.extend(
                    {
                        "name": tool.name,
                        "description": tool.description or "",
                        "parameters": tool.inputSchema,
                    }
                    for tool in page.tools
                )
                cursor = page.nextCursor
                if len(tools) > 10000 or (cursor is not None and cursor in cursors):
                    raise ValueError("MCP catalog exceeds discovery bounds or repeats a cursor")
                if cursor is None:
                    return discover(tools, request)
                cursors.add(cursor)
            raise ValueError("MCP catalog exceeds the discovery page limit")
        elif operation == "call":
            result = await session.call_tool(request["tool"], request.get("arguments", {}))
        elif operation == "read":
            result = await session.read_resource(request["uri"])
        else:
            raise ValueError("MCP op must be list, describe, call, or read")
        return result.model_dump(mode="json", by_alias=True)


if __name__ == "__main__":
    config = json.load(sys.stdin)
    try:
        print(
            json.dumps(
                asyncio.run(evaluate(config["request"], config["servers"])),
                ensure_ascii=False,
                indent=2,
            )
        )
    except Exception as exc:
        # Credentials stay configuration. Avoid dumping a transport exception containing headers.
        print(
            f"MCP evaluation failed ({type(exc).__name__}); check server configuration",
            file=sys.stderr,
        )
        raise SystemExit(1)
