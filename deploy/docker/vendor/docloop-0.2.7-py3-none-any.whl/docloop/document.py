from __future__ import annotations

import copy
import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from typing import Any


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def pretty(value: Any) -> str:
    """Human-readable JSON; canonical serialization remains the hashing format."""
    return json.dumps(value, ensure_ascii=False, indent=2)


def pretty_text(value: str) -> str:
    try:
        parsed = json.loads(value)
    except (ValueError, RecursionError):
        return value
    return pretty(parsed) if isinstance(parsed, (dict, list)) else value


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


@dataclass
class Node:
    id: str
    kind: str
    source: str
    language: str = "python"
    level: int = 1
    outputs: list[dict] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)
    # Parser trivia is derived from the document, never independent agent memory.
    original: str | None = field(default=None, repr=False)
    original_digest: str | None = field(default=None, repr=False)

    def validate(self):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", self.id):
            raise ValueError("IDs must contain 1–64 letters, digits, underscores or hyphens")
        if self.kind not in {"section", "markdown", "item", "code", "raw"}:
            raise ValueError(f"Unsupported node kind: {self.kind}")
        if not isinstance(self.source, str):
            raise ValueError("Node source must be text")
        if self.kind in {"section", "item"} and ("\n" in self.source or "\r" in self.source):
            raise ValueError("Section titles and individual list items must be single-line")
        if not isinstance(self.level, int) or not 1 <= self.level <= 100:
            raise ValueError("Section level must be 1–100")
        if not re.fullmatch(r"[A-Za-z0-9_+.-]+", self.language):
            raise ValueError("Invalid language")

    def value(self) -> dict:
        result = asdict(self)
        result.pop("original")
        result.pop("original_digest")
        return result

    def fingerprint(self) -> str:
        return digest(canonical(self.value()))


@dataclass
class Document:
    nodes: list[Node] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

    def validate(self):
        ids = set()
        for node in self.nodes:
            node.validate()
            if node.id in ids:
                raise ValueError(f"Duplicate node ID: {node.id}")
            ids.add(node.id)

    def get(self, address: str) -> Node:
        for node in self.nodes:
            if node.id == address:
                return node
        raise ValueError(f"No node at address {address!r}")

    def subtree(self, address: str) -> list[Node]:
        node = self.get(address)
        start = self.nodes.index(node)
        end = start + 1
        if node.kind == "section":
            while end < len(self.nodes):
                next_node = self.nodes[end]
                if next_node.kind == "section" and next_node.level <= node.level:
                    break
                end += 1
        return self.nodes[start:end]

    def insert(self, node: Node, after: str | None = None):
        node.validate()
        if any(n.id == node.id for n in self.nodes):
            raise ValueError(f"Duplicate node ID: {node.id}")
        index = len(self.nodes) if after is None else self.nodes.index(self.get(after)) + 1
        self.nodes.insert(index, node)

    def update(self, address: str, **changes):
        if set(changes) - {"source", "language", "level", "metadata"}:
            raise ValueError("Editable fields: source, language, level, metadata")
        node = self.get(address)
        candidate = copy.deepcopy(node)
        for key, value in changes.items():
            setattr(candidate, key, value)
        candidate.validate()
        if candidate.source != node.source or candidate.language != node.language:
            candidate.outputs = []
            candidate.extra.pop("execution_count", None)
            candidate.metadata.pop("docloop_execution", None)
        self.nodes[self.nodes.index(node)] = candidate

    def delete(self, address: str):
        removed = {n.id for n in self.subtree(address)}
        self.nodes[:] = [n for n in self.nodes if n.id not in removed]

    def move(self, address: str, after: str):
        moving = self.subtree(address)
        target = self.get(after)
        if target in moving:
            raise ValueError("Cannot move a subtree inside itself")
        if moving[0].kind == "section" and target.kind == "section":
            target = self.subtree(after)[-1]
        remaining = [n for n in self.nodes if n not in moving]
        index = remaining.index(target) + 1
        self.nodes[:] = remaining[:index] + moving + remaining[index:]
