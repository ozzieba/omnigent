"""Safe storage outcomes shared by native, hosted and standalone HTTP views."""

from .store import HistoryFailure


def storage_error(error):
    result = error.as_dict() if hasattr(error, "as_dict") else dict(error)
    if result.get("installed") is True:
        message = "The document was updated, but saving did not finish."
    elif result.get("installed") is False:
        message = "The document change was not installed. Saving failed."
    else:
        message = "Saving or reading history failed; inspect the current document."
    message += f" History: {result.get('history', 'unknown')}. Durability: {result.get('durability', 'unknown')}."
    message += f" History durability: {result.get('history_durability', 'unknown')}."
    message += " The action was not retried. Repair history without repeating the action."
    return {**result, "error": message}


def history_state(store):
    try:
        return store.history_status()
    except HistoryFailure as error:
        return {"status": "unavailable", **storage_error(error)}
