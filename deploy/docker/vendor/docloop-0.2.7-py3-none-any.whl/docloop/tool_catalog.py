"""Stateless, selective views of the currently advertised tool contracts."""

from __future__ import annotations

from collections import Counter

if __package__:
    from .document import canonical, digest
else:
    from document import canonical, digest

DISCOVERY_HELP = (
    'Evaluate an mcp cell with {"server":"SERVER","op":"list"} for folders; '
    'add "folder":"NAME" or "filter":"TEXT" for matching tool names. '
    'Use "view":"names" for all names, offset/limit to page (limit 1..50), '
    'and {"server":"SERVER","op":"describe","tool":"NAME"} for one full schema. '
    "Pass the returned catalog hash to detect changes while paging. "
    "Reuse one discovery cell: update and eval replaces its old output. "
    'Call with {"server":"SERVER","op":"call","tool":"NAME","arguments":{}}. '
    "Discovery changes context, not permissions. Inspect unknown outcomes before retrying calls."
)


def folder_for(name: str) -> str:
    parts = name.split("__")
    if len(parts) >= 3 and parts[0] == "mcp":
        return "mcp/" + parts[1]
    for separator in ("__", ".", "/", "_"):
        if separator in name:
            return (
                name.rsplit(separator, 1)[0]
                if separator in (".", "/")
                else name.split(separator, 1)[0]
            )
    return "general"


def validate_discovery(request: dict) -> None:
    op = request.get("op")
    fields = {"server", "op", "catalog"}
    if op == "describe":
        fields.add("tool")
        if not isinstance(request.get("tool"), str) or not request["tool"]:
            raise ValueError("describe requires a tool name")
    elif op == "list":
        fields.update({"folder", "filter", "view", "offset", "limit"})
        for field in ("folder", "filter"):
            if field in request and (
                not isinstance(request[field], str) or len(request[field]) > 512
            ):
                raise ValueError(f"{field} must be text of at most 512 characters")
        if request.get("view", "folders") not in {"folders", "names"}:
            raise ValueError("list view must be folders or names")
        if type(request.get("offset", 0)) is not int or request.get("offset", 0) < 0:
            raise ValueError("offset must be a nonnegative integer")
        if type(request.get("limit", 20)) is not int or not 1 <= request.get("limit", 20) <= 50:
            raise ValueError("limit must be an integer from 1 to 50")
    else:
        raise ValueError("Discovery op must be list or describe")
    if set(request) - fields:
        raise ValueError("Unknown discovery fields")
    if "catalog" in request and not isinstance(request["catalog"], str):
        raise ValueError("catalog must be the returned hash")


def discover(tools: list[dict], request: dict) -> dict:
    validate_discovery(request)
    ordered = sorted(tools, key=lambda tool: tool["name"])
    catalog = digest(canonical(ordered))
    if "catalog" in request and request["catalog"] != catalog:
        raise ValueError("Tool catalog changed; list again before continuing this view")
    if request["op"] == "describe":
        tool = next((tool for tool in ordered if tool["name"] == request["tool"]), None)
        if tool is None:
            raise ValueError("Tool is absent from the current inventory")
        return {"tool": tool, "catalog": catalog}
    folder, query = request.get("folder"), request.get("filter", "").casefold()
    matching = [
        tool
        for tool in ordered
        if (folder is None or folder_for(tool["name"]) == folder)
        and (not query or query in (tool["name"] + "\n" + tool.get("description", "")).casefold())
    ]
    view = request.get("view", "names" if folder is not None or query else "folders")
    if view == "folders":
        counts = Counter(folder_for(tool["name"]) for tool in matching)
        items = [{"name": name, "count": counts[name]} for name in sorted(counts)]
    else:
        items = [tool["name"] for tool in matching]
    offset, limit = request.get("offset", 0), request.get("limit", 20)
    end = min(offset + limit, len(items))
    return {
        view: items[offset:end],
        "total": len(items),
        "total_tools": len(matching),
        "next_offset": end if end < len(items) else None,
        "catalog": catalog,
    }
