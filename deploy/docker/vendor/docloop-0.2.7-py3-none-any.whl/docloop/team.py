"""Document-resident delegation and durable at-least-once mail.

Threads/events are execution handles only. Tasks, snapshots, lifecycle, mailbox and
results are readable nodes. No parent transcript or implicit memory is inherited.
"""

from __future__ import annotations

import copy
import json
import os
import shutil
import threading
import time
import uuid
from pathlib import Path

from .document import Node, canonical
from .execution import _process_identity
from .store import Conflict, Store

_HANDLES = {}
_INITIALIZING = set()
_HANDLE_LOCK = threading.Lock()
_OWNERS = {}
_CLOSING = set()
_CLOSE_CALLS = set()
STATE_ID = "docloop-team-state"


class Team:
    def __init__(
        self, store, runner=None, max_children=3, workspace=None, max_depth=2, *, model=None
    ):
        self.store, self.runner, self.max_children = store, runner, max_children
        self.workspace = Path(workspace or store.path.parent).resolve()
        self.max_depth = max_depth
        self.model = model
        self._closed = False

    def _check_open(self):
        path, seen = str(self.store.path), set()
        while path not in seen:
            if path in _CLOSING:
                active = path in _CLOSE_CALLS
                for candidate in set(_HANDLES) | _INITIALIZING:
                    chain = set()
                    while candidate not in chain:
                        if candidate == path:
                            active = True
                            break
                        chain.add(candidate)
                        if candidate not in _OWNERS:
                            break
                        candidate = _OWNERS[candidate]
                if not active:
                    _CLOSING.discard(path)
            if self._closed or path in _CLOSING:
                raise RuntimeError("Team is shutting down")
            seen.add(path)
            if path not in _OWNERS:
                break
            path = _OWNERS[path]

    def close(self, timeout=10):
        """Cancel and join this runtime's descendants; unrelated teams stay live."""
        root = str(self.store.path)
        deadline = time.monotonic() + max(0, timeout)
        with _HANDLE_LOCK:
            self._closed = True
            _CLOSING.add(root)
            _CLOSE_CALLS.add(root)
            owned = {root}
            while True:
                expanded = owned | {child for child, parent in _OWNERS.items() if parent in owned}
                if expanded == owned:
                    break
                owned = expanded
            handles = {
                key: value for key, value in _HANDLES.items() if key in owned and key != root
            }
            owners = {key: _OWNERS[key] for key in handles}
            for _, cancel in handles.values():
                cancel.set()
        try:
            for key in handles:
                parent = Team(Store(owners[key]))

                def cancelling(state, doc, key=key):
                    for entry in state["children"].values():
                        if entry["path"] == key and entry["status"] in {
                            "starting",
                            "running",
                            "cancelling",
                        }:
                            entry["status"] = "cancelling"

                parent._change(cancelling, "Runtime shutdown: cancel child")
            for thread, _ in handles.values():
                if thread is not threading.current_thread():
                    thread.join(max(0, deadline - time.monotonic()))
            while time.monotonic() < deadline:
                with _HANDLE_LOCK:
                    initializing = owned & _INITIALIZING
                if not initializing:
                    break
                time.sleep(0.02)
            active = [key for key, (thread, _) in handles.items() if thread.is_alive()]
            with _HANDLE_LOCK:
                active.extend(sorted(owned & _INITIALIZING))
            return {
                "cancelled": sum(not thread.is_alive() for thread, _ in handles.values()),
                "active": active,
            }
        finally:
            with _HANDLE_LOCK:
                _CLOSE_CALLS.discard(root)
                if not any(key in _HANDLES or key in _INITIALIZING for key in owned - {root}):
                    _CLOSING.discard(root)
                    for key in owned - {root}:
                        _OWNERS.pop(key, None)

    @staticmethod
    def _state(doc):
        try:
            node = doc.get(STATE_ID)
        except ValueError:
            return {"children": {}, "mail": []}
        state = json.loads(node.source)
        if (
            not isinstance(state, dict)
            or not isinstance(state.get("children"), dict)
            or not isinstance(state.get("mail"), list)
        ):
            raise ValueError("Malformed team registry; repair the document before continuing")
        return state

    @staticmethod
    def _write_state(doc, state):
        source = canonical(state)
        try:
            doc.update(STATE_ID, source=source)
        except ValueError:
            doc.insert(Node(STATE_ID, "raw", source, language="json"))

    def _change(self, fn, message, store=None):
        store = store or self.store
        for _ in range(20):
            doc, rev = store.read()
            state = self._state(doc)
            result = fn(state, doc)
            self._write_state(doc, state)
            try:
                store.save(doc, rev, message)
                return result
            except Conflict:
                continue
        raise Conflict("Mailbox busy; retry operation")

    def _child(self, ident):
        doc, _ = self.store.read()
        entry = self._state(doc)["children"][ident]
        return Store(entry["path"])

    def dispatch(self, request):
        op = request.get("op")
        if op == "spawn":
            return self.spawn(
                request["task"],
                request.get("shared", []),
                request.get("id"),
                request.get("workspace_mode", "copy"),
            )
        if op == "send":
            return self.send(request.get("to", "self"), request["body"], request.get("id"))
        if op == "receive":
            doc, _ = self.store.read()
            return {"messages": [m for m in self._state(doc)["mail"] if not m["acked"]]}
        if op == "ack":

            def ack(state, doc):
                matches = [m for m in state["mail"] if m["id"] == request["id"]]
                if not matches:
                    raise ValueError("Unknown message ID")
                matches[0]["acked"] = True
                return matches[0]

            return self._change(ack, "Acknowledge mail")
        if op == "status":
            return self.status()
        if op == "cancel":
            return self.cancel(request["id"])
        if op == "resume":
            return self.resume(request["id"])
        if op == "collect":
            child = self._child(request["id"])
            child_doc, revision = child.read()
            nodes = [n.value() for n in child_doc.nodes if n.id != STATE_ID]
            result = {"child": request["id"], "revision": revision, "nodes": nodes}

            def collect(state, doc):
                entry = state["children"][request["id"]]
                entry["result"] = result
                return result

            return self._change(collect, "Collect child document")
        raise ValueError("Team op must be spawn/send/receive/ack/status/cancel/resume/collect")

    def spawn(self, task, shared=(), ident=None, workspace_mode="copy"):
        if self.runner is None:
            raise ValueError("A configured child runner is required")
        if workspace_mode not in {"copy", "shared"}:
            raise ValueError("workspace_mode must be copy or shared")
        ident = ident or "child-" + uuid.uuid4().hex[:12]
        Node(ident, "markdown", task).validate()
        child_dir = self.store.path.parent / ("." + self.store.path.name + ".children")
        child_path = child_dir / (ident + self.store.path.suffix)

        def reserve(state, doc):
            if state.get("depth", 0) >= self.max_depth:
                raise ValueError("Child nesting depth limit reached")
            if ident in state["children"]:
                raise ValueError("Child ID already exists")
            active = [
                v
                for v in state["children"].values()
                if v["status"] in {"starting", "running", "cancelling"}
            ]
            if len(active) >= self.max_children:
                raise ValueError("Concurrent child limit reached")
            # Explicit immutable snapshots only, with provenance carried in each node.
            snapshots = []
            for address in dict.fromkeys(shared):
                n = copy.deepcopy(doc.get(address))
                if n.id in {STATE_ID, "docloop-environment"}:
                    raise ValueError("Share selected task nodes, not the team registry")
                n.metadata["docloop_shared"] = {
                    "parent": str(self.store.path),
                    "address": n.id,
                    "fingerprint": n.fingerprint(),
                }
                snapshots.append(n)
            state["children"][ident] = {
                "path": str(child_path),
                "task": task,
                "shared": list(shared),
                "status": "starting",
                "owner_pid": os.getpid(),
                "owner_identity": _process_identity(os.getpid()),
                "depth": state.get("depth", 0) + 1,
            }
            return snapshots

        with _HANDLE_LOCK:
            self._check_open()
            snapshots = self._change(reserve, f"Spawn {ident}")
            _INITIALIZING.add(str(child_path))
            _OWNERS[str(child_path)] = str(self.store.path)
        try:
            child_workspace = self.workspace
            if workspace_mode == "copy":
                child_workspace = child_dir / (ident + "-workspace")

                def ignore(directory, names):
                    return [
                        n
                        for n in names
                        if n in {".git", ".venv", "__pycache__", "node_modules"}
                        or n.endswith((".children", ".history"))
                    ]

                shutil.copytree(self.workspace, child_workspace, ignore=ignore, symlinks=True)
            child = Store(child_path)
            doc, rev = child.read()
            if doc.nodes:
                self._set_status(ident, "error", "Child path already contains a document")
                raise ValueError("Child document already exists")
            task_id = "task-" + uuid.uuid4().hex[:12]
            doc.insert(Node(task_id, "markdown", task, metadata={"docloop_role": "instructions"}))
            doc.insert(
                Node(
                    "docloop-environment",
                    "raw",
                    canonical(
                        {
                            "kind": "local",
                            "workspace": str(child_workspace),
                            "workspace_mode": workspace_mode,
                        }
                    ),
                    language="json",
                )
            )
            for snapshot in snapshots:
                doc.insert(snapshot)
            self._write_state(
                doc,
                {
                    "parent": str(self.store.path),
                    "identity": ident,
                    "children": {},
                    "mail": [],
                    "depth": self._state(self.store.read()[0])["children"][ident]["depth"],
                },
            )
            # Freeze the parent choice in the same durable commit as the child task,
            # before a worker can start or a process crash can leave it resumable.
            if self.model is not None:
                doc.metadata["docloop_child_model"] = self.model
            child.save(doc, rev, "Initialize child task and explicit shared snapshots")
            return self._start(ident, child)
        except Exception as exc:
            self._set_status(
                ident,
                "cancelled" if str(exc) == "Team is shutting down" else "error",
                f"Initialization failed: {type(exc).__name__}: {exc}",
            )
            raise
        finally:
            with _HANDLE_LOCK:
                _INITIALIZING.discard(str(child_path))

    def resume(self, ident):
        if self.runner is None:
            raise ValueError("A configured child runner is required")
        child = self._child(ident)
        if not child.path.exists():
            raise ValueError("Child document is missing; cannot resume")
        # Validate initialization before accepting a resume of a failed spawn.
        child.read()[0].get("docloop-environment")

        def reserve(state, doc):
            entry = state["children"][ident]
            if entry["status"] not in {"paused", "interrupted", "error", "cancelled"}:
                raise ValueError("Only paused, interrupted, error or cancelled children can resume")
            active = sum(
                v["status"] in {"starting", "running", "cancelling"}
                for v in state["children"].values()
            )
            if active >= self.max_children:
                raise ValueError("Concurrent child limit reached")
            entry.update(
                status="starting",
                owner_pid=os.getpid(),
                owner_identity=_process_identity(os.getpid()),
            )
            entry.pop("error", None)
            entry.pop("run_result", None)

        with _HANDLE_LOCK:
            self._check_open()
            self._change(reserve, f"Resume {ident}")
            _INITIALIZING.add(str(child.path))
            _OWNERS[str(child.path)] = str(self.store.path)
        try:
            return self._start(ident, child)
        except Exception as exc:
            self._set_status(ident, "error", f"Resume failed: {type(exc).__name__}: {exc}")
            raise
        finally:
            with _HANDLE_LOCK:
                _INITIALIZING.discard(str(child.path))

    def _start(self, ident, child):
        child_path = child.path
        cancel = threading.Event()
        key = str(child_path)

        def work():
            done = threading.Event()

            def watch():
                while not done.wait(0.1):
                    current, _ = self.store.read()
                    if self._state(current)["children"][ident]["status"] == "cancelling":
                        cancel.set()

            watcher = threading.Thread(target=watch, daemon=True)
            watcher.start()
            result = None
            status = "error"
            error = None
            try:
                self._set_status(ident, "running")
                result = self.runner(child, cancel)
                result = (
                    result
                    if isinstance(result, dict)
                    else {
                        "done": False,
                        "reason": "Runner returned without an explicit completion result",
                    }
                )
                if cancel.is_set() or result.get("cancelled"):
                    status = "cancelled"
                elif result.get("retryable"):
                    status = "paused"
                elif result.get("error"):
                    status = "error"
                elif result.get("done") is True:
                    status = "complete"
                else:
                    status = "paused"
                error = result.get("error")
            except Exception as exc:
                result = None
                status = "error"
                error = f"{type(exc).__name__}: {exc}"
            finally:
                done.set()
                watcher.join(timeout=1)
                with _HANDLE_LOCK:
                    # A resumable status must not become visible to resume() while
                    # the previous worker still owns its execution handle.
                    try:
                        self._set_status(ident, status, error, result=result)
                    finally:
                        handle = _HANDLES.get(key)
                        if handle and handle[0] is threading.current_thread():
                            _HANDLES.pop(key, None)

        thread = threading.Thread(target=work, daemon=True, name=ident)
        with _HANDLE_LOCK:
            self._check_open()
            _HANDLES[key] = (thread, cancel)
            thread.start()
        return {"id": ident, "path": str(child_path), "status": "starting"}

    def _set_status(self, ident, status, error=None, result=None):
        def update(state, doc):
            entry = state["children"][ident]
            if entry["status"] == "cancelling" and status == "running":
                return
            entry["status"] = status
            if error:
                entry["error"] = error
            if result is not None:
                entry["run_result"] = result

        self._change(update, f"Child {ident}: {status}")

    def status(self):
        def refresh(state, doc):
            for ident, entry in state["children"].items():
                if entry["status"] not in {"starting", "running", "cancelling"}:
                    continue
                pid = entry.get("owner_pid")
                alive = False
                if pid == os.getpid():
                    with _HANDLE_LOCK:
                        handle = _HANDLES.get(entry["path"])
                        alive = entry["path"] in _INITIALIZING or bool(
                            handle and handle[0].is_alive()
                        )
                elif pid:
                    alive = bool(
                        entry.get("owner_identity")
                        and _process_identity(pid) == entry["owner_identity"]
                    )
                if not alive:
                    entry["status"] = "interrupted"
            return copy.deepcopy(state["children"])

        return {"children": self._change(refresh, "Refresh child lifecycle")}

    def cancel(self, ident):
        doc, _ = self.store.read()
        entry = self._state(doc)["children"][ident]
        if entry["status"] in {"complete", "cancelled", "error", "interrupted"}:
            return entry
        if entry["status"] == "paused":
            self._set_status(ident, "cancelled")
            return {"id": ident, "status": "cancelled"}
        self._set_status(ident, "cancelling")
        with _HANDLE_LOCK:
            handle = _HANDLES.get(entry["path"])
            if handle:
                handle[1].set()
        return {"id": ident, "status": "cancelling"}

    def send(self, target, body, message_id=None):
        doc, _ = self.store.read()
        own = self._state(doc)
        if target == "self":
            destination = self.store
        elif target == "parent":
            destination = Store(own["parent"])
        elif target in own["children"]:
            destination = self._child(target)
        elif "parent" in own:
            parent = Store(own["parent"])
            parent_doc, _ = parent.read()
            destination = Store(self._state(parent_doc)["children"][target]["path"])
        else:
            raise ValueError("Unknown mail destination")
        message = {
            "id": message_id or "mail-" + uuid.uuid4().hex,
            "from": own.get("identity", "parent"),
            "to": target,
            "body": body,
            "acked": False,
            "created_at": time.time(),
        }

        def deliver(state, doc):
            existing = next((m for m in state["mail"] if m["id"] == message["id"]), None)
            if existing:
                if existing["body"] != body or existing["from"] != message["from"]:
                    raise ValueError("Message ID reused with different content")
                return existing
            state["mail"].append(message)
            return message

        return self._change(deliver, "Deliver mail", destination)
