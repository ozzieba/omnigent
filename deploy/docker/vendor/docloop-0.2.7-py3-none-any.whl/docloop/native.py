"""Lifecycle and authenticated reverse proxy for the real JupyterLab UI."""

from __future__ import annotations

import copy
import hashlib
import http.client
import importlib.util
import json
import os
import queue
import re
import secrets
import select
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import quote, urlsplit


def _installed_lab_asset(target, base_url):
    """Recognize only installed, content-hashed Lab files, never notebook paths."""
    path = urlsplit(target).path
    match = re.fullmatch(re.escape(base_url) + r"static/lab/([A-Za-z0-9_.-]+)", path)
    if not match or not re.search(r"(?:^|\.)[0-9a-f]{8,64}\.", match[1]):
        return False
    spec = importlib.util.find_spec("jupyterlab")
    if not spec or not spec.origin:
        return False
    installed = Path(spec.origin).parent / "static" / match[1]
    return installed.is_file() and not installed.is_symlink()


def native_cache_control(method, target, status, upstream, base_url="/jupyter/"):
    """Only authenticated, installed, content-hashed Lab bundles may be cached."""
    if method not in {"GET", "HEAD"} or status not in {200, 203, 204, 206, 304}:
        return "no-store"
    if not _installed_lab_asset(target, base_url):
        return "no-store"
    directives = {part.strip().lower() for part in upstream.split(",")}
    if "immutable" not in directives or "no-store" in directives or "no-cache" in directives:
        return "no-store"
    maximum = next(
        (part.split("=", 1)[1].strip('"') for part in directives if part.startswith("max-age=")),
        "0",
    )
    if not maximum.isdigit() or int(maximum) <= 0:
        return "no-store"
    return f"private, max-age={min(int(maximum), 31536000)}, immutable"


class UpgradeResponse(http.client.HTTPResponse):
    """Do not read ahead into WebSocket frames while parsing upgrade headers."""

    def __init__(self, sock, *args, **kwargs):
        super().__init__(sock, *args, **kwargs)
        self.fp.close()
        self.fp = sock.makefile("rb", buffering=0)


class NativeJupyter:
    def __init__(self, app, *, base_url="/jupyter/"):
        if not re.fullmatch(r"/(?:[A-Za-z0-9_-]+/)+", base_url):
            raise ValueError("Jupyter requires an absolute, normalized path prefix")
        self.app = app
        self.base_url = base_url
        self.lock = threading.Lock()
        self.process = None
        self.directory = None
        self.log = None
        self.document = None
        self.static_environment = None
        self.static_signature = None
        self.token = secrets.token_urlsafe(40)
        self.port = None
        self.execution_lock = threading.Lock()
        self.python_objects = None

    def descriptor(self):
        if self.app.store.path.suffix != ".ipynb":
            return None
        environment = getattr(self.app.executor, "environment", None)
        descriptor = environment.descriptor() if environment is not None else {}
        if not descriptor:
            try:
                descriptor = json.loads(self.app.store.read()[0].get("docloop-environment").source)
            except (KeyError, ValueError):
                descriptor = {}
        if descriptor.get("kind", "local") != "local":
            return {"error": "Native Jupyter currently requires a local execution environment."}
        if importlib.util.find_spec("jupyterlab") is None:
            return {"error": "Install docloop[jupyter] to use native JupyterLab."}
        return {
            "url": self.base_url
            + "lab/tree/"
            + quote(self.app.store.path.name)
            + "?docloop="
            + hashlib.sha256(str(self.app.store.path).encode()).hexdigest()[:16]
        }

    def _document_signature(self):
        """A conservative static-reuse hint, never revision or auth authority."""
        try:
            info = self.app.store.path.stat()
        except OSError:
            return None
        if not stat.S_ISREG(info.st_mode):
            return None
        return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)

    def _reuse_static(self, method, target):
        """Reuse a healthy runtime without reading notebook execution configuration.

        Only immutable installed assets qualify. Explicit local configuration must
        match startup; notebook-derived local validation also requires unchanged
        file identity since its reads. This never starts or restarts a runtime.
        """
        if method not in {"GET", "HEAD"} or not _installed_lab_asset(target, self.base_url):
            return False
        with self.lock:
            if self.app._closed:
                raise ValueError("Application is shutting down")
            environment = getattr(self.app.executor, "environment", None)
            descriptor = environment.descriptor() if environment is not None else {}
            environment_matches = (
                descriptor.get("kind") == "local" and descriptor == self.static_environment
                if descriptor
                else not self.static_environment
                and self.static_signature is not None
                and self.static_signature == self._document_signature()
            )
            return bool(
                environment_matches
                and self.app.store.path.suffix == ".ipynb"
                and self.document == self.app.store.path
                and self.process
                and self.process.poll() is None
            )

    def ensure_http(self, method, target):
        """Validate HTTP requests, with narrow healthy-static runtime reuse."""
        if not self._reuse_static(method, target):
            self.ensure()

    def ensure(self):
        with self.lock:
            if self.app._closed:
                raise ValueError("Application is shutting down")
            previous_static_environment = self.static_environment
            self.static_environment = None
            self.static_signature = None
            environment = getattr(self.app.executor, "environment", None)
            explicit_environment = environment.descriptor() if environment is not None else {}
            before = self._document_signature()
            descriptor = self.descriptor()
            from .python_objects import enabled

            python_state = enabled(self.app.store.read()[0])
            after = self._document_signature()
            if python_state and importlib.util.find_spec("dill") is None:
                raise ValueError(
                    "Install docloop[python-state] to checkpoint Python namespaces"
                )
            current_environment = getattr(self.app.executor, "environment", None)
            still_derived = current_environment is None or not current_environment.descriptor()
            validated_signature = (
                before if before == after and not explicit_environment and still_derived else None
            )
            if self.app.store.path.suffix == ".org" and python_state:
                environment = getattr(self.app.executor, "environment", None)
                if environment is None or environment.descriptor().get("kind") != "local":
                    raise ValueError(
                        "Python state currently requires a local execution environment"
                    )
                descriptor = {"execution": "python-state"}
            if not descriptor or descriptor.get("error"):
                raise ValueError((descriptor or {}).get("error", "No Jupyter notebook is open"))
            if (
                self.process
                and self.document == self.app.store.path
                and self.process.poll() is None
            ):
                self.static_environment = previous_static_environment
                self.static_signature = validated_signature
                return
            self._close()
            self.document = self.app.store.path
            with socket.socket() as reserve:
                reserve.bind(("127.0.0.1", 0))
                self.port = reserve.getsockname()[1]
            self.directory = tempfile.TemporaryDirectory(prefix="docloop-jupyter-")
            notary_directory = self.app.store.history_dir / "jupyter-notary"
            notary_directory.mkdir(mode=0o700, exist_ok=True)
            notary_directory.chmod(0o700)
            config_directory = Path(self.directory.name) / "config"
            config_directory.mkdir()
            (config_directory / "jupyter_server_config.py").write_text(
                f"c.NotebookNotary.data_dir = {str(notary_directory)!r}\n"
            )
            # Jupyter's supported custom-CSS hook stays inside this private
            # runtime, including when Lab is embedded by a different host.
            custom_directory = config_directory / "custom"
            custom_directory.mkdir()
            (custom_directory / "custom.css").write_bytes(
                (Path(__file__).parent / "static" / "native-touch.css").read_bytes()
            )
            environment = getattr(self.app.executor, "environment", None)
            workspace = getattr(
                environment, "workspace", getattr(self.app, "workspace", self.document.parent)
            )
            env = {
                **os.environ,
                "JUPYTER_TOKEN": self.token,
                "JUPYTER_RUNTIME_DIR": self.directory.name,
                "JUPYTER_CONFIG_DIR": str(config_directory),
                "JUPYTER_DATA_DIR": str(Path(self.directory.name) / "data"),
                "JUPYTERLAB_SETTINGS_DIR": str(Path(self.directory.name) / "settings"),
                "JUPYTERLAB_WORKSPACES_DIR": str(Path(self.directory.name) / "layouts"),
                "DOCLOOP_NATIVE_DOCUMENT": str(self.document),
                "DOCLOOP_NATIVE_WORKSPACE": str(workspace),
                "DOCLOOP_NATIVE_PORT": str(self.port),
                "DOCLOOP_NATIVE_BASE_URL": self.base_url,
            }
            if python_state:
                from .python_rpc import PythonObjectsServer

                self.python_objects = PythonObjectsServer(self.app, self.directory.name)
                env["DOCLOOP_PYTHON_SOCKET"] = self.python_objects.path
                kernel = Path(env["JUPYTER_DATA_DIR"]) / "kernels" / "docloop-python"
                kernel.mkdir(parents=True)
                (kernel / "kernel.json").write_text(
                    json.dumps(
                        {
                            "argv": [
                                sys.executable,
                                "-m",
                                "docloop.python_kernel",
                                "-f",
                                "{connection_file}",
                            ],
                            "display_name": "Docloop Python",
                            "language": "python",
                        }
                    )
                )
            notification_settings = (
                Path(env["JUPYTERLAB_SETTINGS_DIR"])
                / "@jupyterlab"
                / "apputils-extension"
                / "notification.jupyterlab-settings"
            )
            notification_settings.parent.mkdir(parents=True, exist_ok=True)
            notification_settings.write_text(
                json.dumps({"fetchNews": "false", "checkForUpdates": False})
            )
            notebook_settings = (
                Path(env["JUPYTERLAB_SETTINGS_DIR"])
                / "@jupyterlab"
                / "notebook-extension"
                / "tracker.jupyterlab-settings"
            )
            notebook_settings.parent.mkdir(parents=True, exist_ok=True)
            notebook_settings.write_text(json.dumps({"codeCellConfig": {"lineWrap": True}}))
            self.log = open(Path(self.directory.name) / "server.log", "w+")
            self.process = subprocess.Popen(
                [sys.executable, "-m", "docloop.jupyter_server"],
                env=env,
                cwd=workspace,
                stdout=self.log,
                stderr=self.log,
            )
            deadline = time.monotonic() + 35
            while time.monotonic() < deadline:
                if self.process.poll() is not None:
                    raise ValueError(
                        "Native Jupyter failed to start; inspect the private runtime log"
                    )
                try:
                    conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=1)
                    conn.request(
                        "GET",
                        self.base_url + "api",
                        headers={"Authorization": "token " + self.token},
                    )
                    response = conn.getresponse()
                    response.read()
                    conn.close()
                    if response.status == 200:
                        self.static_signature = validated_signature
                        self.static_environment = (
                            copy.deepcopy(environment.descriptor())
                            if environment is not None
                            else None
                        )
                        return
                except OSError:
                    pass
                time.sleep(0.1)
            self._close()
            raise ValueError("Native Jupyter startup timed out")

    def _close(self):
        self.static_environment = None
        self.static_signature = None
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
            self.process = None
        if self.python_objects is not None:
            self.python_objects.close()
            self.python_objects = None
        if self.directory:
            log = getattr(self, "log", None)
            self.log = None
            directory, self.directory = self.directory, None
            try:
                if log is not None:
                    log.close()
            finally:
                directory.cleanup()

    def close(self):
        with self.lock:
            self._close()

    def _kernel_request(self, method, path, value=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=15)
        try:
            connection.request(
                method,
                self.base_url + "api/" + path,
                body=json.dumps(value) if value is not None else None,
                headers={
                    "Authorization": "token " + self.token,
                    "Content-Type": "application/json",
                },
            )
            response = connection.getresponse()
            raw = response.read(1_000_001)
            if response.status >= 400 or len(raw) > 1_000_000:
                raise ValueError("Jupyter kernel operation failed")
            return json.loads(raw) if raw else None
        finally:
            connection.close()

    @contextmanager
    def _python_execution(self, cancel_event):
        with self.execution_lock:
            self.ensure()
            bridge = self.python_objects
            bridge.cancel_event = cancel_event
            try:
                yield
            finally:
                # Later browser cells must not inherit an earlier agent cancellation.
                bridge.cancel_event = None

    def execute_python(self, source, *, timeout, max_output, cancel_event=None):
        from jupyter_client import BlockingKernelClient

        from .document import canonical
        from .python_checkpoint import CheckpointStore

        with self._python_execution(cancel_event):
            sessions = self._kernel_request("GET", "sessions")
            session = next((s for s in sessions if s.get("path") == self.document.name), None)
            if session is None:
                session = self._kernel_request(
                    "POST",
                    "sessions",
                    {
                        "path": self.document.name,
                        "name": self.document.name,
                        "type": "notebook" if self.document.suffix == ".ipynb" else "console",
                        "kernel": {"name": "docloop-python"},
                    },
                )
            if session["kernel"]["name"] != "docloop-python":
                raise ValueError("Select the Docloop Python kernel before using Python state")
            if session["kernel"]["execution_state"] == "busy":
                raise ValueError(
                    "Python kernel is busy; inspect its current execution before continuing"
                )
            kernel_id = session["kernel"]["id"]
            connection_file = Path(self.directory.name) / ("kernel-" + kernel_id + ".json")
            client = BlockingKernelClient(connection_file=str(connection_file))
            client.load_connection_file()
            client.start_channels()
            outputs, status, used = [], "ok", 0
            try:
                client.wait_for_ready(timeout=min(15, timeout))
                message_id = client.execute(
                    source, store_history=True, allow_stdin=False, stop_on_error=True
                )
                deadline = time.monotonic() + timeout
                while True:
                    if (cancel_event and cancel_event.is_set()) or time.monotonic() >= deadline:
                        self._kernel_request("POST", f"kernels/{kernel_id}/interrupt")
                        status = "unknown"
                        outputs.append(
                            {
                                "output_type": "error",
                                "ename": "Interrupted",
                                "evalue": "Python execution interrupted; inspect state before retrying",
                                "traceback": [],
                            }
                        )
                        break
                    try:
                        message = client.get_iopub_msg(timeout=0.1)
                    except queue.Empty:
                        continue
                    if message.get("parent_header", {}).get("msg_id") != message_id:
                        continue
                    kind, content = message["msg_type"], message["content"]
                    if kind == "status" and content["execution_state"] == "idle":
                        break
                    if kind == "stream":
                        output = {
                            "output_type": "stream",
                            "name": content["name"],
                            "text": content["text"],
                        }
                    elif kind in {"display_data", "execute_result"}:
                        output = {
                            "output_type": "display_data",
                            "data": content.get("data", {}),
                            "metadata": content.get("metadata", {}),
                        }
                    elif kind == "error":
                        status = "error"
                        output = {
                            "output_type": "error",
                            "ename": content["ename"],
                            "evalue": content["evalue"],
                            "traceback": content["traceback"],
                        }
                    elif kind == "clear_output":
                        outputs, used = [], 0
                        continue
                    else:
                        continue
                    used += len(canonical(output).encode())
                    if used > max_output:
                        self._kernel_request("POST", f"kernels/{kernel_id}/interrupt")
                        outputs.append(
                            {
                                "output_type": "error",
                                "ename": "OutputLimit",
                                "evalue": "Python output limit reached; execution outcome may be incomplete",
                                "traceback": [],
                            }
                        )
                        status = "unknown"
                        break
                    outputs.append(output)
            finally:
                client.stop_channels()
            return {
                "outputs": outputs,
                "status": status,
                "kernel_id": kernel_id,
                "checkpoint": CheckpointStore(self.app.store).head(),
            }

    def proxy(self, handler):
        """Called only after the public handler checks identity, host and origin."""
        self.ensure_http(handler.command, handler.path)
        size = int(handler.headers.get("Content-Length", "0"))
        if not 0 <= size <= 32_000_000 or handler.headers.get("Transfer-Encoding"):
            handler.respond(400, {"error": "Unsupported native request size or framing"})
            return
        websocket = handler.headers.get("Upgrade", "").lower() == "websocket"
        headers = {
            k: v
            for k, v in handler.headers.items()
            if k.lower()
            not in {
                "authorization",
                "cookie",
                "host",
                "connection",
                "tailscale-user-login",
                "x-personal-cloud-route-key",
            }
            and not k.lower().startswith("x-forwarded-")
        }
        headers["Authorization"] = "token " + self.token
        headers["Host"] = f"127.0.0.1:{self.port}"
        if "Origin" in headers:
            headers["Origin"] = f"http://127.0.0.1:{self.port}"
        headers["Connection"] = "Upgrade" if websocket else "close"
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=60)
        if websocket:
            connection.response_class = UpgradeResponse
        try:
            connection.request(
                handler.command,
                handler.path,
                body=handler.rfile.read(size) if size else None,
                headers=headers,
            )
            response = connection.getresponse()
            handler.native_response_started = True
            if websocket and response.status == 101:
                # RFC 6455 upgrades require an HTTP/1.1 response status line.
                handler.protocol_version = "HTTP/1.1"
            handler.send_response(response.status)
            for key, value in response.getheaders():
                if key.lower() not in {
                    "content-length",
                    "transfer-encoding",
                    "connection",
                    "set-cookie",
                    "content-security-policy",
                    "cache-control",
                    "server",
                    "date",
                }:
                    handler.send_header(key, value)
            handler.send_header("Content-Security-Policy", "frame-ancestors 'self'")
            handler.send_header(
                "Cache-Control",
                native_cache_control(
                    handler.command,
                    handler.path,
                    response.status,
                    response.getheader("Cache-Control", ""),
                    self.base_url,
                ),
            )
            if websocket and response.status == 101:
                handler.send_header("Connection", "Upgrade")
                handler.end_headers()
                handler.wfile.flush()
                upstream = connection.sock
                while not self.app._closed and handler.logged_in():
                    readable, _, _ = select.select([handler.connection, upstream], [], [], 0.5)
                    for source in readable:
                        data = source.recv(65536)
                        if not data:
                            return
                        (upstream if source is handler.connection else handler.connection).sendall(
                            data
                        )
            else:
                length = response.getheader("Content-Length")
                if length is not None:
                    handler.send_header("Content-Length", length)
                handler.end_headers()
                # A rejected upgrade still uses UpgradeResponse's unbuffered
                # SocketIO, which has read() but no read1(). Preserve the real
                # HTTP error body so a stale browser kernel can recover.
                read_chunk = response.read if websocket else response.read1
                while chunk := read_chunk(65536):
                    handler.wfile.write(chunk)
        finally:
            handler.close_connection = True
            connection.close()
