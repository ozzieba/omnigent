"""Fresh, cancellable cell evaluation; the document is the only execution memory."""

from __future__ import annotations

import inspect
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path

if __package__:
    from .document import canonical, digest
    from .environments import LocalEnvironment
    from .store import Conflict


_ACTIVE_ATTEMPTS = {}
_ATTEMPT_LOCK = threading.Lock()


def _process_identity(pid):
    try:
        fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        if fields[0] == "Z":
            return None
        return f"{pid}:{fields[19]}"
    except (OSError, IndexError):
        return None


def _attempt_alive(receipt):
    pid = receipt.get("owner_pid")
    if pid == os.getpid():
        with _ATTEMPT_LOCK:
            thread = _ACTIVE_ATTEMPTS.get(receipt.get("attempt_id"))
            return bool(thread and thread.is_alive())
    return bool(
        pid
        and receipt.get("owner_identity")
        and _process_identity(pid) == receipt["owner_identity"]
    )


class Executor:
    def __init__(
        self,
        store,
        timeout=60,
        max_output=1_000_000,
        mcp_config=None,
        team=None,
        environment=None,
        mcp_dispatch=None,
    ):
        self.store = store
        self.environment = environment or LocalEnvironment(store.path.parent)
        self.timeout = timeout
        self.max_output = max_output
        self.mcp_config = mcp_config or {}
        self.mcp_dispatch = mcp_dispatch
        self.team = team
        self.native_jupyter = None
        self._owns_native = False
        self.recover()

    def close(self):
        if self._owns_native and self.native_jupyter is not None:
            self.native_jupyter.close()

    def recover(self):
        """Mark orphaned attempts unknown; never execute or replay a cell."""
        for _ in range(20):
            doc, revision = self.store.read()
            changed = False
            for node in doc.nodes:
                receipt = node.metadata.get("docloop_execution", {})
                if receipt.get("status") == "running" and not _attempt_alive(receipt):
                    receipt.update(
                        status="unknown",
                        recovered_at=time.time(),
                        recovery="Execution owner is gone; side effects and outputs may be incomplete",
                    )
                    changed = True
            if not changed:
                return revision
            try:
                return self.store.save(doc, revision, "Mark orphaned execution attempts unknown")
            except Conflict:
                continue
        raise Conflict("Document busy while recovering execution attempts")

    def __call__(self, address, expected_revision, cancel_event=None):
        doc, revision = self.store.read()
        if revision != expected_revision:
            raise Conflict("Document changed before evaluation")
        node = doc.get(address)
        from .python_objects import enabled

        python_state = enabled(doc) and node.language in {
            "python",
            "python3",
            "jupyter",
            "jupyter-python",
        }
        if node.kind != "code":
            raise ValueError("Only code nodes can be evaluated")
        previous = node.metadata.get("docloop_execution", {})
        if previous.get("status") == "running" and _attempt_alive(previous):
            raise Conflict("Cell already has a live execution attempt")
        source_hash = digest(node.language + "\n" + node.source)
        started = time.time()
        attempt_id = uuid.uuid4().hex
        receipt = {
            "attempt_id": attempt_id,
            "owner_pid": os.getpid(),
            "owner_identity": _process_identity(os.getpid()),
            "environment": self.environment.descriptor(),
            "source_hash": source_hash,
            "started_at": started,
            "status": "running",
            "fresh_process": node.language != "team" and not python_state,
        }
        virtual_request = None
        if node.language == "mcp":
            try:
                parsed = json.loads(node.source)
                if isinstance(parsed, dict) and parsed.get("server") == "omnigent":
                    virtual_request = parsed
                    receipt.update(
                        external_call_id="docloop_" + attempt_id,
                        external_server="omnigent",
                        external_tool=parsed.get("tool"),
                        fresh_process=False,
                    )
            except ValueError:
                pass
        if previous.get("attempt_id"):
            receipt["previous_attempt"] = previous["attempt_id"]
        node.metadata["docloop_execution"] = receipt
        node.outputs = []
        with _ATTEMPT_LOCK:
            _ACTIVE_ATTEMPTS[attempt_id] = threading.current_thread()
        try:
            # This write precedes subprocess, MCP, and team launch. A crash leaves visible uncertainty.
            self.store.save(doc, revision, f"Begin evaluation {address}: {attempt_id}")
            status, code, stdout, stderr = "ok", 0, "", ""
            try:
                if cancel_event is not None and cancel_event.is_set():
                    status, code = "cancelled", -1
                elif python_state:
                    from types import SimpleNamespace

                    from .native import NativeJupyter

                    if self.native_jupyter is None:
                        self.native_jupyter = NativeJupyter(
                            SimpleNamespace(store=self.store, executor=self, _closed=False)
                        )
                        self._owns_native = True
                    outcome = self.native_jupyter.execute_python(
                        node.source,
                        timeout=self.timeout,
                        max_output=self.max_output,
                        cancel_event=cancel_event,
                    )
                    status, code = outcome["status"], 0 if outcome["status"] == "ok" else -1
                    receipt.update(
                        kernel_id=outcome["kernel_id"], python_checkpoint=outcome["checkpoint"]
                    )
                    stdout = json.dumps(outcome["outputs"], ensure_ascii=False)
                elif node.language == "team":
                    if self.team is None:
                        raise ValueError("Team evaluation is not configured")
                    stdout = json.dumps(
                        self.team.dispatch(json.loads(node.source)), ensure_ascii=False, indent=2
                    )
                elif virtual_request is not None:
                    if self.mcp_dispatch is None:
                        raise ValueError(
                            "Virtual Omnigent MCP requires a current Omnigent turn; no transport fallback"
                        )
                    archive_args = {}
                    if (
                        os.environ.get("DOCLOOP_CONTEXT_EPOCHS", "0") == "1"
                        and "archive" in inspect.signature(self.mcp_dispatch).parameters
                    ):
                        from .context_bridge import ContextBridge

                        archive_args["archive"] = ContextBridge(self.store).archive
                    outcome = self.mcp_dispatch(
                        virtual_request,
                        call_id=receipt["external_call_id"],
                        cancel_event=cancel_event,
                        timeout=self.timeout,
                        max_output=self.max_output,
                        **archive_args,
                    )
                    status, stdout = outcome["status"], outcome["output"]
                    code = 0 if status == "ok" else -1
                    receipt.update(outcome.get("receipt", {}))
                else:
                    if node.language in {"python", "python3"}:
                        command, payload = [sys.executable, "-u", "-c", node.source], None
                    elif node.language in {"sh", "bash", "shell"}:
                        command, payload = (
                            ["bash" if node.language == "bash" else "sh", "-c", node.source],
                            None,
                        )
                    elif node.language == "mcp":
                        command = [sys.executable, str(Path(__file__).with_name("mcp_bridge.py"))]
                        payload = json.dumps(
                            {"request": json.loads(node.source), "servers": self.mcp_config}
                        ).encode()
                    elif node.language in {"jupyter", "jupyter-python"}:
                        command, payload = (
                            [sys.executable, str(Path(__file__)), "--kernel"],
                            node.source.encode(),
                        )
                    else:
                        raise ValueError(f"Unsupported evaluation language: {node.language}")
                    status, code, stdout, stderr = self._process(command, payload, cancel_event)
            except Exception as exc:
                status, code, stderr = "error", -1, f"{type(exc).__name__}: {exc}"
            outputs = []
            if (python_state or node.language in {"jupyter", "jupyter-python"}) and stdout:
                try:
                    outputs = json.loads(stdout)
                    stdout = ""
                except json.JSONDecodeError:
                    pass
            for name, value in (("stdout", stdout), ("stderr", stderr)):
                if value:
                    outputs.append({"output_type": "stream", "name": name, "text": value})
            if status != "ok":
                outputs.append(
                    {
                        "output_type": "error",
                        "ename": status,
                        "evalue": stderr[-2000:] or status,
                        "traceback": [],
                    }
                )
            # Team/mail writes intentionally change the document during evaluation. Re-read and
            # merge only this attempt's results, retrying unrelated revision races.
            for _ in range(20):
                current, current_revision = self.store.read()
                target = current.get(address)
                active = target.metadata.get("docloop_execution", {})
                if (
                    active.get("attempt_id") != attempt_id
                    or active.get("status") != "running"
                    or digest(target.language + "\n" + target.source) != source_hash
                ):
                    raise Conflict(
                        f"Evaluated attempt or source changed; results not attached ({attempt_id})"
                    )
                target.outputs = outputs
                target.metadata["docloop_execution"] = {
                    **receipt,
                    "duration": time.time() - started,
                    "status": status,
                    "exit_code": code,
                }
                target.extra["execution_count"] = (target.extra.get("execution_count") or 0) + 1
                try:
                    return self.store.save(
                        current, current_revision, f"Evaluate {address}: {status}"
                    )
                except Conflict:
                    continue
            raise Conflict(
                "Document busy; execution finished but completion receipt could not be saved"
            )
        finally:
            with _ATTEMPT_LOCK:
                _ACTIVE_ATTEMPTS.pop(attempt_id, None)

    def _process(self, command, payload, cancel):
        with (
            tempfile.TemporaryFile() as out,
            tempfile.TemporaryFile() as err,
            tempfile.TemporaryFile() as inp,
        ):
            if payload:
                inp.write(payload)
                inp.seek(0)
            command, workspace = self.environment.prepare(command)
            proc = subprocess.Popen(
                command, stdin=inp, stdout=out, stderr=err, cwd=workspace, start_new_session=True
            )
            deadline = time.monotonic() + self.timeout
            status = "ok"
            try:
                while proc.poll() is None:
                    if cancel is not None and cancel.is_set():
                        status = "cancelled"
                    elif time.monotonic() >= deadline:
                        status = "timeout"
                    elif (
                        os.fstat(out.fileno()).st_size + os.fstat(err.fileno()).st_size
                        > self.max_output
                    ):
                        status = "output_limit"
                    if status != "ok":
                        break
                    time.sleep(0.02)
            finally:
                # Clean up descendants even when the immediate command exited successfully.
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait()
                cleanup = getattr(self.environment, "cleanup", None)
                if cleanup:
                    cleanup()
            out.seek(0)
            err.seek(0)
            full_ref = None
            if (
                os.environ.get("DOCLOOP_CONTEXT_EPOCHS", "0") == "1"
                and os.fstat(out.fileno()).st_size + os.fstat(err.fileno()).st_size
                > self.max_output
            ):
                from .context_bridge import ContextBridge

                full_ref = ContextBridge(self.store).archive(
                    canonical(
                        {
                            "stdout": out.read().decode(errors="replace"),
                            "stderr": err.read().decode(errors="replace"),
                            "capture": "bytes captured before process termination; not future output",
                        }
                    )
                )
                out.seek(0)
                err.seek(0)
            stdout = out.read(self.max_output).decode(errors="replace")
            stderr = err.read(max(0, self.max_output - len(stdout.encode()))).decode(
                errors="replace"
            )
            if os.fstat(out.fileno()).st_size + os.fstat(err.fileno()).st_size > self.max_output:
                status = "output_limit"
                stderr += "\n[output truncated at configured byte limit]"
                if full_ref:
                    stderr += "\nFull captured output: " + full_ref
            if status == "ok" and proc.returncode:
                status = "error"
            return status, proc.returncode, stdout, stderr


def _kernel():
    from jupyter_client import KernelManager

    manager = KernelManager(kernel_name="python3")
    manager.start_kernel(start_new_session=False)
    client = manager.client()
    client.start_channels()
    try:
        client.wait_for_ready(timeout=30)
        message_id = client.execute(sys.stdin.read(), store_history=False)
        failed = False
        outputs = []
        while True:
            msg = client.get_iopub_msg(timeout=60)
            if msg.get("parent_header", {}).get("msg_id") != message_id:
                continue
            kind, content = msg["msg_type"], msg["content"]
            if kind == "stream":
                outputs.append(
                    {"output_type": "stream", "name": content["name"], "text": content["text"]}
                )
            elif kind in {"display_data", "execute_result"}:
                outputs.append(
                    {
                        "output_type": "display_data",
                        "data": content.get("data", {}),
                        "metadata": content.get("metadata", {}),
                    }
                )
            elif kind == "error":
                failed = True
                outputs.append(
                    {
                        "output_type": "error",
                        "ename": content["ename"],
                        "evalue": content["evalue"],
                        "traceback": content["traceback"],
                    }
                )
            elif kind == "status" and content["execution_state"] == "idle":
                break
        print(json.dumps(outputs, ensure_ascii=False))
        return int(failed)
    finally:
        client.stop_channels()
        manager.shutdown_kernel(now=True)


if __name__ == "__main__":
    raise SystemExit(_kernel())
