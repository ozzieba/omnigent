"""Public registry import path required by Omnigent's community harness contract."""

from docloop.omnigent import create_app

__all__ = ["create_app"]
